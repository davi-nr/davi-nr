---
workflow: general-video
flow: automation
storyboard: no
message: "A meta Selic influencia o bolso por vários caminhos, mas não se confunde com a taxa de cada empréstimo ou investimento."
destination: instagram-reels
aspect: 1080x1920
language: pt-BR
audience: público brasileiro geral
length: aproximadamente 3 minutos
angle: educação econômica cotidiana
---

## Intent

Documentário econômico editorial sobre como a taxa básica de juros pode chegar às finanças cotidianas por meio do crédito, consumo, investimento e inflação. Explicar mecanismos e ressalvas sem prometer efeitos automáticos, sem transformar a Selic em taxa universal e sem infantilizar o público.

## Assets

- `assets/illustrations/familia-editorial-2d.png` — grupo ilustrativo sintético criado para este episódio; elemento recorrente, sem fala atribuída.
- `assets/fonts/` — EB Garamond, Teko e JetBrains Mono, herdadas da identidade do Vizinho Público.
- `assets/vendor/gsap.min.js` — runtime GSAP local para render reproduzível.
- `assets/audio/music-original.wav` — trilha original criada para este episódio.
- `assets/documents/research/` — capturas oficiais do BCB e cálculo da simulação PRICE.

## Customizations

- Voz: Fish Audio alias `s2.1-pro-free`, reference `ceaf7f569bef42c7bd322d88e3a356b7`, temperature/top_p 0.85, speed 1.0; texto de síntese normalizado por extenso e enviado com `normalize:false`.
- Simulação educativa com mesmo principal, prazo, sistema PRICE e taxas mensais hipotéticas; sem usar a Selic como taxa de financiamento.
- Gráfico final usa meta Selic de 13,75% a.a. com data e deve ser atualizado caso haja decisão do Copom posterior ao corte de pesquisa.
- Narração individual por cena, mix musical original com ducking, legendas e capa vertical.

## Notes

- A pesquisa foi capturada em 12/10/2026. O Copom decidiu a redução para 13,75% em 16/09/2026; verificar novamente a decisão mais recente antes de publicar em data posterior.
- O roteiro evita afirmar que a taxa de cartão ou o rendimento líquido de um investimento acompanha a Selic na mesma proporção.
- O gancho diz “cinco letras: Selic”; a Selic tem cinco letras.
- A duração final será determinada pelos takes reais e pausas naturais, com alvo aproximado de três minutos.
