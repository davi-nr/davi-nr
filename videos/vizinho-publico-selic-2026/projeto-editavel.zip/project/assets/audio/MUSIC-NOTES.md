# Original music bed

`music-original.wav` is a newly synthesized instrumental cue for this project. It uses no samples, recordings, external music models, or third-party assets. The accompanying `generate_music.py` reproduces it with deterministic additive synthesis and NumPy; the track is cleared for this project's use and may be edited to fit the final film.

- Length: 72 seconds (24 bars)
- Tempo: 80 BPM, 4/4
- Tonal center: D minor, with an F-major color
- Harmony: Dm9 – Bbmaj7 – F/A(add9) – Cadd9, repeated and lightly varied
- Arrangement: sparse felt-piano motif, soft sustained electronic tones, subdued low pulse, quiet high clock-like pulse; 1.5-second edge fades
- File: stereo 16-bit PCM WAV, 48 kHz
- Measured loudness: approximately −13.5 LUFS integrated; peak approximately −2.9 dBFS

The 72-second bed is a loopable motif rather than a finished final mix. It can be extended by editing or by repeating a musical section with a crossfade. Rebuild with `python3 generate_music.py` from this directory.
