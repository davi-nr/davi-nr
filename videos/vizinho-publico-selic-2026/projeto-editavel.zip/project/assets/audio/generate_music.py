#!/usr/bin/env python3
"""Generate an original, royalty-free ambient documentary music bed.

No samples, external services, or third-party recordings are used. The WAV is
fully reproducible from this additive-synthesis script.
"""
from __future__ import annotations

import math
import wave
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = HERE / "music-original.wav"
SR = 48_000
BPM = 80
BEAT = 60.0 / BPM
BAR = 4 * BEAT
BARS = 24
DURATION = BAR * BARS  # 72 seconds


def midi_hz(note: int) -> float:
    return 440.0 * (2.0 ** ((note - 69) / 12.0))


def add_piano(buf: np.ndarray, start: float, note: int, velocity: float,
              pan: float = 0.0, length: float = 1.5) -> None:
    """Soft struck-note tone with an inharmonic, felt-like partial spectrum."""
    i0 = max(0, int(start * SR))
    n = min(int(length * SR), len(buf) - i0)
    if n <= 0:
        return
    t = np.arange(n, dtype=np.float64) / SR
    f = midi_hz(note)
    # A tiny inharmonicity and a quick, gentle attack evoke a muted piano.
    attack = np.minimum(1.0, t / 0.012)
    env = attack * (0.72 * np.exp(-t / 0.72) + 0.28 * np.exp(-t / 1.65))
    tone = np.zeros(n, dtype=np.float64)
    for h, amp in ((1, 1.0), (2, 0.36), (3, 0.14), (4, 0.055), (5, 0.022)):
        tone += amp * np.sin(2 * np.pi * (f * h * (1 + 0.00022 * h)) * t + 0.13 * h)
    tone *= env * velocity * 0.11
    # Equal-power stereo placement, with a very quiet detuned side partial.
    l = math.sqrt((1.0 - pan) * 0.5)
    r = math.sqrt((1.0 + pan) * 0.5)
    buf[i0:i0+n, 0] += tone * l
    buf[i0:i0+n, 1] += tone * r


def add_pad(buf: np.ndarray, start: float, note: int, length: float,
            level: float = 0.022, pan: float = 0.0) -> None:
    i0 = max(0, int(start * SR))
    n = min(int(length * SR), len(buf) - i0)
    if n <= 0:
        return
    t = np.arange(n, dtype=np.float64) / SR
    f = midi_hz(note)
    fade = np.minimum(1.0, t / 0.7) * np.minimum(1.0, (length - t) / 0.8)
    fade = np.maximum(0.0, fade)
    # Soft, slightly chorused sine/triangle-like harmonics, with slow motion.
    phase = 2 * np.pi * f * t
    sig = np.sin(phase) + 0.18 * np.sin(2 * phase + 0.2) + 0.08 * np.sin(3 * phase + 0.5)
    sig += 0.20 * np.sin(2 * np.pi * (f * 1.003) * t + 0.3)
    sig *= fade * level
    l = math.sqrt((1.0 - pan) * 0.5)
    r = math.sqrt((1.0 + pan) * 0.5)
    buf[i0:i0+n, 0] += sig * l
    buf[i0:i0+n, 1] += sig * r


def add_pulse(buf: np.ndarray, start: float, note: int, level: float,
              length: float = 0.22) -> None:
    i0 = int(start * SR)
    n = min(int(length * SR), len(buf) - i0)
    if n <= 0:
        return
    t = np.arange(n, dtype=np.float64) / SR
    f = midi_hz(note)
    # Rounded, low electronic thump without a hard transient.
    env = (1 - np.exp(-t / 0.008)) * np.exp(-t / 0.095)
    sig = np.sin(2 * np.pi * f * t) * env * level
    buf[i0:i0+n, 0] += sig * 0.707
    buf[i0:i0+n, 1] += sig * 0.707


def main() -> None:
    samples = int(round(DURATION * SR))
    audio = np.zeros((samples, 2), dtype=np.float64)

    # D minor / F major palette: Dm9, Bbmaj7, Fadd9/A, Cadd9.
    # Each harmony lasts two bars; a few upper tones change on the final cycle.
    chords = [
        ([50, 57, 60, 64, 67], [74, 77]),  # Dm9
        ([46, 53, 57, 60, 65], [72, 77]),  # Bbmaj7
        ([45, 53, 57, 60, 64], [72, 76]),  # F/A add9
        ([48, 55, 59, 60, 62, 67], [74, 79]),  # Cadd9
    ]
    # Three eight-bar passes; this gives a natural loop point and gentle lift.
    for chord_idx in range(12):
        start = chord_idx * 2 * BAR
        bass, upper = chords[chord_idx % len(chords)]
        variation = chord_idx // 4
        pad_len = 2 * BAR
        for j, note in enumerate(bass[1:]):
            add_pad(audio, start, note + (12 if j >= 3 else 0), pad_len,
                    level=0.018 if variation == 0 else 0.020,
                    pan=(-0.34 + 0.17 * j))
        # Low root support is very restrained and enters after the opening.
        for beat in range(8):
            t = start + beat * BEAT
            if chord_idx < 1 and beat < 4:
                continue
            root = bass[0] - 12
            add_pulse(audio, t, root, 0.048 if beat % 2 == 0 else 0.030)
        # Sparse felt-piano motif on selected offbeats.
        motif = [upper[0], upper[1], bass[-1], upper[0] + 2,
                 upper[1], bass[-2], upper[0], upper[1] - 2]
        beat_offsets = [0.5, 1.5, 2.75, 4.5, 5.5, 6.75, 7.0, 7.5]
        # Thin the first pass; gradually let the motif emerge.
        for k, (off, note) in enumerate(zip(beat_offsets, motif)):
            if chord_idx < 2 and k in (2, 5, 7):
                continue
            if chord_idx >= 8 and k in (1, 6):
                note += 2
            onset = start + off * BEAT
            velocity = 0.40 if chord_idx < 2 else (0.46 if chord_idx < 8 else 0.43)
            add_piano(audio, onset, note, velocity, pan=(-0.22 if k % 2 == 0 else 0.22), length=1.3)

    # A quiet high-register clock/pulse lends gentle forward motion.
    # It enters after the initial statement and drops out for the last bar.
    for beat in range(8, BARS * 4 - 4):
        if beat % 2 == 0:
            t = beat * BEAT
            add_pulse(audio, t, 78, 0.0085, length=0.055)

    # Subtle wide stereo movement from a quiet, delayed copy of the piano bed.
    delay = int(0.013 * SR)
    audio[delay:, 1] += audio[:-delay, 0] * 0.035
    audio[delay:, 0] += audio[:-delay, 1] * 0.035

    # Soft edge fades avoid clicks and keep the track easy to place in an edit.
    edge = int(1.5 * SR)
    audio[:edge] *= np.linspace(0.0, 1.0, edge, endpoint=True)[:, None]
    audio[-edge:] *= np.linspace(1.0, 0.0, edge, endpoint=True)[:, None]
    peak = float(np.max(np.abs(audio)))
    if peak > 0:
        audio *= 0.72 / peak
    pcm = np.asarray(np.clip(audio, -1.0, 1.0) * 32767.0, dtype="<i2")
    with wave.open(str(OUT), "wb") as wav:
        wav.setnchannels(2)
        wav.setsampwidth(2)
        wav.setframerate(SR)
        wav.writeframes(pcm.tobytes())
    print(f"Wrote {OUT} ({DURATION:.3f}s, {SR} Hz, stereo, peak {20*math.log10(0.72):.1f} dBFS target)")


if __name__ == "__main__":
    main()
