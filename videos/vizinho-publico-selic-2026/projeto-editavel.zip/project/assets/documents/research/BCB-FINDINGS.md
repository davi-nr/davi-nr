# Pesquisa BCB — Selic (captura de 12/10/2026)

## Resultado da verificação

A taxa de 13,75% a.a. do briefing está correta para o corte em 12/10/2026, mas a formulação/datação deve ser precisa: a 281ª reunião do Copom, em 16/09/2026, reduziu a meta de 14,00% para 13,75% ao ano. A série diária do BCB (SGS 432, meta da taxa Selic) registra 14,00% até 16/09 e 13,75% a partir de 17/09, mantendo esse valor até 12/10. Assim, a frase «Em setembro de 2026, o Copom reduziu a Selic para 13,75% ao ano» é corroborada no corte desta pesquisa. A série de meta não é uma série de juros de empréstimo ou retorno líquido de aplicação.

Capturas consultadas e incluídas nesta pasta:

- `copom-recent.json`: resposta do endpoint oficial BCB para comunicados recentes; lista reunião 281, data 2026-09-16 e título “Copom reduz a taxa Selic para 13,75% a.a.”.
- `selic-target-series-2026-09-01_to_2026-10-12.json`: exportação da série SGS 432 no intervalo; mostra transição de 14,00 para 13,75.
- `copom-page-shell.html` e `selic-page-shell.html`: páginas institucionais do BCB consultadas. O site é renderizado no cliente; por isso, o dado tabular verificável foi capturado da API/SGS oficial, em vez de tratar o shell como conteúdo da página.

## Fontes primárias

1. BCB, comunicados do Copom (página pública): https://www.bcb.gov.br/controleinflacao/comunicadoscopom
2. BCB, listagem API de comunicados (consulta `quantidade=10`; captura local `copom-recent.json`): https://www.bcb.gov.br/api/servico/sitebcb/copom/comunicados?quantidade=10
3. BCB, SGS, série 432 — taxa Selic definida pelo Copom (meta; intervalo consultado): https://api.bcb.gov.br/dados/serie/bcdata.sgs.432/dados?dataInicial=01%2F09%2F2026&dataFinal=12%2F10%2F2026&formato=json
4. BCB, Taxa Selic, página explicativa: https://www.bcb.gov.br/controleinflacao/taxaselic
5. BCB, política monetária: https://www.bcb.gov.br/controleinflacao/
6. BCB, histórico das taxas de juros: https://www.bcb.gov.br/controleinflacao/historicotaxasjuros

As URLs de páginas institucionais acima são dinâmicas/client-rendered; números e datas nesta nota estão ancorados nas respostas JSON oficiais preservadas, não em busca, snippet ou inferência.

## Interpretação e cautelas editoriais

- O Copom é o comitê do Banco Central que decide a meta para a taxa Selic no âmbito da política monetária. Dizer “o Copom definiu a meta” é mais rigoroso que sugerir que o comitê estabelece diretamente todas as taxas financeiras.
- A Selic-meta é referência fundamental da política monetária. Não chamá-la de taxa universal de financiamento nem dizer que a queda de uma decisão repassa, na mesma magnitude ou imediatamente, para cartão, crédito pessoal, financiamento imobiliário ou empresarial. As taxas cobradas por instituições dependem do produto e de outros componentes, inclusive custos, risco de crédito, garantias, prazo e margem.
- A taxa Selic-meta também não equivale ao rendimento observado de qualquer investimento. Produtos que acompanham Selic/CDI têm regras próprias, podem render percentuais/referenciais diferentes e o resultado ao investidor pode variar com prazo, taxas, impostos, liquidez, preço de mercado e inflação. Se mencionar tributação, evitar uma alíquota única universal; ela depende do produto e das condições aplicáveis. Para explicar tributos concretos, acrescentar fonte específica da Receita Federal/legislação e revisar vigência.
- A relação entre política monetária, demanda e inflação é indireta, com defasagens e incerteza. Usar “tende a”, como no roteiro, e não apresentar aumento/redução de juros como causa mecânica imediata de demissões, preços ou custos individuais.
- Gráfico histórico simplificado deve rotular explicitamente que é a **meta** Selic, usar dados SGS coerentes e anotar datas das decisões/transições. Não extrapolar o valor de outubro para uma data futura.

## Recomendação de atualidade / suitability de execução única

Esta captura responde à pergunta factual para o corte de 12/10/2026, e o pacote de pesquisa é adequado como produção de uma única versão editorial datada. Não é suficiente para uma publicação em data posterior sem nova checagem: o Copom pode mudar a meta em reuniões futuras, e taxas/regras de produtos financeiros e tributos podem mudar. Antes de exportação final/publicação, consultar novamente o comunicado mais recente e a série SGS 432; se a decisão tiver mudado, revisar roteiro, arte de destaque, legenda e narração. Uma publicação sem taxa corrente também poderia evitar essa obsolescência, mantendo a explicação histórica.

## Limites desta captura

Consulta feita em 12/10/2026 (UTC). As fontes primárias confirmam a meta e o histórico do recorte. Esta nota não confirma taxas médias de crédito, rentabilidades de produtos ou regras tributárias específicas; essas afirmações exigiriam séries/fontes específicas adicionais.
