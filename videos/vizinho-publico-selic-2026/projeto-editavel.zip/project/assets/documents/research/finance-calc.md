# Cálculo PRICE — comparação hipotética (cena 6)

Premissas: principal de R$ 10.000,00; 24 parcelas mensais fixas; taxa nominal fixa de 1% a.m. ou 2% a.m.; pagamentos ao fim de cada mês; sem tributos, tarifas, seguros ou outros encargos. São cenários matemáticos hipotéticos, não cotações de crédito.

Fórmula da prestação constante (PRICE):

`A = P × i / [1 − (1 + i)^(-n)]`

em que `P` é o principal, `i` a taxa mensal em forma decimal, `n = 24` e `A` a prestação não arredondada. O total e os juros são calculados como `24 × A` e `24 × A − P`, respectivamente. Valores abaixo arredondados a centavos apenas para apresentação (ROUND_HALF_UP):

| Taxa mensal | Parcela (exata → centavos) | Total exato → centavos | Juros exatos → centavos |
|---|---:|---:|---:|
| 1% | R$ 470,734722… → **R$ 470,73** | R$ 11.297,633333… → **R$ 11.297,63** | R$ 1.297,633333… → **R$ 1.297,63** |
| 2% | R$ 528,710972… → **R$ 528,71** | R$ 12.689,063341… → **R$ 12.689,06** | R$ 2.689,063341… → **R$ 2.689,06** |

**Convenção de arredondamento:** a tabela arredonda somente os resultados finais. Se a parcela exibida em centavos for cobrada 24 vezes sem ajuste, os totais passam a R$ 11.297,52 / R$ 12.689,04 e os juros a R$ 1.297,52 / R$ 2.689,04. Isso difere do cálculo com valores internos não arredondados por R$ 0,11 / R$ 0,02, respectivamente. Em um contrato real, o cronograma e eventual ajuste da última parcela dependem da regra operacional do credor; esta simulação não presume esse ajuste.

Conferência feita com `Decimal` em Python (precisão de 50 dígitos), aplicando a fórmula acima e arredondamento decimal `ROUND_HALF_UP` a R$ 0,01. Não se usou aritmética binária de ponto flutuante.
