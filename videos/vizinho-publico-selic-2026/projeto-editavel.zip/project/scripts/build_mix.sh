#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 scripts/extend_music.py
DUR="$(python3 -c 'import json;print(float(json.load(open("assets/audio/voice-timing.json"))["program_duration_s"])+2.0)')"
ffmpeg -y -hide_banner -loglevel error \
  -i assets/audio/music-extended.wav \
  -i assets/audio/narration-consolidated.wav \
  -filter_complex "[0:a]atrim=0:${DUR},asetpts=PTS-STARTPTS,volume=0.15[bed];[1:a]atrim=0:${DUR},apad=whole_dur=${DUR},asetpts=PTS-STARTPTS,asplit=2[voice][sc];[bed][sc]sidechaincompress=threshold=0.025:ratio=4:attack=120:release=650:makeup=1[duck];[duck][voice]amix=inputs=2:duration=longest:normalize=0,alimiter=limit=0.89:attack=5:release=50[out]" \
  -map '[out]' -t "$DUR" -ar 48000 -ac 2 -c:a pcm_s16le assets/audio/final-mix.wav
python3 scripts/normalize_master.py assets/audio/final-mix.wav assets/audio/final-mix-normalized.wav
