#!/usr/bin/env python3
"""Wire the twelve authored HyperFrames scenes, normalized master, and captions."""
from __future__ import annotations
import html, json, pathlib, re
ROOT=pathlib.Path(__file__).resolve().parents[1]; AUDIO=ROOT/'assets/audio'
ROOT_IDS={'01-hook':'01-hook','02-definition':'02-definition','03-copom':'03-copom','04-high-rates':'frame04','05-low-rates':'frame05','06-financing':'frame06','07-card':'selic-card','08-business':'selic-business','09-savings':'selic-savings','10-inflation':'selic-inflation','11-current-selic':'selic-current-rate','12-outro':'selic-outro'}
def time(s):
 h,m,r=s.split(':'); sec,ms=r.split(','); return int(h)*3600+int(m)*60+int(sec)+int(ms)/1000
def cues_from_srt(p):
 out=[]
 for block in p.read_text(encoding='utf8').strip().split('\n\n'):
  a=block.splitlines()
  if len(a)<3: continue
  start,end=a[1].split(' --> '); out.append((time(start),time(end),'\n'.join(a[2:])))
 return out
def main():
 timing=json.loads((AUDIO/'voice-timing.json').read_text()); spans=timing['scenes']; duration=float(timing['program_duration_s'])+2.0
 story=(ROOT/'STORYBOARD.md').read_text(); blocks=re.findall(r'(?ms)^## Frame (\d+) — (.+?)\n(.*?)(?=^## Frame |\Z)',story)
 if len(blocks)!=12 or len(spans)!=12: raise SystemExit('Storyboard/audio timing must include 12 frames')
 scene_markup=[]
 for ix,(n,title,body) in enumerate(blocks):
  src=re.search(r'(?m)^- src: (.+)$',body).group(1).strip(); p=ROOT/src
  if not p.exists(): raise SystemExit(f'Missing scene source: {src}')
  sid=p.stem; rootid=ROOT_IDS[sid]; start=float(spans[ix]['voice_start_s'])
  end=float(spans[ix+1]['voice_start_s']) if ix<11 else duration
  span=end-start
  # Ensure authored children remain mounted through the natural transition gap/CTA hold.
  raw=p.read_text(encoding='utf8')
  raw=re.sub(r'data-duration="\d+(?:\.\d+)?"',f'data-duration="{span:.3f}"',raw)
  p.write_text(raw,encoding='utf8')
  scene_markup.append(f'<div id="scene-{sid}" class="scene-slot" data-composition-id="{rootid}" data-composition-src="{html.escape(src)}" data-start="{start:.3f}" data-duration="{span:.3f}" data-track-index="1" data-width="1080" data-height="1920"></div>')
 captions=[]; tweens=[]
 for i,(start,end,text) in enumerate(cues_from_srt(AUDIO/'captions.srt'),1):
  safe=html.escape(text).replace('\n','<br>')
  captions.append(f'<div class="caption clip" id="caption-{i}" data-start="{start:.3f}" data-duration="{end-start:.3f}" data-track-index="20">{safe}</div>')
  tweens.append(f"tl.fromTo('#caption-{i}',{{opacity:0,y:12}},{{opacity:1,y:0,duration:.12,ease:'power1.out'}},{start:.3f});tl.to('#caption-{i}',{{opacity:0,duration:.12,ease:'power1.in'}},{max(start,end-.14):.3f});")
 markup=f'''<!doctype html>
<html lang="pt-BR" data-resolution="portrait"><head><meta charset="utf-8"><meta name="viewport" content="width=1080,height=1920"><title>Vizinho Público — Por que a taxa de juros muda sua vida?</title>
<script src="assets/vendor/gsap.min.js"></script>
<style>
@font-face{{font-family:VPEB;src:url('assets/fonts/EBGaramond-700.woff2') format('woff2');font-weight:700;font-display:block}}
*{{box-sizing:border-box}}html,body{{margin:0;width:1080px;height:1920px;overflow:hidden;background:#263438}}
#root{{position:relative;width:1080px;height:1920px;overflow:hidden;background:#F4F1DE;color:#263438}}
.scene-slot{{position:absolute;inset:0;width:1080px;height:1920px}}
.caption{{position:absolute;left:76px;right:76px;top:1430px;min-height:72px;padding:12px 22px 14px;border-left:5px solid #D9A441;background:rgba(38,52,56,.95);color:#F4F1DE;font:700 40px/1.03 VPEB,Georgia,serif;letter-spacing:.005em;text-align:center;text-shadow:0 1px 1px rgba(0,0,0,.25);z-index:60;display:flex;justify-content:center;align-items:center;flex-direction:column;white-space:normal;overflow:hidden;opacity:0}}
</style></head><body><div id="root" data-composition-id="root" data-width="1080" data-height="1920" data-duration="{duration:.3f}" data-fps="30">
{''.join(scene_markup)}
<audio id="el-final-mix" class="clip" src="assets/audio/final-mix-normalized.wav" data-start="0" data-duration="{duration:.3f}" data-track-index="10" data-volume="1"></audio>
{''.join(captions)}
</div><script>window.__timelines=window.__timelines||{{}};const tl=gsap.timeline({{paused:true}});{''.join(tweens)}window.__timelines['root']=tl;tl.seek(0);</script></body></html>'''
 (ROOT/'index.html').write_text(markup,encoding='utf8')
 print(f'root assembled: scenes=12 captions={len(captions)} duration={duration:.3f}s')
if __name__=='__main__': main()
