#!/usr/bin/env python3
"""Repeat the original 72s track with crossfades and a full-program fade."""
import json, pathlib, subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
AUDIO=ROOT/'assets/audio'
source=AUDIO/'music-original.wav'
program=float(json.loads((AUDIO/'voice-timing.json').read_text())['program_duration_s'])+2.0
fade=3.0
fade_start=program-fade
out=AUDIO/'music-extended.wav'
graph=(
 '[0:a][1:a]acrossfade=d=2.0:c1=tri:c2=tri[ab];'
 '[ab][2:a]acrossfade=d=2.0:c1=tri:c2=tri[abc];'
 f'[abc]atrim=0:{program:.3f},asetpts=PTS-STARTPTS,afade=t=out:st={fade_start:.3f}:d={fade:.3f}:curve=tri[bed]'
)
subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(source),'-i',str(source),'-i',str(source),'-filter_complex',graph,'-map','[bed]','-ar','48000','-ac','2','-c:a','pcm_s16le',str(out)],check=True)
print(f'Extended original bed to {program:.3f}s; three original passes with 2s crossfades; final {fade:.1f}s fade. Original retained.')
