#!/usr/bin/env python3
"""Build readable SRT cues from HyperFrames word timestamps; correct ASR spelling only."""
from __future__ import annotations
import json,re,textwrap,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; AUDIO=ROOT/'assets/audio'
TRANSCRIPT=ROOT/'transcript.json'; MAX_WORDS=6; MAX_CHARS=52; LINE_WIDTH=34
FIX={'celic':'Selic','copon':'Copom','copão':'Copom','copao':'Copom','pras':'Price','ocd':'CDI','selic,':'Selic,','selic.':'Selic.','selic?':'Selic?','selic!':'Selic!','copom,':'Copom,','copom.':'Copom.'}
def fold(s):
 return ''.join(c for c in unicodedata.normalize('NFKD',s.casefold()) if not unicodedata.combining(c)).strip('.,!?;:()[]{}"“”')
def fmt(t):
 ms=max(0,round(t*1000)); h,ms=divmod(ms,3600000); m,ms=divmod(ms,60000); s,ms=divmod(ms,1000); return f'{h:02}:{m:02}:{s:02},{ms:03}'
def corrected(s):
 return FIX.get(s.casefold(),FIX.get(fold(s),s))
def lines(text): return textwrap.wrap(text,width=LINE_WIDTH,break_long_words=False,break_on_hyphens=False)
def main():
 raw=json.loads(TRANSCRIPT.read_text()); words=[]
 for x in raw:
  t=str(x['text']).strip()
  if not t: continue
  # HyperFrames may output a non-speech token; keep no empty marker as spoken text.
  if t.startswith('[_'): continue
  words.append({'text':corrected(t),'start':float(x['start']),'end':float(x['end'])})
 cues=[]; group=[]
 def flush():
  nonlocal group
  if not group:return
  text=' '.join(w['text'] for w in group)
  wrapped=lines(text)
  if len(wrapped)>2 and len(group)>1:
   half=max(1,len(group)//2); left=group[:half]; group=group[half:]; flush(); group=left; flush(); group=[]; return
  cues.append({'start':max(0,group[0]['start']-.025),'end':group[-1]['end']+.12,'text':'\n'.join(wrapped)})
  group=[]
 for w in words:
  candidate=' '.join(x['text'] for x in group+[w])
  if group and (len(group)>=MAX_WORDS or len(candidate)>MAX_CHARS or len(lines(candidate))>2): flush()
  group.append(w)
  if re.search(r'[.!?;:]$',w['text']): flush()
 flush()
 # Enforce non-overlap while retaining natural word timing and readable hold.
 for i,c in enumerate(cues[:-1]):
  nxt=cues[i+1]
  if c['end']>nxt['start']:
   c['end']=nxt['start']-.035
  if c['end']-c['start']<.42:
   # Expand only into an available gap, never over the next cue.
   c['end']=min(nxt['start']-.035,c['start']+.52)
 for i,c in enumerate(cues):
  if c['end']-c['start']<.42:
   need=.42-(c['end']-c['start'])
   if i>0:
    cues[i-1]['end']-=need
    c['start']-=need
   elif i+1<len(cues):
    c['end']+=need
    cues[i+1]['start']+=need
   else:
    c['end']+=need
 if any(c['start']>=c['end'] for c in cues): raise SystemExit('Invalid caption interval')
 if any(cues[i]['end']>cues[i+1]['start'] for i in range(len(cues)-1)): raise SystemExit('Caption overlap')
 if any(len(c['text'].splitlines())>2 for c in cues): raise SystemExit('Caption exceeds two lines')
 out=[]
 for i,c in enumerate(cues,1):out += [str(i),f"{fmt(c['start'])} --> {fmt(c['end'])}",c['text'],'']
 (AUDIO/'captions.srt').write_text('\n'.join(out),encoding='utf-8')
 (AUDIO/'captions.json').write_text(json.dumps(cues,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 report=(ROOT/'CAPTION-ALIGNMENT.md')
 report.write_text(f'''# Alinhamento das legendas\n\nAs legendas foram agrupadas a partir de {len(words)} timestamps por palavra produzidos pelo comando `hyperframes transcribe` (Whisper.cpp small, idioma português, alinhamento DTW), sobre o WAV consolidado. Os termos “Selic”, “Copom”, “Price” e “CDI” tiveram somente a grafia corrigida em relação a erros ortográficos prováveis do ASR. Não foi realizada escuta humana; a dicção foi verificada automaticamente e os números-chave também tiveram revisão independente por Whisper medium nas cenas 06 e 11.\n\nForam geradas {len(cues)} cues; intervalos monotônicos, sem sobreposição, com no máximo duas linhas e duração mínima de 0,42 s.\n''',encoding='utf-8')
 print(f'captions={len(cues)} words={len(words)} min_duration={min(c["end"]-c["start"] for c in cues):.3f}s')
if __name__=='__main__': main()
