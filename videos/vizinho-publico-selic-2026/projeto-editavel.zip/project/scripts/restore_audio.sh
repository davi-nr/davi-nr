#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
while IFS= read -r -d '' audio; do
 bits=$(ffprobe -v error -select_streams a:0 -show_entries stream=bits_per_raw_sample -of default=nw=1:nk=1 "$audio")
 case "$bits" in 16) codec=pcm_s16le;; 24) codec=pcm_s24le;; 32) codec=pcm_s32le;; *) echo "Unsupported bit depth: $bits" >&2; exit 1;; esac
 ffmpeg -v error -y -i "$audio" -c:a "$codec" "${audio%.flac}.wav"
done < <(find assets/audio -name '*.flac' -print0)
echo 'Áudios WAV restaurados sem perda.'
