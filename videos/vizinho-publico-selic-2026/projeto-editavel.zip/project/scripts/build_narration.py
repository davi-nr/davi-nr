#!/usr/bin/env python3
import json, subprocess, wave
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
AUDIO=ROOT/'assets/audio'; SCENES=AUDIO/'scenes'; OUT=AUDIO/'narration-consolidated.wav'
RATE=48000; CHANNELS=2; SAMPLE_WIDTH=2; GAP=0.42
spans=[]; cursor=0.0
with wave.open(str(OUT),'wb') as w:
    w.setnchannels(CHANNELS); w.setsampwidth(SAMPLE_WIDTH); w.setframerate(RATE)
    for i in range(1,13):
        src=SCENES/f'{i:02d}-scene.mp3'
        raw=subprocess.run(['ffmpeg','-v','error','-i',str(src),'-f','s16le','-acodec','pcm_s16le','-ar',str(RATE),'-ac',str(CHANNELS),'-'],check=True,stdout=subprocess.PIPE).stdout
        duration=len(raw)/(RATE*CHANNELS*SAMPLE_WIDTH)
        if i>1:
            silence=round(GAP*RATE)*CHANNELS*SAMPLE_WIDTH
            w.writeframes(b'\0'*silence); cursor+=GAP
        start=cursor; w.writeframes(raw); cursor+=duration
        spans.append({'scene':i,'voice_start_s':round(start,6),'voice_end_s':round(cursor,6),'duration_s':round(duration,6)})
    program=cursor
(AUDIO/'voice-timing.json').write_text(json.dumps({'scenes':spans,'inter_scene_gap_s':GAP,'program_duration_s':round(program,6)},indent=2)+'\n')
print(json.dumps({'duration_s':program,'scenes':spans},indent=2))
