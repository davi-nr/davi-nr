# Vizinho Público — identidade editorial

## Conceito

Uma família acompanha a viagem da taxa básica desde a mesa de decisão até as contas do cotidiano. A Selic aparece como um eixo que conecta casa, loja, fábrica, crédito e investimentos; gráficos e objetos mudam diante da família enquanto o contexto explica por que a ligação existe e onde ela deixa de ser direta.

## Paleta

- Papel: `#F4F1DE` (marfim quente)
- Tinta: `#263438` (grafite esverdeado)
- Vermelho editorial: `#B9483D` (terracota)
- Verde: `#347A70`
- Dourado de marcação: `#D9A441`
- Fundo de documento: `#E8E2D1`

Preservar a paleta e textura de papel dos episódios recentes. No comparativo financeiro, manter as duas opções igualmente legíveis; taxas mais altas serão destacadas por dados, não por cor partidária ou linguagem de reprovação.

## Tipografia

- Títulos, números e cifras: Teko 700, em caixa alta e tracking moderado.
- Narração editorial e notas: EB Garamond 400/700, corpo grande e entrelinha generosa.
- Datas, taxas e códigos: JetBrains Mono 400/700.
- Fontes locais em `assets/fonts/`; nunca depender de fontes remotas.

## Composição e movimento

Motion design editorial 2D. Usar margem de segurança ampla, tipografia grande e camadas com profundidade: fundo de papel com textura, eixo gráfico/objetos em movimento no plano médio e etiquetas/documentos no primeiro plano. A família funciona como âncora recorrente, com apenas parallax, leve oscilação e reposicionamento suave; o movimento informativo vem de escalas, barras, setas, números, linhas, etiquetas e transições motivadas.

Cada cena precisa de movimento visual relacionado ao conteúdo: abrir conexões; mudar a direção das setas; fazer a demanda desacelerar/acelerar; revelar e comparar parcelas; conectar empresas a contratações; alternar crédito e investimento; percorrer uma linha histórica de metas. Evitar telas que se comportem como slides, transições de apresentação, personagens falando ou ações corporais complexas.

## Tom

Documentário econômico contemporâneo, curioso e acessível. Usar “tende”, “pode” e “depende” quando o mecanismo econômico é indireto; nenhuma animação deve sugerir uma relação instantânea ou automática que o roteiro não afirma.
