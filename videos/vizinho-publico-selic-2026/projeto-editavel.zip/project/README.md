# Vizinho Público — Por que a taxa de juros muda a sua vida?

Projeto editável do documentário vertical em HyperFrames. A exportação principal é `renders/vizinho-publico-selic-final.mp4`; a capa é `deliverables/capa-instagram.jpg`. O projeto usa HTML/CSS/GSAP local e arquivos de mídia do próprio diretório.

## Requisitos

- Node.js compatível com HyperFrames 0.8.147 e npm.
- Python 3; NumPy é necessário somente para regenerar a trilha original.
- FFmpeg e `ffprobe` para montar narração, música, legendas e capa.
- Os arquivos locais de fontes, GSAP, áudio e ilustração em `assets/`.

GSAP e as fontes são fornecidos localmente, com avisos/licenças em `assets/vendor/` e `assets/fonts/licenses/`. Não há dependência de CDN para renderizar. O `package-lock.json` registra o projeto npm sem dependências Node adicionais; o CLI HyperFrames é chamado na versão fixada com `npx`.

## Restaurar os áudios do pacote

Os WAV estão comprimidos em FLAC sem perda. Antes de abrir ou renderizar, execute `bash scripts/restore_audio.sh`. Os takes MP3 originais também estão preservados. O MP4 final é disponibilizado separadamente no GitHub.

## Validar e renderizar

Na raiz deste projeto:

```sh
npm ci
npm run check -- --json
npx --yes hyperframes@0.8.147 render . \
  --output renders/vizinho-publico-selic-final.mp4 \
  --quality delivery --fps 30 --resolution portrait --workers 2 \
  --no-browser-gpu --experimental-fast-capture=false
```

O render fiel usa captura de screenshot com GPU de software. `npm run check` pode avisar que a ilustração ultrapassa o limite de inline do bundle; mantenha o arquivo em `assets/illustrations/` ao mover ou empacotar o projeto. O check automático de movimento pode estar desativado na versão do CLI; nesse caso, confira quadros em diferentes tempos do MP4 exportado e registre separadamente a limitação.

Para renderizar a capa editável como imagem estática:

```sh
npx --yes hyperframes@0.8.147 render . \
  --composition compositions/cover.html \
  --output renders/selic-cover-sequence --format png-sequence \
  --fps 1 --workers 1 --no-browser-gpu \
  --experimental-fast-capture=false --strict
ffmpeg -y -i renders/selic-cover-sequence/frame_000001.png \
  -q:v 2 deliverables/capa-instagram.jpg
```

## Áudio, música e legendas

As doze narrações originais estão em `assets/audio/scenes/`, e a consolidação usada pelo filme está em `assets/audio/narration-consolidated.wav`. Preserve esses arquivos para reproduzir a versão entregue sem chamar novamente um sintetizador.

Para remontar a mixagem a partir das narrações existentes, instale NumPy no Python 3 e tenha FFmpeg disponível no `PATH`:

```sh
python3 -m pip install numpy
python3 assets/audio/generate_music.py
python3 scripts/build_narration.py
bash scripts/build_mix.sh
```

Isso cria a música original com síntese aditiva determinística, estende o motivo com crossfades, monta a trilha com ducking, e gera `final-mix.wav` e `final-mix-normalized.wav`. `scripts/build_mix.sh` usa `scripts/normalize_master.py` para normalização EBU R128 em duas passagens. As vozes narradas estão preservadas como takes; a música original está documentada em `assets/audio/MUSIC-NOTES.md`.

As legendas atuais são `assets/audio/captions.srt` e `assets/audio/captions.json`. Para regenerá-las após alterar a narração, atualize primeiro `transcript.json` com os timestamps por palavra do processo HyperFrames/Whisper apropriado e execute `python3 scripts/build_captions.py`. O script valida duração mínima, ordem, limite de duas linhas e ausência de sobreposição.

Nova síntese é opcional e requer Fish Audio habilitado no ambiente. `scripts/generate_voice.py` procura a configuração MCP do Fish no ambiente Codex; credenciais não são armazenadas neste projeto. A configuração gravada em `assets/audio/voice-manifest.json` registra o alias solicitado/aceito `s2.1-pro-free`, referência vocal e `normalize: false`. Não altere os takes existentes ao validar uma nova geração.

## Organização

- `index.html`, `compositions/` e `scene-text.json`: fonte editável das cenas e capa.
- `SCRIPT.md`, `STORYBOARD.md`, `FACTS.md`: texto, storyboard e base factual.
- `AUDIT-REPORT.md`, `CAPTION-ALIGNMENT.md`: verificações e limitações.
- `assets/audio/`: narrações, música, mix, legendas e manifestos.
- `assets/documents/`: fontes e capturas consultadas.
- `deliverables/`: capa e legenda de publicação.

Consulte `ASSET-ATTRIBUTIONS.md` para créditos e licenças. Verifique novamente a meta Selic do Banco Central antes de qualquer publicação após a data de corte de 12/10/2026.
