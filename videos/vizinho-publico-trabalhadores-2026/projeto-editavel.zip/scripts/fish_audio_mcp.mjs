#!/usr/bin/env node
import readline from 'node:readline';
import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { homedir } from 'node:os';

const env = process.env;
const config = {
  apiKey: env.FISH_API_KEY,
  model: env.FISH_MODEL_ID || 's2.1-pro-free',
  referenceId: env.FISH_REFERENCE_ID,
  temperature: Number(env.FISH_TEMPERATURE ?? 0.85),
  topP: Number(env.FISH_TOP_P ?? 0.85),
  speed: Number(env.FISH_SPEED ?? 1.0),
};

if (!config.apiKey) {
  process.stderr.write('FISH_API_KEY is required\n');
  process.exit(1);
}

const valid = (n, min, max) => Number.isFinite(n) && n >= min && n <= max;
if (!valid(config.temperature, 0, 1) || !valid(config.topP, 0, 1) || !valid(config.speed, 0.5, 2)) {
  process.stderr.write('Invalid Fish Audio generation defaults\n');
  process.exit(1);
}

const tools = [
  {
    name: 'fish_audio_tts',
    description: 'Generate speech with the configured Fish Audio model, voice, temperature, top_p, and speed.',
    inputSchema: {
      type: 'object',
      properties: {
        text: { type: 'string', description: 'Text to convert to speech', maxLength: 10000 },
        output_path: { type: 'string', description: 'Optional path for the generated audio file' },
        temperature: { type: 'number', minimum: 0, maximum: 1, default: config.temperature },
        top_p: { type: 'number', minimum: 0, maximum: 1, default: config.topP },
        speed: { type: 'number', minimum: 0.5, maximum: 2, default: config.speed },
        format: { type: 'string', enum: ['mp3', 'wav', 'pcm', 'opus'], default: 'mp3' },
      },
      required: ['text'],
    },
  },
  {
    name: 'fish_audio_get_settings',
    description: 'Show the active Fish Audio model, voice, and generation settings.',
    inputSchema: { type: 'object', properties: {} },
  },
];

function reply(id, result) {
  process.stdout.write(`${JSON.stringify({ jsonrpc: '2.0', id, result })}\n`);
}

async function callTool(name, args = {}) {
  if (name === 'fish_audio_get_settings') {
    return { content: [{ type: 'text', text: JSON.stringify({
      model: config.model,
      reference_id: config.referenceId,
      temperature: config.temperature,
      top_p: config.topP,
      speed: config.speed,
    }) }] };
  }

  if (name !== 'fish_audio_tts') throw new Error(`Unknown tool: ${name}`);
  if (typeof args.text !== 'string' || !args.text.trim()) throw new Error('Text is required');
  if (args.text.length > 10000) throw new Error('Text exceeds 10000 characters');

  const temperature = args.temperature ?? config.temperature;
  const topP = args.top_p ?? config.topP;
  const speed = args.speed ?? config.speed;
  if (!valid(temperature, 0, 1) || !valid(topP, 0, 1) || !valid(speed, 0.5, 2)) {
    throw new Error('temperature and top_p must be between 0 and 1; speed must be between 0.5 and 2');
  }

  const format = args.format || 'mp3';
  if (!['mp3', 'wav', 'pcm', 'opus'].includes(format)) throw new Error('Unsupported audio format');
  const outputDir = env.AUDIO_OUTPUT_DIR || join(homedir(), '.fish-audio-mcp', 'audio_output');
  const outputPath = args.output_path || join(outputDir, `fish-audio-${Date.now()}.${format}`);
  const response = await fetch('https://api.fish.audio/v1/tts', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${config.apiKey}`,
      'Content-Type': 'application/json',
      model: config.model,
    },
    body: JSON.stringify({
      text: args.text,
      reference_id: config.referenceId,
      temperature,
      top_p: topP,
      prosody: { speed, volume: 0, normalize_loudness: true },
      format,
    }),
  });

  if (!response.ok) {
    const detail = (await response.text()).slice(0, 500);
    throw new Error(`Fish Audio API returned HTTP ${response.status}: ${detail}`);
  }

  const audio = Buffer.from(await response.arrayBuffer());
  await mkdir(dirname(outputPath), { recursive: true });
  await writeFile(outputPath, audio, { mode: 0o600 });
  return { content: [{ type: 'text', text: JSON.stringify({
    success: true,
    output_path: outputPath,
    bytes: audio.length,
    model: config.model,
    reference_id: config.referenceId,
    temperature,
    top_p: topP,
    speed,
  }) }] };
}

const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
rl.on('line', async (line) => {
  let request;
  try {
    request = JSON.parse(line);
    if (request.method === 'notifications/initialized' || request.method?.startsWith('notifications/')) return;
    if (request.method === 'initialize') {
      reply(request.id, {
        protocolVersion: request.params?.protocolVersion || '2024-11-05',
        capabilities: { tools: {} },
        serverInfo: { name: 'fish-audio-configured', version: '1.0.0' },
      });
    } else if (request.method === 'tools/list') {
      reply(request.id, { tools });
    } else if (request.method === 'tools/call') {
      try {
        reply(request.id, await callTool(request.params?.name, request.params?.arguments));
      } catch (error) {
        reply(request.id, { content: [{ type: 'text', text: error instanceof Error ? error.message : 'Fish Audio request failed' }], isError: true });
      }
    } else if (request.id !== undefined) {
      reply(request.id, { error: { code: -32601, message: 'Method not found' } });
    }
  } catch (error) {
    if (request?.id !== undefined) reply(request.id, { error: { code: -32700, message: 'Parse error' } });
  }
});
