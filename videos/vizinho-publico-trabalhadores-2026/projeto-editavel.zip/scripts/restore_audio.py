#!/usr/bin/env python3
"""Restore WAV working files from bundled lossless FLAC files.

Run from any directory with Python 3 and FFmpeg installed. FLAC decoding is
lossless; this recreates the exact PCM sources needed by index.html/build_mix.sh.
"""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
AUDIO = ROOT / "assets" / "audio"
PAIRS = {
    "music-original.flac": "music-original.wav",
    "narration-consolidated.flac": "narration-consolidated.wav",
    "final-mix-normalized.flac": "final-mix-normalized.wav",
}
for source, target in PAIRS.items():
    src, dst = AUDIO / source, AUDIO / target
    if not src.is_file():
        raise SystemExit(f"Missing bundled source: {src}")
    subprocess.run([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-i", str(src), "-map_metadata", "0", "-c:a", "pcm_s16le", str(dst)
    ], check=True)
    print(f"Restored {dst.relative_to(ROOT)}")
