# Vizinho Público — Lula × Flávio e trabalho

Documentário editorial vertical em português brasileiro, 1080 × 1920, 30 fps, corte factual em 11/10/2026. O projeto foi montado e exportado com HyperFrames 0.8.147, captura por screenshot e navegador em modo software; GSAP 3.14.2 está fixado no pacote e disponível localmente em `assets/vendor/`.

## Arquivos principais

- Vídeo final MP4: entregue separadamente ao pacote editável para manter o ZIP abaixo de 100 MiB; o caminho da master no projeto publicado é `deliverables/vizinho-publico-trabalhadores-2026-final.mp4`.
- Capa limpa: `deliverables/capa-instagram.jpg` e fonte autocontida em `cover/index.html` (`cover/assets/` contém as fontes e ilustrações necessárias).
- Narração por cena: `assets/audio/scenes/01-scene.mp3` a `11-scene.mp3`.
- Narração consolidada sem perda: `assets/audio/narration-consolidated.flac` (os MP3s individuais também estão incluídos).
- Áudios lossless no ZIP: `assets/audio/music-original.flac`, `assets/audio/narration-consolidated.flac` e `assets/audio/final-mix-normalized.flac`. Para restaurar os WAVs de trabalho referenciados pelo HTML e scripts, execute `python3 scripts/restore_audio.py`; FFmpeg decodifica FLAC sem perda. O WAV de mix pode ser recriado com `bash scripts/build_mix.sh`.
- Legendas: `assets/audio/captions.srt`.
- Fontes, checagens e ressalvas: `FACTS.md`, `TSE-IA-NOTE.md`, `ASSET-ATTRIBUTIONS.md`.
- Projeto editável: `index.html`, `compositions/frames/`, `scripts/`, `assets/`.
- Alternativa documental preparada: `compositions/alternatives/opening-documentary.html`, com retratos licenciados e créditos visíveis. Para criar uma entrada separada com esse plano: `python scripts/assemble_index.py` e `python scripts/make_documentary_opening.py`; a versão alternativa não foi exportada como MP4 nesta entrega.

## Abrir e validar

Requisitos: Node.js 20+; Python 3.11+; FFmpeg; Chrome/Chromium compatível com HyperFrames. Na pasta `project/`:

```sh
npm ci
python scripts/assemble_index.py
npx hyperframes check --json
npx hyperframes preview
```

Para renderizar novamente o MP4 principal com captura fiel por screenshots:

```sh
PRODUCER_BROWSER_GPU_MODE=software npx hyperframes render --fps 30 --workers 2 --quality delivery --resolution portrait --experimental-fast-capture=false --no-page-side-compositing --output deliverables/vizinho-publico-trabalhadores-2026-final.mp4
```

O projeto usa o executável `hyperframes` local instalado por `npm ci`; não depende de um caminho absoluto para a instalação do plugin no ambiente de origem. Para regenerar a voz, `scripts/generate_voice.py` usa o helper sem credenciais `scripts/fish_audio_mcp.mjs` e lê as configurações do Fish Audio em `CODEX_HOME/config.toml`. As credenciais não são incluídas neste diretório; configure `FISH_API_KEY`, `FISH_MODEL_ID`, `FISH_REFERENCE_ID` e os parâmetros em um cofre/configuração segura antes de usar esse fluxo. Não grave segredos em scripts, commits ou arquivos de exportação.

O modelo solicitado para a voz foi o alias `s2.1-pro-free`, referência `ceaf7f569bef42c7bd322d88e3a356b7`, temperature/top_p 0.85 e speed 1.0. A API confirmou a requisição; não foi fornecida uma atestação independente do backend que executou o modelo.

## Auditoria e publicação

Consulte `AUDIT-REPORT.md` para resultados e limites de verificação. Para recriar a mix e a master do render, primeiro restaure os WAVs de trabalho com `python3 scripts/restore_audio.py` e depois execute `bash scripts/build_mix.sh`: a mix de origem fica em `final-mix.wav` e o script cria `final-mix-normalized.wav` em dois passes para −16 LUFS e true peak ≤ −1 dBTP. `scripts/assemble_index.py` referencia essa master. O pacote editável não inclui MP4s intermediários ou diretórios de render. As transcrições automáticas servem como checagem auxiliar; não se afirma audição humana quando ela não ocorreu. Antes de publicar, revise a nota `TSE-IA-NOTE.md`, decisões eleitorais posteriores e regras atuais do Instagram/Meta.
