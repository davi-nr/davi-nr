# Narração e temporização

- Cenas narradas: 11.
- Duração de fala somada: 164.753 s.
- Respiros entre cenas: 10 transições de 0.4 s cada (4.0 s no total).
- Sustentação final sem fala: 3.0 s.
- Duração da composição: 171.753 s (2.86 min). O MP4 exportado tem 171.766667 s de vídeo (5.153 quadros a 30 fps) e 171.800 s no contêiner, incluindo a duração do áudio AAC.
- Todas as durações foram lidas com ffprobe; o MP3 de cada cena foi decodificado com ffmpeg.
