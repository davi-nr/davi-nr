---
workflow: general-video
flow: companion
storyboard: yes
format: Instagram Reels
canvas: 1080x1920
language: pt-BR
duration_max_seconds: 170
voice: Fish Audio S2.1 Pro Free; Mulher do Criativo top; ref ceaf7f569bef42c7bd322d88e3a356b7; temperature .85; top_p .85; speed 1.0
---
# Vizinho Público — WhatsApp, eleições e liberdade de expressão

Documentário editorial sobre a ação eleitoral envolvendo o canal “Exército do Lula”, com corte factual em 12/10/2026. Tratar alegações da campanha como alegações, atribuir os relatos sobre decisões posteriores aos veículos que os publicaram, e deixar explícito que não há decisão final de mérito confirmada neste recorte. Preservar o estilo documental 2D do Vizinho Público: papel claro, tinta azul-petróleo, vermelho tijolo, verde, dourado; Teko para manchetes/dados, EB Garamond para texto editorial, JetBrains Mono para datas/fontes. Usar fotos documentais com créditos; não fabricar documentos judiciais. Voz deve ser natural e serena. Encerramento e CTA dentro do limite de 170 segundos.
