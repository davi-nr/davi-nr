#!/usr/bin/env python3
"""Normalize Whisper segment text against the approved narration and validate timed captions."""
import json, pathlib, re
ROOT=pathlib.Path(__file__).resolve().parents[1]
SRT=ROOT/'assets/audio/asr-transcript.srt'
OUT=ROOT/'assets/audio/caption-cues.json'
OUT_SRT=ROOT/'assets/audio/captions-final.srt'
FIXES=[
 (r'André Giannones', 'André Janones'),
 (r'Giannones', 'Janones'),
 (r'Ricardo Villas Boas-Cueva', 'Ricardo Villas Bôas Cueva'),
 (r'Ricardo Vilas Boas-Cueva', 'Ricardo Villas Bôas Cueva'),
 (r'A legação', 'Alegação'),
 (r'receberá ação', 'receber a ação'),
 (r'Vilas Boas', 'Villas Bôas'),
 (r'Agência Brasil', 'Agência Brasil'),
 (r'Villas Bôas-Cueva', 'Villas Bôas Cueva'),
 (r'Cássio Nunes Marques', 'Kassio Nunes Marques'),
 (r'Intefira', 'interfira'),
 (r'interfere o mínimo', 'interfira o mínimo'),
 (r'justiça', 'Justiça'),
 (r'\?Siga', '? Siga'),
 (r'agência Brasil', 'Agência Brasil'),
 (r'resolução do TSE, número 23\.610,?', 'Resolução do TSE nº 23.610'),
 (r'alegando o abuso e disseminação', 'alegando abuso e disseminação'),
 (r' tem alcances diferentes', ' têm alcances diferentes'),
 (r' A pergunta de proporcionalidade é,', ' A pergunta de proporcionalidade é:'),
 (r'Na ação consta cerca de 1\.925\.000', 'Na ação constam cerca de 1.925.000'),
 (r'Quem deve fixar esse limite, siga vizinho público\.?', 'Quem deve fixar esse limite? Siga Vizinho Público.'),
 (r' Siga vizinho público\.?', ' Siga Vizinho Público.'),
 (r' O canal Exército', 'O canal Exército'),
 (r' O despacho', 'O despacho'),
]
def stamp(s):
 h,m,rest=s.split(':'); sec,ms=rest.split(','); return int(h)*3600+int(m)*60+int(sec)+int(ms)/1000
def parse():
 blocks=re.split(r'\n\s*\n',SRT.read_text(encoding='utf-8').strip())
 out=[]
 for block in blocks:
  lines=block.splitlines()
  if len(lines)<3: continue
  a,b=lines[1].split(' --> '); text=' '.join(x.strip() for x in lines[2:]).strip()
  for pattern,repl in FIXES: text=re.sub(pattern,repl,text,flags=re.I)
  out.append({'start':stamp(a),'end':stamp(b),'text':text})
 return out
def chunks(text,limit=80):
 words=text.split(); total=sum(map(len,words))+max(0,len(words)-1)
 if total<=limit:return [text]
 n=(total+limit-1)//limit; target=total/n
 groups=[];buf=''
 for wi,w in enumerate(words):
  trial=(buf+' '+w).strip()
  words_left=len(words)-wi
  groups_left=n-len(groups)
  if buf and len(trial)>target and groups_left>1 and words_left>=groups_left:
   groups.append(buf);buf=w
  else:buf=trial
 if buf:groups.append(buf)
 return groups

cues=[]
raw=parse()
# The independent ASR boundaries merged the hook question into the prior sentence.
# Re-time the approved spoken wording across the same combined span.
if len(raw)>=4:
 raw=[raw[0],{'start':raw[1]['start'],'end':9.200,'text':'Horas depois, outro ministro do mesmo tribunal determinou sua reativação.'},{'start':9.200,'end':14.200,'text':'Mas a Justiça pode suspender um canal inteiro para conter notícias falsas?'},{'start':14.200,'end':raw[3]['end'],'text':'E onde entra a liberdade de expressão?'}]+raw[4:]
for item in raw:
 parts=chunks(item['text'])
 
 if len(parts)==1:
  cues.append({**item,'text':parts[0]}); continue
 weights=[len(p) for p in parts];total=sum(weights); cursor=item['start']
 for i,p in enumerate(parts):
  end=item['end'] if i==len(parts)-1 else cursor+(item['end']-item['start'])*weights[i]/total
  cues.append({'start':cursor,'end':end,'text':p});cursor=end
for i,c in enumerate(cues):
 assert c['start'] < c['end'], c
 assert len(c['text']) <= 100, c
 if i: assert cues[i-1]['end'] <= c['start']+1e-6, (cues[i-1],c)
 assert c['end']-c['start'] >= .40, c
OUT.write_text(json.dumps(cues,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def fmt(x):
 ms=round(x*1000);h=ms//3600000;ms%=3600000;m=ms//60000;ms%=60000;sec=ms//1000;ms%=1000
 return f'{h:02d}:{m:02d}:{sec:02d},{ms:03d}'
OUT_SRT.write_text('\n\n'.join(f'{i}\n{fmt(c["start"])} --> {fmt(c["end"])}\n{c["text"]}' for i,c in enumerate(cues,1))+'\n',encoding='utf-8')
print(json.dumps({'cues':len(cues),'first':cues[0],'last':cues[-1],'min_duration_s':min(c['end']-c['start'] for c in cues),'overlaps':0,'longest_chars':max(len(c['text']) for c in cues)},ensure_ascii=False,indent=2))
