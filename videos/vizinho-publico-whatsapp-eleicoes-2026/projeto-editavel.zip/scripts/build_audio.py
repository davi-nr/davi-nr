#!/usr/bin/env python3
import pathlib, subprocess, json, re
ROOT=pathlib.Path(__file__).resolve().parents[1]
scenes=sorted((ROOT/'assets/audio/scenes').glob('[0-9][0-9]-scene.mp3'))
if len(scenes)!=12: raise SystemExit(f'Expected 12 takes, found {len(scenes)}')
# Concatenate as PCM with short, intentional breaths between scene takes.
ins=[]
for p in scenes: ins += ['-i',str(p)]
filters=[]; pieces=[]
for i,p in enumerate(scenes):
 filters.append(f'[{i}:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo[v{i}]');pieces.append(f'[v{i}]')
 if i<len(scenes)-1:
  filters.append(f'anullsrc=r=48000:cl=stereo:d=0.18[s{i}]');pieces.append(f'[s{i}]')
filters.append(''.join(pieces)+f'concat=n={len(pieces)}:v=0:a=1[narr]')
concat_graph=';'.join(filters)
narr=ROOT/'assets/audio/narration-consolidated.wav'
subprocess.run(['ffmpeg','-y',*ins,'-filter_complex',concat_graph,'-map','[narr]','-c:a','pcm_s24le',str(narr)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
narr_dur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(narr)],text=True).strip())
dur=narr_dur+0.18
music=ROOT/'assets/audio/music-original.wav'
used=ROOT/'assets/audio/music-used.wav'
fade=max(0,dur-4)
subprocess.run(['ffmpeg','-y','-i',str(music),'-t',f'{dur:.6f}','-af',f'volume=0.16,afade=t=out:st={fade:.6f}:d={min(4,dur):.6f}','-c:a','pcm_s24le',str(used)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
# Voiceover sidechain-ducks the bed; the original music and individual Fish takes remain untouched.
raw=ROOT/'assets/audio/premix.wav'
graph=f'[0:a]apad=pad_dur=0.18[narrpad];[1:a][narrpad]sidechaincompress=threshold=0.025:ratio=8:attack=35:release=550:makeup=1[duck];[narrpad][duck]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.891:level=disabled[out]'
subprocess.run(['ffmpeg','-y','-i',str(narr),'-i',str(used),'-filter_complex',graph,'-map','[out]','-c:a','pcm_s24le',str(raw)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
# Two-pass EBU R128 normalization to a Reels-friendly master ceiling.
p1=subprocess.run(['ffmpeg','-hide_banner','-i',str(raw),'-af','loudnorm=I=-16:TP=-1:LRA=7:print_format=json','-f','null','-'],text=True,capture_output=True,check=True)
match=re.search(r'\{\s*"input_i".*?\}',p1.stderr,re.S)
if not match: raise RuntimeError('Could not read loudnorm first-pass measurements')
m=json.loads(match.group(0))
af=(f"loudnorm=I=-16:TP=-1:LRA=7:measured_I={m['input_i']}:measured_TP={m['input_tp']}:measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true:print_format=summary")
final=ROOT/'assets/audio/final-mix.wav'
subprocess.run(['ffmpeg','-y','-i',str(raw),'-af',af+',apad=pad_dur=0.18','-c:a','pcm_s24le',str(final)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
raw.unlink(missing_ok=True)
print(json.dumps({'scene_takes':len(scenes),'voice_plus_breaths_s':round(dur,3),'music_bed':'ducked against voice; final 4 s fade','loudnorm_pass1':m,'final':str(final.relative_to(ROOT))},ensure_ascii=False,indent=2))
