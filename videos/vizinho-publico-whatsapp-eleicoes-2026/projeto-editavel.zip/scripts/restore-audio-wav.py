#!/usr/bin/env python3
"""Restore the lossless WAV render inputs from the FLAC files in this package."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
for name in ("final-mix", "music-original", "music-used", "narration-consolidated"):
    source = ROOT / "assets/audio" / f"{name}.flac"
    target = ROOT / "assets/audio" / f"{name}.wav"
    if not source.is_file():
        raise SystemExit(f"Missing lossless source: {source}")
    if shutil.which("ffmpeg"):
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(source), str(target)], check=True)
    else:
        raise SystemExit("FFmpeg is required to restore the WAV project inputs.")
print("Restored four WAV files losslessly from FLAC.")
