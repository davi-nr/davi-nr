VIZINHO PÚBLICO — HYPERFRAMES
WHATSAPP, ELEIÇÕES E LIBERDADE DE EXPRESSÃO

MISSÃO: Produzir um documentário editorial animado sobre a disputa judicial envolvendo o canal “Exército do Lula” no WhatsApp e os limites da atuação da Justiça Eleitoral.

1. ORQUESTRAÇÃO
Localize e acione efetivamente o subagente HyperFrames. Ele assume pesquisa, roteiro, storyboard, direção artística, narração, animação, renderização e auditoria. Remotion pode ser usado pelo HyperFrames, mas não o substituir. Preserve a identidade visual dos episódios anteriores do Vizinho Público.

2. CONFIGURAÇÃO
Formato: 1080 × 1920, vertical. Duração máxima: 2min50s. Narradora: Mulher do Criativo top. Fish Audio S2.1 Pro Free, reference ID ceaf7f569bef42c7bd322d88e3a356b7. Música instrumental documental discreta, com ducking. Motion design editorial 2D, fotografias documentais, documentos judiciais e animações fluidas. Não produzir slides estáticos nem animações corporais complexas.

3. GANCHO
“Um canal político com mais de três milhões de seguidores foi alvo de uma ordem de suspensão no WhatsApp. Horas depois, outro ministro do mesmo tribunal determinou sua reativação. Mas afinal: combater notícias falsas permite suspender um canal inteiro? E onde entra a liberdade de expressão?”

4. NARRATIVA
Bloco 1 — O que aconteceu: apresentar o canal “Exército do Lula”, administrado pelo deputado André Janones. Explicar a reclamação apresentada pela campanha de Flávio Bolsonaro e as alegações de disseminação de desinformação.
Bloco 2 — A primeira decisão: explicar a decisão de Kassio Nunes Marques, de 11/10/2026, determinando a suspensão. Distinguir alegações da campanha dos fundamentos adotados na decisão.
Bloco 3 — A reversão: explicar a decisão de Ricardo Villas Bôas Cueva, que restabeleceu provisoriamente o canal. Destacar discussão sobre suficiência das provas, competência do relator e proporcionalidade da restrição.
Bloco 4 — A legislação: liberdade de expressão protege manifestações políticas, mas não impede responsabilização por ilícitos eleitorais. Diferenciar remover uma postagem específica e suspender um canal inteiro.
Bloco 5 — O dilema: (a) combater a circulação de informações comprovadamente falsas que violem a legislação eleitoral; (b) preservar liberdade de expressão, participação política e proporcionalidade das medidas judiciais.
Bloco 6 — Conclusão: “Combater a desinformação e proteger a liberdade de expressão não são objetivos incompatíveis. A questão é como fazer isso com provas, critérios claros e respeito às garantias legais. E enquanto a disputa judicial continua, fica uma pergunta: quando uma publicação é irregular, qual deve ser o limite da intervenção? Siga @vizinhopublico.”

5. STORYBOARD
Aproximadamente 12 cenas: 1) smartphone com interface ilustrativa de canal WhatsApp; 2) contador de seguidores; 3) fotografia documental de André Janones; 4) pedido judicial da campanha de Flávio; 5) fotografia documental de Kassio Nunes Marques; 6) documento da ordem de suspensão; 7) linha do tempo; 8) fotografia documental de Ricardo Villas Bôas Cueva; 9) documento da decisão de restabelecimento; 10) balança animada desinformação × liberdade; 11) remoção pontual × suspensão integral; 12) conclusão e assinatura. Utilizar documentos autênticos sempre que disponíveis. Não fabricar documentos judiciais. Evitar caricaturas; usar fotografias documentais e textos reais das decisões.

6. VERIFICAÇÃO FACTUAL
Consultar prioritariamente TSE, textos originais das decisões, Resolução TSE 23.610/2019 e alterações, Agência Brasil e cobertura independente. Verificar o andamento mais recente antes de finalizar. Não apresentar a suspensão como definitiva; não apresentar acusações controvertidas como fatos; não afirmar que alguma decisão resolveu definitivamente o mérito. Criar FACTS.md com datas, fontes e trechos relevantes.

7. NARRAÇÃO
Normalizar números, datas e siglas antes de Fish Audio. Não permitir abreviações pronunciadas literalmente. Ouvir e corrigir segmentos problemáticos.

8. AUDITORIA E ENTREGA
Exportar 1080×1920. Música desde a primeira renderização. Auditar sincronização, pronúncia, textos, sobreposições e transições. Entregar MP4 final, projeto editável, roteiro, fontes, trilha, capa e legenda. Toda narrativa/conclusão/CTA dentro de 2min50s; sem 30s finais descartáveis.

Produzir somente afirmações sustentadas por documentos. Se os atos de 11/10/2026 ou seus textos não puderem ser confirmados, reportar o impedimento e não inventar conteúdo ou decisões. Preservar episódios anteriores.
