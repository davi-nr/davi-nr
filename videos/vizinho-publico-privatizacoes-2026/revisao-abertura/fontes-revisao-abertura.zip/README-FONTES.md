# Fontes da revisão pontual

Este ZIP é um **delta de fontes**, não duplica os assets já entregues.

1. Extraia o pacote completo original em uma **nova pasta**, preservando o projeto aprovado: https://raw.githubusercontent.com/davi-nr/davi-nr/main/videos/vizinho-publico-privatizacoes-2026/projeto-editavel.zip
2. Dentro da nova cópia `projeto-editavel`, execute `python3 scripts/restore_audio.py` para recuperar os WAVs sem perda.
3. Copie o conteúdo de `project-overlay/` deste ZIP para essa nova cópia. Isso atualiza o `index.html` e adiciona a capa editável em `compositions/cover-revision.html`.
4. Confira `REVISION-OPENING.md` e `AUDIT-REVISION.md` para o fluxo de captura fiel e exportação H.264/AAC. Para obter a CLI fixada, use `npx --yes hyperframes@0.8.147` em lugar de `hyperframes` nos exemplos, se não houver instalação global. Em ambiente com diretório pessoal somente leitura, defina `export npm_config_cache="$PWD/.cache/npm"`.

O `index.html` deste ZIP é a composição revisada pronta. O gerador `scripts/assemble_index.py` pertence ao projeto original: não o execute sobre esta revisão, pois reconstruiria a abertura antiga. A capa adicional é independente da capa aprovada anterior. Nenhuma credencial acompanha este pacote.
