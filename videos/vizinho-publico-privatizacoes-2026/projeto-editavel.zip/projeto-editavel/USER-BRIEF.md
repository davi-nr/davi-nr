PROJETO VIZINHO PÚBLICO — DOCUMENTÁRIO PRIVATIZAÇÕES: QUEM PAGA ESSA CONTA?

MISSÃO PRINCIPAL
Produzir integralmente novo documentário para @vizinhopublico, investigando privatizações, prejuízos de estatais, função social dos serviços públicos, eficiência econômica e consequências para a população brasileira. Títulos sugeridos “ESTATAL DÁ PREJUÍZO. E DAÍ?” e “PRIVATIZAÇÃO: QUEM PAGA ESSA CONTA?”; escolher definitivo pela clareza, precisão e força editorial. Pergunta central: uma estatal com prejuízo financeiro necessariamente fracassou? Privatizar garante serviço melhor? Investigar argumentos, dados e efeitos concretos sem concluir previamente que toda privatização é benéfica ou prejudicial. Documentário jornalístico profissional, não slides, imagens estáticas ou promocional.

1. ORQUESTRAÇÃO OBRIGATÓRIA
Inspecionar projeto, AGENTS, subagentes e skills. Localizar HyperFrames e mecanismo real, invocar efetivamente, confirmar execução antes de produção e delegar pesquisa/roteiro/storyboard/arte/visuais/voz/trilha/mix/render/auditoria. Ler configuração não equivale a invocar. Remotion subordinado, não substitui subagente. Usar outras skills/ferramentas quando úteis. Sem limites artificiais de tokens/agentes/pesquisa/iterações. Preservar todos os anteriores.

2. TÉCNICA
Vertical9:16,1080×1920, máximo3min incluindo abertura/encerramento/créditos/assinatura. Ideal2min45–55s, InstagramReels, documentaleditorial2D, FishAudioS2.1ProFree MulherdoCriativotop, instrumentalincorporada/duckingautomático, MP4H264+AAC, identidadeVizinhoPúblico. Nuncaexceder3min ou cortar conclusão de3min30. Reescrever/condensar ANTES de gerar vídeo se necessário.

3. IDENTIDADE VISUAL
Consultar anteriores. Motioneditorial2D, fotosdocumentaisautênticas, recortesnotícias, gráficosanimados,mapaBrasilcommovimento, documentosoficiais, tipografiacinetica, transiçõescinematográficas, isométricadiscreta,paletasóbria, composiçãolimpa. Evitarslides/textoexcessivo/fotosparadaslongotempo/transiçõesgenéricasrepetitivas/exageros/personagens3D/corposcomplexos/estéticaautomatizada. Cada cena movimento significativo ligado àfala.

4. FOTOS REAIS OBRIGATÓRIAS
Pesquisar/incorporar empresas e serviçosbrasileiros reais: Correios(fachadasagências/carteirosentregando/centrosdistribuição/transporte/atendimentocidadesspequenas), Petrobras(refinarias/plataformas/instalações/históricas),Eletrobras(hidrelétricas/transmissão/instalações),saneamento(estaçõestratamento/redes/obras/comunidadessemcobertura). Nãoapresentargenéricascomoespecíficas. Identificarorigem/direitoslicença,autorizaçãooubasejurídicaadequada/créditosprojeto. Animarparallax/zoom/pan/máscarasprofundidade/recortesprimeirosegundoplanos/transiçõesfotosilustrações. Nãfabricarfotografiasacontecimentosreais.

5. NOTÍCIAS/PRINTS REAIS OBRIGATÓRIOS
PesquisarfontesconfiáveismanchetesprejuízosCorreios/funçãosocial/privatização/tarifas/qualidade/investimentouniversalização/resultadosconcessões. FontesAgênciaBrasil,G1,Folha,Estadão,BBC,Valor,Reuters,TCU,Ipea,reguladoras,docscompanhias. Nãinventarmanchetes, capturartítulooriginal/veículo/data/contextoquando possível; nãoalterarsignificado. Recortesnecessáriosdireitosautorais. Se semautorização/baseadequada, cartãoeditorialpróprioparáfrasefielcomatribuiçãoreferência,semimitarsitefalsamente. Movimentossutisdestacarnúmerosexpressões.

6. GANCHO0–20s
Telaescura, somdiscretoimpressãojornal. MancheterealprejuízoCorreios, zoomvalor, corteagênciareal/carteiroentregaregiãodistante. Narraçãosugerida: “Você já ouviu alguém dizer que uma estatal deu bilhões de reais de prejuízo e, por isso, deveria ser privatizada? Mas existe uma pergunta que quase ninguém faz. Uma empresa pública precisa necessariamente dar lucro? E será que prejuízo financeiro significa que ela não está cumprindo seu papel?” ConfirmarresultadofinanceiroCorreios2025/publicaçãoOFICIAL/fatoresdocumentados. Nãatribuirtodoprejuízoaobrigaçõessociais: universalização/custosoperacionais/passivos/decisõesadministrativas/outros. Númerossempreconfirmados.

7. ROTEIRO/STORYBOARD
Estruturareferência,fluida natural,≤180s:
CENA1 0–20s: mancheteverdadeira/fotosreais/perguntalucrofunçãosocial/curiosidadesemconclusão.
CENA2 20–43s: balançaresultadofinanceiro×social. Estataisobrigaçõescoletivasquenãseriam escolhidasexclusivamenteporrentabilidade. Lei13303/2016art27funçãosocial. Função NÃO elimin eficiência/transparência/responsabilidadefinanceira. Distinguirgastojustificáveldesperdíciomágestão.
CENA3 43–65s: cidadebrasileirailustrativa/transporteligacomunidadedistantehospitalescola. “Imagine um transporte que custa mais para funcionar do que arrecada em passagens. Financeiramente, ele pode apresentar déficit. Mas, sem esse serviço, moradores podem perder acesso ao trabalho, à escola e ao hospital.” EXEMPLOILUSTRATIVOsubsídio, NÃO prova todasestatais. Mostrarsimultaneamentebenefíciossociaiscustos.
CENA4 65–90s: mapaBrasil/agênciasverdadeiras/rotasanimadascapitaiscidadespequenasremotas; universalizaçãopostalobrigações/custos/financiamentooficiais, separadosoutrosfatoresprejuízo.
CENA5 90–115s: públicoparaprivadocontrato/reguladorainvestimento/tarifametas. Distinguirprivatização,vendacontrole, concessão,PPP. Resultadosdependemsetorcontratoregulaçãofiscalização.
CENA6 115–140s: contaágua,redeelétricacomunidadereguladora. RISCOSPOSSÍVEIS aumentostarifas/fiscalizaçãofalha/incentivosinsuficientesmenosrentáveis/metasinadequadas/qualidade/monopóliosnaturaisescolhadifícil; nãosãoinevitáveis. ExemplosbrasileirosDOCUMENTADOSlocal/período/fontequando possível.
CENA7 140–158s: obrasmodernizaçãoexpansão. Argumentosfavoráveis: investimentoprodutividadeexpansãoemcondiçõesdeterminadas/estudoseindicadoresreais/semgeneralizarempresaparageral.
CENA8 158–175s: montagemrealcarteiroagênciatrabalhadorestratamentoágua/moradores. “Uma estatal não pode ser avaliada apenas pelo lucro. Mas sua função social também não pode servir de desculpa para desperdício. E privatizar, por si só, não garante um serviço melhor. A pergunta que realmente importa é: quanto custa, quem se beneficia e quem paga essa conta?” CTA“Siga @vizinhopublico”. Não exceder3min.

8. PESQUISA
Fontesprimárias/acadêmicas: Lei13303/2016;Constituiçãoart173/serviçospúblicos;Lei8987/1995concessões;Lei14026/2020saneamento;TCU,Ipea,ANA,Correios,peerreviewed,reguladoras. Distinguirlucrocontábil/resultoperacional/fluxocaixa/subsídio/investimento/universalização/ineficiência/benefíciosocial. Nãtratarsubsídiocomolucrooualldéficitsjustificáveis. Númeroscomempresa/ano/R$/unidade/fonte. Nãfabricardados/citações/estudos. FACTS.mdafirmaçãorelevante+fontes.

9. VOZ
FishS2.1ProFree MulherdoCriativotop, referenceceaf7f569bef42c7bd322d88e3a356b7,temp.85,top_p.85,speed1. Natural/documental/serena/segura/envolvente/semexagero. narration_text separado display_textOBRIGATÓRIO. Númerossiglasdatasabreviaçõesnormalizadas: R$8,5bilhões→“oito bilhões e quinhentos milhões de reais”;TCU→“Tribunal de Contas da União”;2025→“dois mil e vinte e cinco”. Não enviarabreviaçõesambíguas. EscutarnarraçãoINTEGRAL/corrigirpronúncia/pausas/entonação. Nãexporcredenciais.

10. MÚSICAOBRIGATÓRIA
MP4COMTRILHA desde PRIMEIRA renderização. Instrumentaldocumentalcontemporânea,pianosutil/texturas/percussãoleve/pulsoconstante/crescimentodiscreto/finalelegante. Curiosidadetensãoinício/equilíbrioexplicação/profundidadesocialsemmanipulação/resoluçãosuavefim. Música doinício,duckingfalas/vozintegrível/semclipping/saltosvolume/fadeout/licençaouoriginalredessociais. Exportartrilhaseparada.

11. PÚBLICO
Semtítulos/capas/vinhetas/legendas/chamadas/assinatura“geradoIA”,“feitoIA”,“AIGenerated”,“ChatGPT”,“agentes”etc. Identidadeexclusiva VIZINHOPÚBLICO—@vizinhopublico. Transparênciaseleieplataformaexigemcontinua.Nunca sintéticascomofotosreais.

12. AUDITORIA
Factual:todovalor/data/manchete/foto/classificação/ref. Audiovisual:sync/legibilidademobile/movimentocadascena/ortografia/pronúncia/trilha/mix/transições/export/nãocortesabruptos. DuraçãoFFprobe≤180segundos, reestruturarsuperar,nãcortarfim. Editorial:funçãosocial/déficitjustificado≠mágestão/riscosconcretos/benefíciosdocumentados/opiniões≠fatos/manchetesreais/fotosreais/identidade.

13. ENTREGÁVEIS
1MP4final1080×1920músicaincorporada;2projetoeditávelcompleto;3roteirofinal;4storyboard;5FACTS;6fotosematériasorigemdireitos;7trilhainstrumentalseparada;8capavertical;9legendainstagramMAX5hashtags;10auditoriaduração/áudio/editorial. Preservarantigos.

14. SUCESSO
Reflexãocomfatos/concretos/acessibilidade. Públicocompreenderfinanceiro≠social/funçãosocialexigeeficiência/privatização≠concessão/propriedadeisoladanãdeterminqualidade/tarifascontratosuniversalizaçãoreguladoresafetamvida. Ritmoclarezaqualidadeatéúltimosegundo. Pesquisa/arte/revisãosemeconomiaartificial. ≤3min,música,nãfake,fimcompleto,HYPERFRAMESresponsável.
