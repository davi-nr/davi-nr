# Vizinho Público — PRIVATIZAÇÃO: QUEM PAGA ESSA CONTA?

## Conceito
Um balanço público que se abre como mapa de serviços reais: uma coluna mostra as contas, outra revela quem recebe o serviço e onde. O filme parte do resultado contábil dos Correios e amplia o quadro para separar função social, eficiência e desenho regulatório. A propriedade é uma variável da análise; o resultado para as pessoas aparece na rede, no contrato, na tarifa e na fiscalização.

## Paleta
- Papel: `#F4F1DE`
- Tinta: `#263438`
- Terracota de ênfase: `#B9483D`
- Verde de serviço: `#347A70`
- Dourado: `#D9A441`
- Fundo de arquivo: `#E8E2D1`

## Tipografia
- Teko 700 para títulos e algarismos.
- EB Garamond para narração em tela e explicação editorial.
- JetBrains Mono para datas, unidades, fonte curta e notas de método.

## Composição e movimento
Formato vertical, margens seguras de Reels, um foco visual por vez e no máximo dois apoios. Fotografias documentais licenciadas, com movimentos lentos e máscaras; mapa com rotas animadas; documentos verídicos com realces; gráficos com unidades e fonte. Transições por linha de balanço, recorte de papel, deslocamento de mapa e cortes motivados pela fala. Cada cena tem mudança de estado narrativa. Não usar manchete inventada nem fotomontagem enganosa.

## Regra editorial
O resultado líquido dos Correios em 2025 é um fato contábil reportado. A causa não é decomposta em reais por universalização, passivos, decisões de gestão, custos e concorrência; o filme não atribui o prejuízo inteiro a qualquer fator. Função social exige também eficiência e responsabilidade. Privatização, concessão e PPP são instrumentos distintos; contrato, tarifa, metas e fiscalização condicionam resultados.
