# Pesquisa jurídica e evidências brasileiras — privatizações, concessões e serviços públicos

Pesquisa preparatória para o documentário “Privatizações: quem paga essa conta?”. Consulta em 12/10/2026. Este memo distingue normas, indicadores observados e inferências. Não substitui revisão jurídica da versão final nem autoriza generalizações para todos os setores.

## Síntese editorial segura

- “Estatal” não é sinônimo de serviço público: a Constituição trata de forma distinta a exploração estatal de atividade econômica (art. 173) e a prestação de serviços públicos, que pode ser direta ou por concessão/permissão (art. 175).
- A Lei das Estatais atribui função social de interesse coletivo e, no mesmo dispositivo, exige bem-estar econômico, alocação socialmente eficiente de recursos e acesso economicamente sustentado. Função social não é autorização legal para ignorar eficiência, custos ou governança.
- Concessão não transfere necessariamente a propriedade do ativo/serviço ao particular. É delegação contratual temporária da prestação, sob licitação, fiscalização, metas, regras tarifárias e obrigações contratuais. “Privatização” pode designar venda de participação/controle; convém nomear cada arranjo real com precisão.
- Leis criam deveres e instrumentos de regulação; não comprovam, por si, que determinada empresa/contrato cumpriu metas ou que determinada tarifa subiu/caiu.
- Há evidência setorial heterogênea. Um estudo observacional de distribuidoras do Nordeste (1997–2008) reporta melhora de indicadores financeiros nas três empresas privatizadas, mas não encontrou evidência de efeito na qualidade medida. Um estudo empírico sobre telecomunicações não detectou diferenças de eficiência entre julho/1998 e dezembro/1999. Esses achados são curtos/sectoriais e não autorizam conclusão universal.

## Normas primárias verificadas

### Constituição Federal
Fonte oficial: https://www.planalto.gov.br/ccivil_03/constituicao/constituicao.htm (cópia HTML de trabalho em `cf88.html`).

- Art. 173, caput: ressalvadas hipóteses constitucionais, exploração direta de atividade econômica pelo Estado só se permite quando necessária aos imperativos de segurança nacional ou a relevante interesse coletivo, conforme definidos em lei.
- Art. 173, §1º, I: o estatuto das empresas estatais deve dispor sobre sua função social e formas de fiscalização estatal e social.
- Art. 175, caput: compete ao Poder Público prestar serviços públicos diretamente ou sob concessão/permissão, sempre mediante licitação, na forma da lei.
- Art. 175, parágrafo único, I–IV: a lei tratará do regime das concessionárias/permissionárias, fiscalização e extinção, direitos dos usuários, política tarifária e dever de manter serviço adequado.
- Cautela: art. 173 não diz que toda estatal é serviço público nem estabelece que toda atividade econômica precise ser privatizada; art. 175 não determina que um serviço público seja concedido.

### Lei 13.303/2016 (Lei das Estatais)
Fonte oficial: https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2016/lei/l13303.htm (`lei-13303.html`).

Art. 27: empresa pública e sociedade de economia mista têm função social de realizar interesse coletivo ou atender imperativo de segurança nacional expresso no instrumento legal de autorização. §1º orienta a realização do interesse coletivo para o bem-estar econômico e a alocação socialmente eficiente dos recursos; inclui ampliar acesso de modo economicamente sustentado e desenvolver/empregar tecnologia brasileira de modo economicamente justificado. §2º prevê práticas de sustentabilidade ambiental e responsabilidade social corporativa compatíveis com o mercado.

Formulação fiel possível: “A lei fala em interesse coletivo, mas também em eficiência e acesso economicamente sustentado.” Não resumir o artigo a “estatais não precisam dar lucro”; o texto não institui imunidade a prejuízos ou à responsabilidade por gestão.

### Lei 8.987/1995 (concessão e permissão)
Fonte oficial consolidada: https://www.planalto.gov.br/ccivil_03/leis/l8987cons.htm (`lei-8987.html`).

- Art. 2º, II: concessão de serviço público é delegação da prestação, por licitação, a pessoa jurídica/consórcio que demonstre capacidade, por prazo determinado e por sua conta e risco.
- Art. 6º: toda concessão pressupõe serviço adequado; §1º define adequação por regularidade, continuidade, eficiência, segurança, atualidade, generalidade, cortesia e modicidade das tarifas; §2º inclui modernidade de técnicas, equipamentos e instalações e sua conservação/expansão.
- Art. 7º: assegura direitos dos usuários e prevê comunicação ao poder público de irregularidades na prestação.
- Art. 9º: tarifa é fixada conforme proposta vencedora e preservada pelas regras de revisão previstas em lei, edital e contrato; não é correto dizer que privatização/concessão implica necessariamente aumento ou redução tarifária.
- Art. 23: contrato deve disciplinar serviço, padrões/indicadores de qualidade, preço e reajuste/revisão tarifária, fiscalização, penalidades e expansão/modernização.
- Arts. 29–30: atribuem ao poder concedente/regulador a fiscalização, aplicação de penalidades e intervenção, nos termos legais/contratuais.
- Art. 38: prevê declaração de caducidade em hipóteses de inadimplemento, com processo administrativo e oportunidade de defesa.
- Limite interpretativo: existência de instrumentos legais não demonstra que a fiscalização tenha sido suficiente/efetiva no caso concreto.

### Lei 14.026/2020 (atualização do marco do saneamento)
Fonte oficial: https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2020/lei/l14026.htm (`lei-14026.html`).

A lei altera, entre outros diplomas, a Lei 11.445/2007. Texto consolidado relevante:
- Lei 11.445, art. 11-B: contratos devem prever metas de universalização de 99% da população com água potável e 90% com coleta e tratamento de esgoto até 31/12/2033, além de metas de não intermitência, redução de perdas e melhoria do tratamento. O próprio artigo prevê exceções/regras para contratos licitados com metas diversas; não apresentar a meta nacional como cobertura já atingida nem como obrigação automaticamente uniforme sem consultar o contrato/regra aplicável.
- Lei 11.445, art. 22: entidade reguladora deve estabelecer padrões de qualidade/expansão, garantir metas contratuais, prevenir/reprimir abuso de poder econômico e definir tarifas que conciliem equilíbrio econômico-financeiro e modicidade, com mecanismos de eficiência e compartilhamento de ganhos de produtividade.
- Lei 11.445, art. 23: regulação abrange dimensões técnica, econômica e social, inclusive fiscalização e sanções.
- A ANA informa que emite normas de referência nacionais a serem consideradas pelas entidades reguladoras infranacionais: https://www.gov.br/ana/pt-br/assuntos/saneamento-basico/saneamento-basico-no-brasil.
- Evidência de contexto, não de efeito da privatização: dados e diagnósticos nacionais de cobertura são publicados em séries do SNIS/SINISA e no Atlas Água e Esgotos da ANA. Compare prestadores, municípios, períodos e definições antes de usar qualquer percentual: https://www.gov.br/ana/pt-br/assuntos/aplicativos-sistemas/atlas-agua-e-esgotos.

## Estudos empíricos / casos concretos

### Distribuição de energia no Nordeste — comparação de três privatizadas e duas públicas
Silvestre, Bruno; Hall, Jeremy; Matos, Stelvia; Figueira, Luiz Augusto. “Privatization of electricity distribution in the Northeast of Brazil: the good, the bad, the ugly or the naïve?”, *Energy Policy* 38(11), 2010, DOI: https://doi.org/10.1016/j.enpol.2010.07.015.

O resumo depositado na página Figshare da publicação afirma que o estudo compara indicadores técnicos e financeiros de cinco distribuidoras (três privatizadas, duas públicas) entre 1997–2008; encontrou melhora dos indicadores financeiros das empresas privatizadas, mas “no evidence that privatization affected the quality of service” medida pelos indicadores usados. Página do registro/abstract: https://figshare.com/articles/journal_contribution/Privatization_of_electricity_distribution_in_the_Northeast_of_Brazil_the_good_the_bad_the_ugly_or_the_na_ve_/23473646 ; metadados JSON consultados: https://api.figshare.com/v2/articles/23473646.

Uso seguro: “Num estudo de cinco distribuidoras do Nordeste, os indicadores financeiros das privatizadas melhoraram no período estudado, mas o estudo não encontrou efeito demonstrável na qualidade medida.”
Limites: recorte regional, apenas cinco empresas, comparação observacional e janela histórica específica; não prova que propriedade privada causou sozinha qualquer mudança nem descreve desempenho atual de cada concessionária. Não converter “não encontrou evidência” em prova de que serviço não melhorou em toda dimensão.

### Telecomunicações — eficiência técnica no início da privatização
Resende, M.; Façanha, L. O. “Privatization and efficiency in Brazilian telecommunications: an empirical study”, *Applied Economics Letters* 9(13), 2002, pp. 823–826, DOI: https://doi.org/10.1080/13504850210128811.

Resumo indexado no OpenAlex (metadados do DOI) descreve comparação de escores relativos de eficiência via DEA em julho de 1998 e dezembro de 1999 e relata que não foram detectadas diferenças nos níveis de eficiência entre os dois momentos; observa ainda retornos decrescentes de escala em 1999. Registro: https://api.openalex.org/works/https://doi.org/10.1080/13504850210128811 ; DOI/publisher: https://doi.org/10.1080/13504850210128811.

Uso seguro: mostrar que a expansão/reorganização posterior à privatização não permite atribuir imediatamente ganhos de eficiência: estudo específico não detectou diferença entre duas medições próximas.
Limites: período curtíssimo, métrica e desenho específicos; não mede sozinho acesso universal, preço, qualidade percebida nem efeitos de longo prazo. Não usar como síntese da transformação das telecomunicações no Brasil.

### Saneamento municipal — estudo de 2026, usar só após validação do texto
Cardoso, Jordana de Menezes; Zoghbi, Ana Carolina Pereira; Resende, José Guilherme de Lara. “Privatization and sanitation outcomes: evidence from Brazilian municipalities”, *Applied Economics Letters* (2026), DOI: https://doi.org/10.1080/13504851.2026.2622550.

O abstract disponibilizado pelos metadados OpenAlex descreve dados SNIS de 2006–2022 e método SDID com adoção escalonada; reporta aumento de fluxos de investimento realizados e produtividade no curto prazo, melhora robusta no tratamento de água e melhora de tratamento de esgoto em nível convencional de significância; resposta tarifária modesta, com alguma evidência de tarifas de água menores. Indica participação privada baixa (~4% dos prestadores). Metadados/abstract: https://api.openalex.org/works/https://doi.org/10.1080/13504851.2026.2622550 ; DOI da revista: https://doi.org/10.1080/13504851.2026.2622550.

**Recomendação de cautela:** por ser resultado recente e o artigo completo não ter sido consultado nesta pesquisa, não usar números/conclusões fortes na locução até uma segunda pessoa conferir o texto integral publicado, definição de “privatização”, desenho e robustez. Se incluído, delimitar “municípios tratados na amostra, 2006–2022”; não dizer que privatizar sempre reduz tarifa ou universaliza saneamento.

### Bancos — produtividade e confusão de mecanismos
Nakane, Márcio I.; Weintraub, Daniela B. *Bank Privatization and Productivity: Evidence for Brazil*, World Bank Policy Research Working Paper 3666 (2005), DOI: https://doi.org/10.1596/1813-9450-3666. O resumo do World Bank reporta que, no setor bancário analisado, bancos públicos eram menos produtivos que pares privados e privatização elevou produtividade. Registro oficial: https://documents.worldbank.org/en/publication/documents-reports/documentdetail/2005/07/6074929/bank-privatization-productivity-evidence-brazil.

Não é evidência sobre serviço público universal nem sobre infraestrutura: setor bancário também passou por fusões, aquisições, fechamento de instituições problemáticas e entrada estrangeira. Só usar se explicar esse conjunto de mudanças e delimitar o resultado à produtividade bancária.

## Riscos/benefícios: o que se pode dizer com precisão

1. **Risco regulatório/contratual (inferência institucional, não estatística de resultado):** concessão é contrato de longo prazo e serviço essencial. Se metas, fiscalização, revisão tarifária, sanções ou capacidade institucional forem insuficientes, pode haver risco de qualidade, preço ou cobertura. As Leis 8.987 e 11.445 estabelecem ferramentas para lidar com isso, mas a mera previsão legal não prova falha ou sucesso. É melhor demonstrar por caso documentado (processo/relatório de regulador ou tribunal), identificando período e decisão.
2. **Benefícios possíveis, sem promessa:** os estudos acima encontram resultados positivos limitados em certos indicadores (finanças de distribuidoras, produtividade de bancos ou resultados de saneamento de uma amostra recente). Não extrapolar entre setor, região, empresa e período.
3. **Função social e subsídio:** para dizer que um déficit decorre de obrigação de universalização, o caso precisa mostrar obrigação formal, custo incremental/compensação e contabilidade separada. Não inferir que todo prejuízo de empresa pública é custo de serviço social, nem que toda operação deficitária seja desperdício.
4. **Tarifa:** conferir contrato, edital, estrutura regulatória e série histórica em valores reais; distinguir reajuste inflacionário, revisão, subsídio cruzado, alteração tributária e tarifa média efetivamente paga. Uma manchete de aumento nominal não mede por si custo real nem acessibilidade.
5. **Privatização vs concessão:** em audiovisual, nomear se se trata de venda/alienação do controle, concessão, PPP, autorização ou terceirização. Elas diferem quanto à titularidade, risco, duração, investimento, regulação e reversão de ativos.

## Fontes e arquivos locais

Foram baixadas cópias de trabalho da Constituição e das leis diretamente do Planalto nesta pasta (`cf88.html`, `lei-13303.html`, `lei-8987.html`, `lei-14026.html`). A fonte de autoridade é sempre o texto oficial vigente no Planalto; conferir consolidação/alterações antes da publicação. Os arquivos HTML podem renderizar com caracteres/acentos de forma imperfeita no terminal; citar o texto oficial ligado acima.

## Créditos/direitos

Normas federais em fonte oficial podem ser referenciadas como legislação; as cópias locais servem para consulta e não são assets visuais. Estudos acadêmicos e resumos citados são fontes, não licença para republicar figuras/tabelas. Para imagem de capa/quadros, obter imagens sob licença compatível ou usar design original com referências; citar origem e não reproduzir captura integral de artigo/portal sem base legal clara.

### Correios 2025 — indicador de resultado e risco de governança, não teste de privatização

A pasta de pesquisa também contém `MEMO-CORREIOS-RESULTADO-2025.md`, com auditoria e demonstrações financeiras oficiais dos Correios. O memo registra prejuízo líquido contábil de R$ 8,458 bilhões em 2025 e documenta múltiplos fatores, sem quantificar a contribuição isolada de universalização, gestão, concorrência ou passivos. O relatório independente emitiu opinião com ressalva, por não conseguir concluir sobre adequação integral das provisões de processos e passivos contingentes.

Uso seguro: como exemplo de que um balanço negativo é relevante e exige escrutínio financeiro e governança — mas, sozinho, não mensura benefício social, não prova que a obrigação universal causou a perda e não estima o que ocorreria sob privatização. A ressalva do auditor tampouco significa que o balanço inteiro foi invalidado.
