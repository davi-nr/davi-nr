# Memo de pesquisa — Correios: resultado de 2025 e componentes

**Escopo:** documentar o resultado contábil dos Correios em 2025 e o que as demonstrações oficiais mostram sobre sua composição, sem atribuir o prejuízo integralmente à obrigação de universalização postal.

**Data de consulta:** 12/10/2026. A demonstração financeira é do exercício encerrado em 31/12/2025; foi autorizada pela Diretoria em 06/04/2026 e aprovada pelo Conselho de Administração em 07/04/2026 (nota 2.1). Valores originais estão em **R$ mil**. Nas tabelas abaixo, converti para R$ milhões dividindo por mil; mantenho três casas decimais para conservar o valor exato.

## Fonte primária recuperada

1. **Correios, Demonstrações Contábeis individuais do exercício 2025**, PDF oficial: [Correios-DF-2025.pdf](Correios-DF-2025.pdf). Página de publicação oficial: [Demonstrações Financeiras](https://www.correios.com.br/acesso-a-informacao/institucional/publicacoes/demonstracoes-financeiras/demonstracoes-financeira). A cópia da página está em [Correios-demonstracoes-financeiras-index.html](Correios-demonstracoes-financeiras-index.html), o texto extraído para busca em [Correios-DF-2025.txt](Correios-DF-2025.txt). SHA-256 do PDF: `3d8ffa29552e03639308b91b3302a8fc5ca1ac306d9c4cf6a4e54a6d36caf975`.
2. **Consult Auditores Independentes, Relatório dos Auditores Independentes nº 1-04/26**, referente às demonstrações de 31/12/2025, datado de 06/04/2026: [Correios-Auditoria-2025.pdf](Correios-Auditoria-2025.pdf), texto em [Correios-Auditoria-2025.txt](Correios-Auditoria-2025.txt). Publicado junto ao conjunto anual no portal oficial acima. SHA-256: `c4a748f9ff8210d84b23aba8007a6d682986d6ce2297e681e6bec3449f4a0a6f`.

## Resultado e comparação anual

A demonstração do resultado (DRE, p. 4; nota 22, pp. 55–58) apresenta, em R$ milhões:

| Linha da DRE | 2025 | 2024 reapresentado | Variação 2025 vs. 2024 |
|---|---:|---:|---:|
| Receita líquida de vendas e serviços | 16.653,863 | 18.908,247 | −2.254,384 (−11,9%) |
| Custo dos produtos e serviços | (15.940,365) | (15.916,486) | custo maior em 23,879 |
| Lucro bruto | 713,498 | 2.991,761 | −2.278,263 |
| Despesas com vendas/serviços | (2.054,520) | (1.877,170) | despesa maior em 177,350 |
| Despesas gerais e administrativas | (6.289,086) | (4.589,848) | despesa maior em 1.699,238 |
| Outras receitas operacionais | 518,330 | 1.510,189 | −991,859 |
| Outras despesas operacionais | (38,773) | (289,064) | despesa menor em 250,291 |
| Resultado antes do resultado financeiro | (7.150,551) | (2.254,132) | piora de 4.896,419 |
| Resultado financeiro | (1.272,057) | (379,942) | piora de 892,115 |
| Resultado antes dos tributos | (8.422,608) | (2.634,074) | piora de 5.788,534 |
| Tributos sobre o lucro | (35,185) | 186,845 | piora de 222,030 |
| **Resultado líquido do período** | **(8.457,793)** | **(2.447,229)** | **piora de 6.010,564** |

O valor correto, se arredondado a uma casa decimal em bilhões, é **prejuízo líquido de R$ 8,5 bilhões em 2025**. No comparativo reapresentado, 2024 teve prejuízo líquido de R$ 2,447 bilhões. O resultado negativo de 2025 corresponde a cerca de 3,46 vezes o prejuízo de 2024; em valor absoluto, cresceu R$ 6,011 bilhões (245,6%). Isso é resultado **contábil líquido**, não medida isolada de fluxo de caixa nem demonstração de custo líquido da universalização.

Os comparativos de 2024 foram reapresentados em 2025 por revisão de estimativas de contingências trabalhistas envolvendo cumulatividade do Adicional de Atividade de Distribuição e/ou Coleta Externa (AADC) e do Adicional de Periculosidade (AP), conforme recomendação da CGU (nota 4, pp. 13–14). Para a DRE de 2024, houve ajuste de R$ 144,019 milhões na provisão de contingências trabalhistas, levando o resultado reapresentado a prejuízo de R$ 2,447 bilhões, em vez de R$ 2,591 bilhões na apresentação original. Ao narrar comparação, usar sempre **“2024 reapresentado”**.

## Componentes e fatores documentados

### Receita e operação

- A receita bruta caiu de R$ 19.560,667 milhões para R$ 17.340,452 milhões; deduções totalizaram R$ 686,589 milhões em 2025, resultando em receita líquida de R$ 16.653,863 milhões (nota 22.1, p. 55).
- A demonstração divide a receita bruta de 2025 em encomendas: R$ 9.636,398 milhões (55,6%); mensagens: R$ 4.782,071 milhões (27,5%); internacional: R$ 1.344,365 milhões (7,8%); outros: R$ 1.577,618 milhões (9,1%). A parcela identificada como monopólio foi R$ 3.988,304 milhões (23,0%); concorrencial, R$ 13.352,148 milhões (77,0%). São categorias contábeis apresentadas pela própria empresa, não uma estimativa do custo/benefício social de cada serviço.
- O custo total dos produtos/serviços foi R$ 15.940,365 milhões (quase estável contra R$ 15.916,486 milhões em 2024), mas a composição mudou: pessoal R$ 11.381,829 milhões; transporte de malas e malotes R$ 1.984,779 milhões; serviços de pessoas físicas/jurídicas R$ 1.246,003 milhões; depreciação/amortização R$ 637,602 milhões; outros itens menores completam o total (nota 22.2, p. 56).
- A nota 22.2.1 informa que o incremento no custo de pessoal incluiu reajuste salarial linear de 5,1% do ACT 2024/2025, aumento de despesas assistenciais do plano de saúde e reconhecimento de incentivo do PDV. Os impactos individualizados divulgados foram: salários e encargos, +R$ 414,926 milhões; subsídio cruzado do plano Correios Saúde II, +R$ 81,398 milhões; PDV, +R$ 174,567 milhões. A fonte não apresenta esses três valores como uma decomposição exaustiva de todo o custo de pessoal.
- Receita bruta internacional caiu de R$ 3.901,621 milhões para R$ 1.344,365 milhões (queda de R$ 2.557,256 milhões). A receita de encomendas caiu R$ 42,860 milhões; mensagens aumentaram R$ 303,632 milhões. Isso mostra que o recuo de receita ocorreu sobretudo na categoria internacional da classificação da nota, mas a publicação não fornece nesta tabela uma ponte causal completa entre volume, preços, mix e lucro.

### Despesas administrativas, judiciais e outros itens

- As despesas gerais e administrativas aumentaram R$ 1.699,238 milhões. A DRE detalha pessoal administrativo em R$ 3.220,528 milhões; precatórios e RPVs em R$ 2.479,801 milhões; pós-emprego em R$ 155,137 milhões; contingências em R$ 268,273 milhões; demais itens em valores menores (nota 22.4, p. 57).
- A despesa com precatórios e RPVs subiu de R$ 1.132,662 milhões para R$ 2.479,801 milhões. A nota 22.4.1 atribui o aumento principalmente à liquidação de obrigações judiciais — ações trabalhistas com decisões desfavoráveis e atualização. Separadamente, a nota 13.4 relata que o saldo contabilizado de precatórios/RPVs foi de R$ 645,847 milhões no início de 2025, com adições de R$ 2.393,491 milhões, atualização de R$ 86,310 milhões e pagamentos de R$ 369,069 milhões, fechando em R$ 2.756,578 milhões. Esses saldos/movimentos não devem ser apresentados como se fossem o mesmo que a linha de despesa da DRE.
- A nota 13.4 diz que houve aprimoramento do levantamento junto a tribunais e que novas informações podem alterar o período de reconhecimento de provisões. O relatório do auditor ressalva justamente a impossibilidade de concluir integralmente sobre a adequação de provisões para processos e precatórios: R$ 6.359,063 milhões registrados em 31/12/2025 na rubrica referida no relatório. A ressalva também cita pontos a aprimorar em critérios e controles internos. Portanto, o número de prejuízo da DRE é reportado, mas a mensuração de contingências relacionadas tem limitação de auditoria descrita explicitamente.
- Despesas de pós-emprego administrativas: R$ 155,137 milhões (2025), com a nota 22.4.2 atribuindo o acréscimo à provisão de despesa do plano de equacionamento do déficit (nota 11.5.1.4.1.1). Isso é um item específico; não deve ser confundido com o total dos passivos de benefícios ou entendido como causa integral do prejuízo.
- Outras receitas operacionais caíram R$ 991,859 milhões. A rubrica em 2024 incluiu R$ 512,361 milhões de ganhos tributários (principalmente crédito de PIS/COFINS decorrente de acordo judicial com a PGFN), R$ 374,406 milhões de reversão de provisão de contingências e R$ 265,829 milhões de reversão de PECLD, entre outros. Em 2025, os valores correspondentes foram R$ 0,103 milhão, R$ 119,469 milhões e R$ 33,442 milhões. Isso é uma comparação de receitas não recorrentes/estimativas lançadas em cada exercício, não prova que sua ausência explique isoladamente a perda.
- Resultado financeiro negativo: R$ 1.272,057 milhões em 2025, contra R$ 379,942 milhões em 2024; a DRE separa receita financeira de R$ 287,259 milhões e despesa financeira de R$ 1.559,316 milhões em 2025. A DFC registra empréstimo de R$ 9.300 milhões captado em financiamento e R$ 550 milhões de amortização de principal, além de juros de R$ 242,959 milhões e taxa de negociação de R$ 125,261 milhões; não presumir equivalência entre esses pagamentos/lançamentos e a despesa financeira contábil.

## O que a própria administração diz — e limite de atribuição

Na nota 2.2 (pp. 8–9), a Administração descreve pressões sobre caixa e resultados “decorrentes, principalmente” de: redução das receitas em serviços postais tradicionais; aumento de custos operacionais influenciados por inflação, reajustes salariais e passivos judiciais; intensificação da concorrência em segmentos logísticos de maior rentabilidade; e necessidade de manter estrutura operacional de elevada capilaridade em razão da obrigação legal de serviço postal universal. Este é o diagnóstico divulgado pela Administração; não vem acompanhado de estimativa em reais da contribuição isolada de cada fator.

Assim, os documentos **não quantificam qual parcela do prejuízo decorre da universalização postal** e não autorizam dizer que “o prejuízo foi causado pela universalização” ou que “o prejuízo todo é obrigação social”. Também não permitem inferir, só pelo resultado líquido, quanto seria evitável por gestão, custos ou concorrência, ou o que ocorreria sob privatização. A receita de monopólio versus concorrencial é desagregada, mas não há aqui uma alocação completa de custos, subsídio cruzado, externalidade/benefício público e margem de contribuição por produto ou por localidade.

O balanço mostra caixa e equivalentes de R$ 147,827 milhões no encerramento (R$ 114,881 milhões em 2024), mas isso não deve ser confundido com prejuízo líquido. A DFC informa recursos líquidos utilizados nas atividades operacionais de R$ 691,948 milhões em 2025 (2024: R$ 2.351,952 milhões utilizados), saída líquida de investimento de R$ 7.191,894 milhões e entradas líquidas de financiamento de R$ 7.916,788 milhões. As mutações de aplicações financeiras e a captação de crédito influenciam esses fluxos; portanto, a variação líquida de caixa de R$ 32,946 milhões não é sinônimo de lucro nem elimina o prejuízo contábil.

## Formulação editorial segura

> “Os Correios fecharam 2025 com prejuízo líquido de R$ 8,46 bilhões, segundo as demonstrações anuais da empresa. A receita líquida caiu 11,9% ante 2024, reapresentado. A empresa lista vários fatores: queda de receitas postais tradicionais, custos operacionais, decisões judiciais, concorrência logística e a manutenção de uma rede de ampla cobertura. Os documentos não calculam quanto do prejuízo cabe a cada fator — então não dá para atribuir tudo à universalização, nem concluir que o prejuízo sozinho prova que privatizar melhoraria o serviço.”

Se necessário reduzir a fala: **“O balanço mostra prejuízo; não mostra que a universalização, sozinha, o causou.”** A ressalva de auditoria sobre contingências deve estar contextualizada, por exemplo: “O auditor independente emitiu opinião com ressalva sobre provisões judiciais e contingências.” Não dizer que o auditor “invalidou” o resultado ou que a ressalva muda automaticamente o prejuízo em determinado montante.

## Arquivos e reprodução

O PDF e o relatório foram baixados diretamente dos links publicados no portal institucional dos Correios, preservando os arquivos sem alteração. Os textos `.txt` são extrações locais via `pdftotext -layout` para pesquisa; citar o PDF e a página, não a extração, na tela/legenda. Trechos ou números não dispensam revisão do PDF paginado antes de inserir na arte.
