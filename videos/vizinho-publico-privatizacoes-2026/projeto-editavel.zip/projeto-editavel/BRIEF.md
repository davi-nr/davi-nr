---
workflow: general-video
flow: automation
storyboard: no
message: "Uma estatal com prejuízo financeiro não fracassou automaticamente, e privatização sozinha não garante serviço melhor; importa quanto custa, quem se beneficia e quem paga."
destination: instagram-reels
aspect: 1080x1920
language: pt-BR
audience: público brasileiro geral
length: 165-175 seconds, hard maximum 180 seconds
angle: documentary-investigation
narration: yes
voice: Fish Audio S2.1 Pro Free, Mulher do Criativo top
---

## Intent
Produzir documentário editorial para @vizinhopublico sobre privatizações, resultados financeiros de estatais, função social dos serviços públicos, eficiência econômica e consequências para a população. Pesquisar fatos, distinguir fontes/alegações/interpretação e equilibrar benefícios e riscos concretos sem concluir previamente que toda privatização é benéfica ou prejudicial.

## Assets
- `USER-BRIEF.md` — briefing completo com narrativa, estrutura, fontes e entregáveis.
- `research/` — materiais de apuração primária e documental, a validar antes de uso audiovisual.

## Customizations
- Voz Fish Audio S2.1 Pro Free, Mulher do Criativo top, reference `ceaf7f569bef42c7bd322d88e3a356b7`, temperature/top_p 0.85, speed 1.0, normalize false; texto de locução separado do texto de tela.
- Trilha instrumental original com ducking, presente desde o primeiro render, além de faixa separada.
- Fotografias e manchetes reais com créditos/licenças; quando direitos de reprodução não estiverem estabelecidos, usar paráfrase editorial própria atribuída, sem imitar captura de site.

## Notes
- Formato vertical 1080×1920, 30 fps; filme deve terminar até 180 s, incluindo CTA e créditos.
- Verificar o demonstrativo oficial dos Correios de 2025 e não atribuir todo o prejuízo a custos sociais. Diferenciar resultado líquido, operacional, fluxo de caixa, investimentos e subsídios.
- Tratar Lei 13.303/2016 art. 27, Constituição, concessões (Lei 8.987/1995), PPPs e saneamento (Lei 14.026/2020) com fontes primárias.
- Distinguir privatização/venda de controle, concessão e PPP. Mostrar benefícios e riscos brasileiros documentados sem generalização causal.
- Preservar integralmente os episódios e arquivos anteriores. Projeto novo em diretório exclusivo.
