# Vizinho Público — Privatização: quem paga essa conta?

Projeto editorial vertical criado com HyperFrames 0.8.147. A composição principal está em `index.html` (1080 × 1920, 30 fps). O roteiro e os dados ficam em `SCRIPT.md`, `SCENE-DATA.json`, `STORYBOARD.md` e `FACTS.md`; fontes, limites de uso e créditos estão em `ASSET-ATTRIBUTIONS.md`.

## Reprodução e edição

Neste pacote distribuído, execute primeiro `python3 scripts/restore_audio.py` para restaurar os WAVs preservados sem perda em FLAC. O script valida os hashes do PCM. Os takes MP3 originais também estão incluídos. Para uso no ambiente de nuvem com diretório pessoal somente leitura, configure `export npm_config_cache="$PWD/.cache/npm"` antes dos comandos npm.

Requisitos: Node.js 20 ou mais recente, npm, Python 3 com NumPy/SciPy, FFmpeg/ffprobe e HyperFrames 0.8.147. No diretório do projeto:

```bash
npm run check
PRODUCER_LOW_MEMORY_MODE=true npx --yes hyperframes@0.8.147 render . --output exports/vizinho-publico-privatizacoes-final.mp4 --fps 30 --workers 2 --experimental-fast-capture=false
```

O comando acima produz a master fiel em captura por screenshot. Para gerar a cópia compacta de distribuição sem alterar a faixa AAC, execute `bash scripts/export_distribution.sh exports/vizinho-publico-privatizacoes-master-hyperframes.mp4 exports/vizinho-publico-privatizacoes-final.mp4`.

O arquivo de render contém a master de áudio já mixada e normalizada em `assets/audio/final-mix-normalized.wav`. Para recriar a trilha e a mixagem a partir dos takes de voz:

```bash
python3 scripts/generate_original_music.py
python3 scripts/generate_opening_sfx.py
python3 scripts/build_narration.py
bash scripts/build_mix.sh
python3 scripts/build_captions.py
```

`generate_voice.py` documenta a integração Fish Audio utilizada, com normalização desativada. A execução de novas chamadas requer credenciais fornecidas localmente pelo usuário; não há credenciais neste pacote. Os takes aprovados estão preservados em `assets/audio/scenes/` e não precisam ser regenerados para editar ou renderizar a timeline.

O projeto inclui GSAP local e fontes licenciadas sob OFL em `assets/fonts/`; avisos/licenças estão junto aos arquivos. As fotografias e o trecho documental têm atribuições individuais em `ASSET-ATTRIBUTIONS.md`. Música original gerada pelo script incluso.

A capa editável está em `compositions/cover.html`; o JPG 1080 × 1920 entregue está em `deliverables/capa-instagram.jpg`. A capa fica fora da raiz para o projeto manter `index.html` como sua única composição principal.

## Pesquisa e auditoria

`FACTS.md` registra fontes, datas de consulta e distinção entre dados, interpretações e limites causais. `research/` inclui documentos consultados e memos de verificação. A auditoria do MP4 exportado será registrada em `AUDIT-REPORT.md`.

Render fiel e snapshots usam a captura de navegador do HyperFrames. Para uso público, mantenha os créditos de mídia e verifique as licenças e regras aplicáveis à plataforma de publicação.

## Conteúdo de distribuição

Veja `DISTRIBUTION-NOTES.md` para o recorte jornalístico e a preservação lossless dos áudios. A master MP4 original permanece no projeto de origem; o arquivo de distribuição auditado é entregue separadamente. `verification/` contém os registros da verificação independente e quadros de contato do MP4 final.
