#!/usr/bin/env python3
"""Restore the exact PCM audio files preserved as lossless FLAC in this package."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / 'AUDIO-LOSSLESS-MANIFEST.json').read_text())
for item in manifest:
    source = root / item['flac']
    target = root / item['wav']
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', str(source),
                    '-c:a', item['codec'], str(target)], check=True)
    pcm = subprocess.check_output(['ffmpeg', '-v', 'error', '-i', str(target),
                                   '-f', item['pcm_format'], '-'])
    if hashlib.sha256(pcm).hexdigest() != item['pcm_sha256']:
        raise SystemExit('PCM verification failed: ' + item['wav'])
    print('Restored and verified: ' + item['wav'])
