#!/usr/bin/env python3
"""Create a short, original paper-print/rustle accent for the opening."""
import numpy as np
import wave
from pathlib import Path

rate = 48000
duration = 0.46
n = int(rate * duration)
rng = np.random.default_rng(20261012)
white = rng.normal(0, 1, n)
# A few short, irregular swishes give a quiet paper feed / press texture.
env = np.zeros(n)
for start, end, peak in [(0.015, .13, .60), (.16, .27, .44), (.31, .43, .72)]:
    a, b = int(start * rate), int(end * rate)
    x = np.linspace(0, np.pi, b - a, endpoint=True)
    env[a:b] += peak * np.sin(x) ** .65
# Slightly soften the high end, then mix a few subdued press ticks.
smoothed = np.convolve(white, np.ones(9) / 9, mode='same')
paper = (0.72 * white + 0.28 * smoothed) * env
for t, amp in [(.082, .20), (.235, .13), (.384, .18)]:
    i = int(t * rate)
    length = int(.008 * rate)
    paper[i:i + length] += amp * np.exp(-np.arange(length) / (rate * .0012)) * rng.choice([-1, 1])
paper *= .055 / max(np.max(np.abs(paper)), 1e-9)
paper *= np.linspace(.15, 0, n) ** .35
stereo = np.column_stack([paper, np.roll(paper, 17) * .96]).astype(np.float32)
out = Path(__file__).resolve().parents[1] / 'assets/audio/newsprint-sfx.wav'
out.parent.mkdir(parents=True, exist_ok=True)
pcm = np.clip(stereo, -1, 1)
pcm = np.where(pcm < 0, pcm * 32768, pcm * 32767).astype('<i2')
with wave.open(str(out), 'wb') as f:
    f.setnchannels(2)
    f.setsampwidth(2)
    f.setframerate(rate)
    f.writeframes(pcm.tobytes())
print(out)
