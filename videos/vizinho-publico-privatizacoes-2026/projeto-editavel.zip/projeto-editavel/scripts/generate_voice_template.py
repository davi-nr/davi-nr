#!/usr/bin/env python3
from __future__ import annotations
import json, os, pathlib, re, subprocess, tomllib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
SCRIPT=ROOT/'SCRIPT.md'; OUT=ROOT/'assets/audio/scenes'; HELPER=ROOT/'assets/vendor/fish_audio_tts.mjs'
CONFIG=pathlib.Path('/run/codex-environment/codex-home/config.toml')

def main():
 text=SCRIPT.read_text(encoding='utf-8')
 chunks=re.findall(r'(?m)^## (\d+) — ([^\n]+)\n(.+?)(?=\n## |\Z)',text,re.S)
 if len(chunks)!=12: raise SystemExit(f'Expected 12 scenes; found {len(chunks)}')
 OUT.mkdir(parents=True,exist_ok=True)
 cfg=tomllib.loads(CONFIG.read_text(encoding='utf-8'))
 env=os.environ.copy();env.update(cfg['mcp_servers']['fish-audio']['env']);env['NODE_USE_ENV_PROXY']='1';env['AUDIO_OUTPUT_DIR']=str(OUT)
 manifest_path=ROOT/'assets/audio/voice-manifest.json'
 old_manifest={x['scene']:x for x in json.loads(manifest_path.read_text())} if manifest_path.exists() else {}
 only={int(x) for x in sys.argv[1:]}
 manifest=[]
 speech=[]
 for num,title,body in chunks:
  narration=' '.join(body.split())
  scene_id=f'{int(num):02d}'
  display={'01':'MILHÕES / QUEM DECIDE O LIMITE?','02':'EXÉRCITO DO LULA · AÇÃO ELEITORAL','03':'10 OUT · ESCLARECIMENTOS EM 72 HORAS','04':'11 OUT · SUSPENSÃO — SEGUNDO AGÊNCIA BRASIL','05':'11 OUT · REATIVAÇÃO PROVISÓRIA — SEGUNDO G1','06':'ORDENS POSTERIORES · TEXTOS NÃO OBTIDOS','07':'12 OUT · MÉRITO EM DISCUSSÃO','08':'RESOLUÇÃO TSE 23.610 · ART. 38','09':'POSTAGEM ESPECÍFICA × CANAL INTEIRO','10':'MILHÕES · MEDIÇÕES EM DATAS DIFERENTES','11':'PROVAS · ALCANCE · PROPORCIONALIDADE','12':'QUAL É O LIMITE? · @VIZINHOPUBLICO'}[scene_id]
  speech.append({'scene':int(num),'title':title,'display_text':display,'narration_text':narration})
  path=OUT/f'{scene_id}-scene.mp3'
  if only and int(num) not in only:
   manifest.append(old_manifest.get(int(num),{'scene':int(num),'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'model_requested':'s2.1-pro-free','reference_id':'ceaf7f569bef42c7bd322d88e3a356b7','temperature':0.85,'top_p':0.85,'speed':1.0,'normalize':False}))
   continue
  args={'text':narration,'output_path':str(path),'format':'mp3','temperature':0.85,'top_p':0.85,'speed':1.0,'normalize':False}
  req={'jsonrpc':'2.0','id':int(num),'method':'tools/call','params':{'name':'fish_audio_tts','arguments':args}}
  result=subprocess.run(['node',str(HELPER)],input=json.dumps(req,ensure_ascii=False)+'\n',capture_output=True,text=True,env=env,timeout=240,check=True)
  response=json.loads(result.stdout.splitlines()[-1]);body=response.get('result',{})
  if body.get('isError'): raise RuntimeError(body.get('content',[{}])[0].get('text','TTS failed'))
  detail=json.loads(body['content'][0]['text'])
  if not detail.get('success') or not path.exists() or path.stat().st_size==0: raise RuntimeError(f'No audio for scene {num}')
  manifest.append({'scene':int(num),'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'model_requested':detail.get('model'),'model_backend_attestation':'not independently provided by response','reference_id':detail.get('reference_id'),'temperature':detail.get('temperature'),'top_p':detail.get('top_p'),'speed':detail.get('speed'),'normalize':False})
  print(json.dumps({'scene':num,'bytes':path.stat().st_size,'model':detail.get('model')},ensure_ascii=False),flush=True)
 (ROOT/'assets/audio/scene-text.json').write_text(json.dumps(speech,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 (ROOT/'assets/audio/voice-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
if __name__=='__main__': main()
