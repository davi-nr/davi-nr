#!/usr/bin/env python3
"""Build corrected Portuguese captions from the approved narration and Whisper word timestamps."""
import json, pathlib, re, unicodedata, difflib, html
P=pathlib.Path(__file__).resolve().parents[1]
scene_text=json.loads((P/'assets/audio/scene-text.json').read_text())
timing=json.loads((P/'assets/audio/voice-timing.json').read_text())
asr=json.loads((P/'assets/audio/asr-small-final.json').read_text())

def ms(t):
    h,m,s=t.split(':'); ss,mmm=s.split(','); return int(h)*3600+int(m)*60+int(ss)+int(mmm)/1000

def norm(s):
    s=unicodedata.normalize('NFD',s.lower())
    s=''.join(c for c in s if unicodedata.category(c)!='Mn')
    return re.sub(r'[^a-z0-9]+','',s)

def transcript_words(segs):
    out=[]
    for seg in segs:
        for tok in seg.get('tokens',[]):
            raw=tok.get('text','')
            if not raw or raw.startswith('[_'): continue
            ts=tok.get('timestamps') or {}
            try: a,b=ms(ts['from']),ms(ts['to'])
            except Exception: continue
            text=raw
            starts=bool(text[:1].isspace())
            text=text.strip()
            if not text: continue
            # Whisper token fragments with leading spaces begin a lexical token.
            if starts or not out:
                out.append({'text':text,'start':a,'end':b})
            else:
                out[-1]['text']+=text
                out[-1]['end']=max(out[-1]['end'],b)
    return out

def wrap(words, limit=50):
    lines=[]; line=''
    for w in words:
        cand=(line+' '+w['text']).strip()
        if len(cand)>limit and line:
            lines.append(line); line=w['text']
        else: line=cand
    if line: lines.append(line)
    return lines

def stamp(t):
    n=max(0,round(t*1000)); h=n//3600000; n%=3600000; m=n//60000; n%=60000; s=n//1000; ms=n%1000
    return f'{h:02}:{m:02}:{s:02},{ms:03}'

asr_words=transcript_words(asr['transcription'])
cues=[]
for idx,item in enumerate(scene_text):
    span=timing['scenes'][idx]
    start=float(span['voice_start_s']); end=float(span['voice_end_s'])
    aw=[w for w in asr_words if w['end']>start+.01 and w['start']<end-.01]
    # Clip word candidates to this scene and retain local-relative times for alignment.
    local=[]
    for w in aw:
        local.append({'text':w['text'],'start':max(start,w['start']),'end':min(end,w['end'])})
    text=item['narration_text']
    target=[{'text':m.group(0),'start':None,'end':None} for m in re.finditer(r"[\w]+(?:['’][\w]+)*[.,!?;:]?",text,re.UNICODE)]
    tn=[norm(w['text']) for w in target]; an=[norm(w['text']) for w in local]
    sm=difflib.SequenceMatcher(None,tn,an,autojunk=False)
    for a,b,n in sm.get_matching_blocks():
        for k in range(n):
            target[a+k]['start']=local[b+k]['start']; target[a+k]['end']=local[b+k]['end']
    anchors=[i for i,w in enumerate(target) if w['start'] is not None]
    # Interpolate only unmatched words between neighboring ASR anchors.
    prev=-1
    for nxt in anchors+[len(target)]:
        lo=target[prev]['end'] if prev>=0 else start
        hi=target[nxt]['start'] if nxt<len(target) else end
        count=nxt-prev-1
        if count>0:
            step=max(0,(hi-lo)/count)
            for j in range(count):
                i=prev+1+j; target[i]['start']=lo+j*step; target[i]['end']=lo+(j+1)*step
        prev=nxt
    # Build readable phrase cues: break at sentence punctuation, or at two-line/10-word limit.
    groups=[]; cur=[]
    for w in target:
        test=cur+[w]
        too_many=len(test)>10 or len(wrap(test))>2 or test[-1]['end']-test[0]['start']>3.3
        sent_end=bool(re.search(r'[.!?;:]$',w['text'])) and len(test)>=5
        if cur and (too_many or sent_end):
            groups.append(cur); cur=[]
        cur.append(w)
    if cur: groups.append(cur)
    # Merge short fragments where possible and keep each caption readable.
    merged=[]
    for g in groups:
        if merged and (g[-1]['end']-g[0]['start']<.68 or len(wrap(g))==1 and len(g)<3):
            trial=merged[-1]+g
            if len(trial)<=10 and len(wrap(trial))<=2 and trial[-1]['end']-trial[0]['start']<=3.3:
                merged[-1]=trial; continue
        merged.append(g)
    for g in merged:
        lines=wrap(g)
        if len(lines)>2: raise ValueError(f'Caption exceeds two lines in scene {idx+1}: {lines}')
        a=max(0,g[0]['start']-.035); b=min(float(timing['program_duration_s']),g[-1]['end']+.085)
        if b-a<.45: b=a+.45
        cues.append({'start':a,'end':b,'text':'\n'.join(lines),'scene':idx+1})
# Ensure chronological non-overlap and plausible duration.
cues.sort(key=lambda x:x['start'])
for i,c in enumerate(cues):
    if i and c['start']<cues[i-1]['end']:
        c['start']=cues[i-1]['end']+.025
    if c['end']<=c['start']: c['end']=c['start']+.45
    if i+1<len(cues) and c['end']>cues[i+1]['start']:
        c['end']=max(c['start']+.42,cues[i+1]['start']-.025)
    if c['end']-c['start']<.4: raise ValueError(f'Caption too short: {c}')

srt='\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(cues))+'\n'
(P/'assets/audio/captions-final.srt').write_text(srt)
(P/'assets/audio/captions-final.json').write_text(json.dumps(cues,ensure_ascii=False,indent=2)+'\n')
markup='<div id="caption-layer">'+''.join(f'<div class="caption" id="cap{i}">{html.escape(c["text"]).replace(chr(10),"<br>")}</div>' for i,c in enumerate(cues))+'</div>'
path=P/'index.html'; doc=path.read_text()
needle='</audio>\n</div><script>window.__timelines'
if needle not in doc: raise SystemExit('Could not find caption insertion point')
doc=doc.replace(needle,'</audio>\n'+markup+'\n</div><script>window.__timelines',1)
code=''.join(f"tl.fromTo('#cap{i}',{{opacity:0}},{{opacity:1,duration:.06}}, {c['start']:.3f});tl.to('#cap{i}',{{opacity:0,duration:.06}}, {c['end']:.3f});" for i,c in enumerate(cues))
doc=doc.replace("window.__timelines['root']=tl;",code+"window.__timelines['root']=tl;",1)
path.write_text(doc)
print(json.dumps({'captions':len(cues),'min_s':round(min(c['end']-c['start'] for c in cues),3),'max_s':round(max(c['end']-c['start'] for c in cues),3),'max_lines':max(len(c['text'].splitlines()) for c in cues),'duration':round(float(timing['program_duration_s']),3)},ensure_ascii=False))
