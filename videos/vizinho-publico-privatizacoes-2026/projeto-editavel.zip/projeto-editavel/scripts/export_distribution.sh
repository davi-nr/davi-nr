#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
  echo "Usage: $0 MASTER.mp4 OUTPUT.mp4" >&2
  exit 2
fi

ffmpeg -y -i "$1" \
  -map 0:v:0 -map 0:a:0 \
  -c:v libx264 -preset medium -crf 20 \
  -profile:v high -level:v 4.1 -pix_fmt yuv420p \
  -c:a copy -movflags +faststart \
  "$2"
