#!/usr/bin/env python3
from __future__ import annotations
import json, os, pathlib, re, subprocess, tomllib, hashlib
P=pathlib.Path(__file__).resolve().parents[1]
TEXT=P/'assets/audio/scene-text.json'; OUT=P/'assets/audio/scenes'; HELPER=P/'assets/vendor/fish_audio_tts.mjs'
VOICE='ceaf7f569bef42c7bd322d88e3a356b7'
def main():
 data=json.loads(TEXT.read_text(encoding='utf-8'))
 if len(data)!=8 or [x['scene'] for x in data]!=list(range(1,9)): raise SystemExit('Expected scenes 1–8')
 if any(re.search(r'\d',x['narration_text']) for x in data): raise SystemExit('Narration must spell out all numbers')
 config=tomllib.loads(pathlib.Path('/run/codex-environment/codex-home/config.toml').read_text(encoding='utf8'))
 fish=config['mcp_servers']['fish-audio']['env']
 env=os.environ.copy(); env.update(fish); env.update(AUDIO_OUTPUT_DIR=str(OUT),NODE_USE_ENV_PROXY='1')
 OUT.mkdir(parents=True,exist_ok=True)
 manifest_path=P/'assets/audio/voice-manifest.json'
 old=json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.exists() else []
 records={int(x['scene']):x for x in old}
 selected={int(x) for x in __import__('sys').argv[1:]} if len(__import__('sys').argv)>1 else set(range(1,9))
 for item in data:
  i=item['scene']
  if i not in selected: continue
  path=OUT/f'{i:02d}-scene.mp3'
  args={'text':item['narration_text'],'output_path':str(path),'format':'mp3','temperature':.85,'top_p':.85,'speed':1.0,'normalize':False,'input_sha256':hashlib.sha256(item['narration_text'].encode('utf-8')).hexdigest()}
  req={'jsonrpc':'2.0','id':i,'method':'tools/call','params':{'name':'fish_audio_tts','arguments':args}}
  r=subprocess.run(['node',str(HELPER)],input=json.dumps(req,ensure_ascii=False)+'\n',capture_output=True,text=True,env=env,timeout=240,check=True)
  response=json.loads(r.stdout.splitlines()[-1]); body=response.get('result',{})
  if body.get('isError'): raise RuntimeError('Fish Audio rejected scene '+str(i))
  d=json.loads(body['content'][0]['text'])
  if not d.get('success') or not path.exists() or path.stat().st_size==0: raise RuntimeError('No audio for scene '+str(i))
  records[i]={'scene':i,'path':path.relative_to(P).as_posix(),'bytes':path.stat().st_size,'model_requested_accepted_alias':d.get('model'),'model_backend_attestation':'not independently provided','reference_id':d.get('reference_id'),'temperature':d.get('temperature'),'top_p':d.get('top_p'),'speed':d.get('speed'),'normalize':False,'input_sha256':hashlib.sha256(item['narration_text'].encode('utf-8')).hexdigest()}
  print(json.dumps({'scene':i,'bytes':path.stat().st_size,'model':d.get('model'),'normalize':False,'input_sha256':hashlib.sha256(item['narration_text'].encode('utf-8')).hexdigest()},ensure_ascii=False),flush=True)
 for item in data:
  records[item['scene']]['input_sha256']=hashlib.sha256(item['narration_text'].encode('utf-8')).hexdigest()
 (P/'assets/audio/voice-manifest.json').write_text(json.dumps([records[i] for i in sorted(records)],ensure_ascii=False,indent=2)+'\n',encoding='utf8')
if __name__=='__main__': main()
