#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
DUR="$(python3 -c 'import json;print(float(json.load(open("assets/audio/voice-timing.json"))["program_duration_s"]))')"
FADE="$(python3 -c 'import json;d=float(json.load(open("assets/audio/voice-timing.json"))["program_duration_s"]);print(max(0,d-5))')"
python3 scripts/generate_opening_sfx.py
ffmpeg -y -hide_banner -loglevel error -i assets/audio/music-original.wav -i assets/audio/narration-consolidated.wav -i assets/audio/newsprint-sfx.wav \
  -filter_complex "[0:a]atrim=0:${DUR},asetpts=PTS-STARTPTS,volume=0.22,afade=t=out:st=${FADE}:d=5[bed];[1:a]apad=whole_dur=${DUR},atrim=0:${DUR},asetpts=PTS-STARTPTS,asplit=2[voice][sc];[bed][sc]sidechaincompress=threshold=0.018:ratio=5:attack=80:release=520:makeup=1[duck];[duck][voice]amix=inputs=2:duration=longest:normalize=0[base];[2:a]adelay=0|0,volume=1[sfx];[base][sfx]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.89:attack=5:release=60[out]" \
  -map '[out]' -t "$DUR" -ar 48000 -ac 2 -c:a pcm_s16le assets/audio/final-mix.wav
python3 scripts/normalize_master.py assets/audio/final-mix.wav assets/audio/final-mix-normalized.wav
