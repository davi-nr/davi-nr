#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, wave
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; AUDIO=ROOT/'assets/audio'; SCENES=AUDIO/'scenes'
RATE=48000; CHANNELS=2; WIDTH=2; GAP=.30; HOLD=5.0
spans=[]; cursor=0.0
OUT=AUDIO/'narration-consolidated.wav'
with wave.open(str(OUT),'wb') as w:
 w.setnchannels(CHANNELS);w.setsampwidth(WIDTH);w.setframerate(RATE)
 for i in range(1,9):
  f=SCENES/f'{i:02d}-scene.mp3'
  raw=subprocess.run(['ffmpeg','-v','error','-i',str(f),'-f','s16le','-acodec','pcm_s16le','-ar',str(RATE),'-ac',str(CHANNELS),'-'],stdout=subprocess.PIPE,check=True).stdout
  dur=len(raw)/(RATE*CHANNELS*WIDTH)
  if i>1:
   n=round(GAP*RATE)*CHANNELS*WIDTH;w.writeframes(b'\0'*n);cursor+=GAP
  start=cursor;w.writeframes(raw);cursor+=dur
  spans.append({'scene':i,'voice_start_s':round(start,6),'voice_end_s':round(cursor,6),'duration_s':round(dur,6)})
program=cursor+HOLD
(AUDIO/'voice-timing.json').write_text(json.dumps({'scenes':spans,'inter_scene_gap_s':GAP,'voice_end_s':round(cursor,6),'program_hold_s':HOLD,'program_duration_s':round(program,6)},indent=2)+'\n')
print(json.dumps({'voice_end_s':cursor,'program_duration_s':program,'scenes':spans},indent=2))
