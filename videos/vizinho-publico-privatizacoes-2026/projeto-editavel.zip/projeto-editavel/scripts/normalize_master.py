#!/usr/bin/env python3
"""Two-pass EBU R128 normalization for the edit's final WAV master."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path


def run(args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)


def stats(stderr: str) -> dict[str, str]:
    matches = re.findall(r"\{\s*\"input_i\".*?\n\}", stderr, re.S)
    if not matches:
        raise RuntimeError("FFmpeg loudnorm did not return measurement JSON")
    return json.loads(matches[-1])


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: python3 scripts/normalize_master.py INPUT.wav OUTPUT.wav")
    ffmpeg = os.environ.get("FFMPEG") or shutil.which("ffmpeg")
    if not ffmpeg:
        raise SystemExit("ffmpeg was not found")
    source = Path(sys.argv[1]).resolve()
    destination = Path(sys.argv[2]).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.stem + ".tmp" + destination.suffix)
    first = run([
        ffmpeg, "-hide_banner", "-i", str(source), "-af",
        "loudnorm=I=-16:LRA=7:TP=-1:print_format=json", "-f", "null", "-",
    ])
    measured = stats(first.stderr)
    values = {key: measured[key] for key in ("input_i", "input_lra", "input_tp", "input_thresh", "target_offset")}
    filt = (
        "loudnorm=I=-16:LRA=7:TP=-1:"
        f"measured_I={values['input_i']}:measured_LRA={values['input_lra']}:"
        f"measured_TP={values['input_tp']}:measured_thresh={values['input_thresh']}:"
        f"offset={values['target_offset']}:linear=true:print_format=json"
    )
    second = run([
        ffmpeg, "-hide_banner", "-y", "-i", str(source), "-af", filt,
        "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", str(temporary),
    ])
    out = stats(second.stderr)
    out_i, out_tp = float(out["output_i"]), float(out["output_tp"])
    if abs(out_i + 16.0) > 0.2 or out_tp > -0.9:
        temporary.unlink(missing_ok=True)
        raise SystemExit(f"Normalized master missed target: {out_i:.2f} LUFS, {out_tp:.2f} dBTP")
    temporary.replace(destination)
    print(f"Wrote {destination}: {out_i:.2f} LUFS, LRA {float(out['output_lra']):.2f} LU, TP {out_tp:.2f} dBTP")


if __name__ == "__main__":
    main()
