# Notas do pacote distribuído

O HTML integral da republicação UOL/Agência Brasil foi preservado no projeto de origem para verificação, mas não é redistribuído neste pacote. `research/NEWS-HEADLINE-VERIFIED.json` registra a manchete, a data, a URL e o uso editorial; `FACTS.md` traz a fonte contábil primária dos números. O vídeo usa cartão editorial próprio com a manchete real atribuída.

Os áudios WAV foram compactados sem perda em FLAC. Execute `python3 scripts/restore_audio.py` antes de conferir ou renderizar. A restauração é validada pelo hash do PCM em `AUDIO-LOSSLESS-MANIFEST.json`; os takes MP3 originais também estão incluídos.
