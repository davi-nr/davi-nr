# Media research — “Por que pagamos impostos?”

All four files below are original, real photographs downloaded from their Wikimedia Commons file pages. I visually inspected the local originals. Their licenses and credits are stated on the individual Commons file pages; retain attribution and identify crops or other modifications where required.

## Recommended assets

### 1. Public school — Escola Municipal Leonel de Moura Brizola, Sorriso (MT)

- Local original: `escola-municipal-leonel-sorriso.jpg` — 5152 × 3864 px.
- Commons file page: https://commons.wikimedia.org/wiki/File:Escola_Municipal_Leonel_de_Moura_Brizola_(Sorriso,_Brasil).jpg
- Artist: Eugenio Hansen, OFS. Captured 17 June 2017. License: CC BY-SA 4.0 — https://creativecommons.org/licenses/by-sa/4.0
- Institutional identity check: Prefeitura Municipal de Sorriso’s official school unit page, https://site.sorriso.mt.gov.br/unidade/12/escola-municipal-leonel-de-moura-brizola, lists “Escola Municipal Leonel de Moura Brizola” under government units, with school contact and address (Rua Santiago, 155, Jardim das Américas). This ties the named school in the photograph to a municipal school; do not generalize its appearance to every public school.
- Visual note: facade signage makes the school identifiable. Use as a documentary example of a specific municipal school, without claims about maintenance or student experience.
- Suggested credit: “Eugenio Hansen, OFS / Wikimedia Commons, CC BY-SA 4.0” (link file page and license; indicate crop if used).

### 2. Public/SUS hospital — Hospital Municipal Dr. Mário Gatti, Campinas (SP)

- Local original: `hospital-municipal-mario-gatti.jpg` — 4896 × 2752 px.
- Commons file page: https://commons.wikimedia.org/wiki/File:Hospital_Municipal_M%C3%A1rio_Gatti.jpg
- Artist: Raphael Henrique Figueira. Captured 29 November 2016. License: CC BY-SA 4.0 — https://creativecommons.org/licenses/by-sa/4.0
- Institutional/operator and SUS check: Ministry of Health/DATASUS CNES record, https://cnes2.datasus.gov.br/cabecalho_reduzido.asp?VCod_Unidade=3509502081490 . Its record names “HOSPITAL MUNICIPAL DR MARIO GATTI CAMPINAS”; names the business entity as “REDE MUNICIPAL DR MARIO GATTI DE URGENCIA EMERGENCIA E HOS…” (field display is truncated in the page); classifies the unit as “HOSPITAL GERAL MUNICIPAL”; and lists “AMBULATORIAL SUS”, “INTERNACAO SUS”, “SADT SUS” and “URGENCIA SUS”. The CNES record’s last update is 8 October 2026.
- Visual note: identifiable facade, no queue or condition claim. Use only as a named example of a municipal SUS hospital.
- Suggested credit: “Raphael Henrique Figueira / Wikimedia Commons, CC BY-SA 4.0” (link file page and license; indicate crop if used).

### 3. City panorama — Rio de Janeiro (cover option)

- Local original: `rio-de-janeiro-panorama.jpg` — 13,526 × 5,520 px.
- Commons file page: https://commons.wikimedia.org/wiki/File:Panoramic_view_of_Rio_de_Janeiro.jpg
- Artist: Wilfredor. Captured 22 June 2024. License: CC0 — https://creativecommons.org/publicdomain/zero/1.0/
- Commons description identifies Rio, Guanabara Bay, and Sugarloaf Mountain. The high-resolution panoramic provides abundant detail for a vertical crop/pan; the Sugarloaf and bay make the location recognizable. Attribution is not required under CC0, though credit is welcome.

### 4. Optional emergency-service image — CBMDF vehicle handover, Brasília (DF)

- Local original: `bombeiros-df-viaturas-2015.jpg` — 3543 × 2353 px.
- Commons file page: https://commons.wikimedia.org/wiki/File:Bombeiros_ganham_nove_viaturas_especiais_(16962745590).jpg
- Source/photographer: Agência Brasília; source caption credits Andre Borges/Agência Brasília. Captured 14 April 2015 at the Military Firefighters Academy in Brasília. License: CC BY 2.0 — https://creativecommons.org/licenses/by/2.0
- Caption on Commons states that the Distrito Federal Military Fire Department received nine new specialized vehicles intended for operational incidents and community response. It is a dated delivery event, not evidence of the current fleet or a current service level. The frame includes public officials at the ceremony, so it is less neutral than the three main assets; use only if an archival procurement moment adds value, and date-label it.
- Suggested credit: “Andre Borges/Agência Brasília, CC BY 2.0, via Wikimedia Commons” (link file page and license; indicate crop if used).

## Provenance and use

The Commons files establish author, capture date, file resolution, and license. The school’s official municipal unit directory and the hospital’s official CNES record separately establish public-service identity/operator; do not rely on image captions alone for those claims. No synthetic images were created. No repository or prior video files were changed.
