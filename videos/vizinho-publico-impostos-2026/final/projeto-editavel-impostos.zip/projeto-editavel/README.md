# Vizinho Público — Por que pagamos impostos?

Projeto HyperFrames 0.8.147, 1080 × 1920, 30 fps. `index.html` é a composição completa. A abertura conversacional de 22 segundos é um clipe silencioso H.264 seekable (`assets/video/opening-conversacional-v6-seekable.mp4`) mais nove takes Fish separados; a versão v6 original e a composição editável da prévia estão preservadas em `revision-opening/preview-conversacional-v1/`.

## Reproduzir e renderizar

Requisitos: Node.js, FFmpeg/ffprobe, Chromium instalado pelo runtime HyperFrames e plugin HyperFrames 0.8.147. O projeto não tem dependências próprias instaláveis por `npm ci`; os scripts do `package.json` apontam para o plugin desta instalação.

```bash
npm run check
npm_config_cache=/tmp/hf-npm-cache node /run/codex-environment/codex-home/plugins/cache/hyperframes/hyperframes/0.8.147/skills/hyperframes/scripts/plugin-cli.mjs render . --output deliverables/vizinho-impostos-master-hyperframes.mp4 --fps 30 --quality delivery --low-memory-mode --experimental-fast-capture=false --workers 1
```

O render final foi feito por captura fiel de screenshot, com low-memory e um worker. A versão de distribuição recodifica o vídeo em H.264 High@4.1 e normaliza o áudio (alvo −16 LUFS; true peak −1,5 dBTP antes do AAC) pelo script reproduzível:

```bash
bash scripts/export_distribution.sh deliverables/vizinho-impostos-master-hyperframes.mp4 deliverables/vizinho-impostos-final.mp4
```

O gate automático de amostragem de motion não está habilitado nesta execução; a direção e os movimentos devem ser conferidos nos quadros extraídos do MP4 exportado. O CLI não conseguiu inicializar a gravação de histórico porque seu caminho de cache padrão fica fora das raízes graváveis do ambiente; nenhuma pasta de histórico foi criada fora do workspace.

## Áudio e sincronização

A abertura usa os nove arquivos em `assets/audio/opening/`, descritos em `assets/audio/opening/voice-manifest-v6.json` junto com hashes, texto, configurações e tempos. As cenas 2–12 usam os takes em `assets/audio/scenes/`, listados em `assets/audio/voice-manifest.json`. `assets/audio/voice-manifest-full.json` reúne ambos os grupos. O modelo pedido/aceito pela API foi o alias `s2.1-pro-free`; a resposta não forneceu atestação independente do backend.

`deliverables/narration-full-aligned.wav` é a narração consolidada sem música. `assets/audio/music-full.wav` é a trilha separada usada no render: deriva de `music-original.wav` com pequena compensação de tempo sem mudança de pitch para cobrir toda a duração e manter o fade final. O arquivo original permanece intacto. As faixas, o ducking e a cronologia completa estão declarados em `index.html`, `scripts/build_full_composition.py` e `TIMELINE.json`.

## Materiais

- `SCRIPT.md`, `STORYBOARD.md`, `FACTS.md` e `AUDIT-REPORT.md`: roteiro, cenas, metodologia e auditoria.
- `CAPTION.md`, `LEGENDA-INSTAGRAM.txt` e `ASSET-ATTRIBUTIONS.md`: texto de publicação e créditos/licenças.
- `deliverables/captions.srt` e `deliverables/captions.json`: legendas com tempos do programa.
- `deliverables/narration-full-aligned.wav`: voz consolidada.
- `assets/audio/opening/` e `assets/audio/scenes/`: takes individuais e manifestos.
- `assets/audio/music-original.wav` e `assets/audio/music-full.wav`: trilha fonte e versão usada.
- `compositions/cover.html` e `deliverables/capa-instagram.jpg`: capa editável e exportada.
- `assets/research/`: legislação, relatórios, cálculo e verificação das fontes citadas.
