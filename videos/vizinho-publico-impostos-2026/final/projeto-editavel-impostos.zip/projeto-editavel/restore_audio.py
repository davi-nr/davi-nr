from pathlib import Path
import hashlib, json, subprocess, wave
root=Path(__file__).resolve().parent
for r in json.loads((root/'AUDIO-RESTORE-MANIFEST.json').read_text()):
    target=root/r['wav']
    codec={1:'pcm_u8',2:'pcm_s16le',3:'pcm_s24le',4:'pcm_s32le'}[r['width']]
    subprocess.run(['ffmpeg','-v','error','-i',str(root/r['flac']),'-c:a',codec,'-y',str(target)],check=True)
    with wave.open(str(target),'rb') as w:
        assert (w.getnchannels(),w.getframerate(),w.getsampwidth(),w.getnframes()) == (r['channels'],r['rate'],r['width'],r['frames'])
        assert hashlib.sha256(w.readframes(w.getnframes())).hexdigest() == r['pcm_sha256']
    print('Audio restaurado e verificado:',r['wav'])
