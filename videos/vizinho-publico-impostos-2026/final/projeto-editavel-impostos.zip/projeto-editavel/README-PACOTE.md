# Projeto editável — Por que pagamos impostos?

Produção dirigida pelo subagente HyperFrames. `index.html` é o episódio completo; capa editável em `compositions/cover.html`. As versões anteriores permanecem preservadas no ambiente de origem.

Requisitos: Node.js 20+, npm, Python 3 e FFmpeg/ffprobe. Antes de abrir a composição, execute `python3 restore_audio.py` nesta pasta: os WAV foram compactados em FLAC sem perdas, e a restauração verifica frames e SHA256 do conteúdo PCM. Em seguida use `npm run preview`, `npm run check` e `npm run render` com o CLI fixado HyperFrames 0.8.147. A reprodução pode baixar o CLI/Chromium quando ausentes; use captura fiel com um worker e `--experimental-fast-capture=false`.

As falas e a música já acompanham o projeto; nenhuma chave API é necessária para renderizá-las. O helper de voz deste pacote foi adaptado para ler FISH_API_KEY do ambiente seguro: `scripts/generate_voice.py` regenera as cenas 2–12 por padrão. A abertura utiliza nove takes separados, descritos em `assets/audio/opening/voice-manifest-v6.json`; não execute o antigo helper de abertura técnica, excluído deste pacote. Nenhuma credencial acompanha o arquivo.

Se editar a locução, reconstrua a timeline, rode check e repita a auditoria. As medições loudnorm de `scripts/export_distribution.sh` correspondem ao master entregue; recalcule-as antes de normalizar um novo master com conteúdo alterado.

Consulte SCRIPT.md, STORYBOARD.md, FACTS.md, ASSET-ATTRIBUTIONS.md e o relatório de auditoria para narração, fontes, períodos, direitos de uso e limites das verificações. As transcrições e os medidores automáticos não são apresentados como audição humana da narração.
