# VIZINHO PÚBLICO — DOCUMENTÁRIO

## POR QUE PAGAMOS IMPOSTOS?

MISSÃO

Codex, acione efetivamente o subagente HyperFrames e produza um documentário editorial animado para o perfil @vizinhopublico.

O objetivo é explicar por que os impostos existem, como são cobrados no Brasil, o que financiam, por que pagamos tributos em diferentes situações e como a população pode fiscalizar o uso do dinheiro público.

O vídeo deve ser acessível, investigativo, visualmente sofisticado e fundamentado em fontes oficiais.

Não produzir propaganda a favor ou contra governos.

Não tratar todos os tributos como impostos: diferenciar impostos, taxas e contribuições quando necessário.

### 1. ORQUESTRAÇÃO

* HyperFrames deve comandar a produção audiovisual completa.
* Remotion será utilizado apenas como ferramenta subordinada, quando adequado.
* Pesquisar fontes oficiais e exemplos reais.
* Produzir roteiro, storyboard, narração, animações, música, mixagem e renderização.
* Reaproveitar a identidade visual aprovada do Vizinho Público.
* Preservar os projetos anteriores.
* Não impor limites artificiais de tokens ou revisões.

### 2. CONFIGURAÇÕES

* Duração máxima absoluta: 3 minutos.
* Duração ideal: 2 minutos e 50 segundos.
* Resolução: 1080 × 1920.
* Formato: vertical 9:16.
* Estilo: motion design editorial 2D.
* Narração: Fish Audio S2.1 Pro Free.
* Voz: Mulher do Criativo top.
* Reference ID: ceaf7f569bef42c7bd322d88e3a356b7.
* Temperature: 0.85.
* Top P: 0.85.
* Speed: 1.0.
* Trilha instrumental documental incorporada ao MP4.
* Ducking automático durante a narração.

### 3. ABERTURA — 0 A 20 SEGUNDOS

Mostrar uma sequência animada:

Uma pessoa recebe o salário.

Compra pão.

Abastece o carro.

Paga a conta de luz.

Em cada operação, destacar discretamente os tributos envolvidos, sem inventar percentuais.

Narração sugerida:

“Você trabalha, recebe seu salário e paga imposto.

Depois vai ao supermercado… e paga imposto de novo.

Abastece o carro… mais imposto.

Mas espera aí…”

[Pausa expressiva.]

“Por que a gente paga imposto tantas vezes?”

[Pausa.]

“E para onde vai todo esse dinheiro?”

A entonação deve ser genuinamente interrogativa, com curiosidade e variação natural.

Não confiar apenas no ponto de interrogação: gerar e ouvir versões alternativas da narração.

### 4. CENA 2 — POR QUE OS IMPOSTOS EXISTEM?

20–43 segundos

Mostrar uma cidade animada sendo construída.

Surgem:

* Escolas.
* Hospitais.
* Ruas.
* Iluminação pública.
* Bombeiros.
* Segurança.
* Serviços administrativos.

Explicar que tributos são uma das principais formas de financiar o funcionamento do Estado e políticas públicas.

Evitar sugerir que cada imposto é automaticamente destinado a um serviço específico.

### 5. CENA 3 — POR QUE PAGAMOS VÁRIOS TRIBUTOS?

43–68 segundos

Mostrar três categorias:

Renda: tributação sobre rendimentos.

Consumo: tributação sobre bens e serviços.

Patrimônio: tributação sobre propriedades.

Exemplificar com imposto de renda, tributos sobre compras, IPTU e IPVA.

Esclarecer que nem todas as pessoas pagam imposto de renda e que diferentes tributos têm regras próprias.

Explicar de maneira simples a diferença entre tributos diretos e indiretos.

### 6. CENA 4 — QUEM RECEBE O DINHEIRO?

68–92 segundos

Mostrar mapa do Brasil dividido em:

* União.
* Estados.
* Municípios.

Explicar que diferentes entes arrecadam tributos e que também existem transferências constitucionais e legais entre eles.

Não sugerir que toda a arrecadação vai para Brasília.

### 7. CENA 5 — PARA ONDE VAI?

92–120 segundos

Mostrar um orçamento público animado, com categorias como:

* Saúde.
* Educação.
* Previdência.
* Segurança.
* Infraestrutura.
* Assistência social.
* Despesas administrativas.
* Encargos da dívida.

Usar dados oficiais recentes e identificar claramente se são federais ou consolidados entre União, estados e municípios.

Não inventar percentuais.

Não confundir pagamento de juros, amortização e refinanciamento da dívida.

### 8. CENA 6 — POR QUE NEM SEMPRE SENTIMOS O RETORNO?

120–145 segundos

Mostrar:

Uma escola bem conservada.

Outra precisando de manutenção.

Um hospital equipado.

Uma fila de atendimento.

Explicar que arrecadar recursos não garante automaticamente qualidade dos serviços.

Os resultados dependem de planejamento, orçamento, prioridades, execução, fiscalização e capacidade administrativa.

Distinguir problemas documentados de exemplos ilustrativos.

### 9. CENA 7 — QUEM PAGA PROPORCIONALMENTE MAIS?

145–162 segundos

Explicar brevemente a diferença entre carga tributária total e peso dos tributos no orçamento familiar.

Apresentar o conceito de regressividade da tributação sobre o consumo, utilizando estudos oficiais ou acadêmicos.

Não inventar comparações numéricas.

Se pertinente, mencionar que o Brasil está em transição para um novo modelo de tributação do consumo, com IBS e CBS.

Não afirmar que a transição já terminou.

### 10. CONCLUSÃO — 162 A 175 SEGUNDOS

Narração sugerida:

“Os impostos ajudam a financiar serviços que usamos individualmente e outros que beneficiam a sociedade inteira.”

“Mas pagar imposto também nos dá um motivo para perguntar como o dinheiro público está sendo utilizado.”

“Porque a discussão não é apenas quanto o governo arrecada. É o que a população recebe, quem paga mais e como cada real é administrado.”

“Siga @vizinhopublico.”

Encerrar com assinatura animada.

### 11. MATERIAL DOCUMENTAL

Utilizar fotografias reais, quando pertinentes, de:

* Escolas públicas.
* Hospitais do SUS.
* Obras de infraestrutura.
* Serviços de segurança e emergência.
* Congresso Nacional.
* Receita Federal.
* Serviços municipais.

Pesquisar notícias autênticas sobre arrecadação, orçamento, qualidade dos serviços e reforma tributária.

Usar prints reais com veículo, título e data identificáveis, quando os direitos de uso permitirem.

Não fabricar manchetes ou documentos.

Não usar fotografias sintéticas como se fossem registros reais.

### 12. MÚSICA E NARRAÇÃO

Produzir uma trilha instrumental documental discreta, com piano suave, texturas atmosféricas e percussão leve.

A música deve estar incorporada ao vídeo desde a primeira renderização.

Aplicar ducking automático.

Normalizar siglas, números e abreviações para o Fish Audio.

Separar narration_text de display_text.

Ouvir integralmente a narração e corrigir perguntas sem entonação, pronúncias inadequadas e pausas artificiais.

### 13. VERIFICAÇÃO FACTUAL

Priorizar:

* Receita Federal.
* Tesouro Nacional.
* Portal da Transparência.
* Constituição Federal.
* Leis orçamentárias.
* IBGE.
* Ipea.
* Fontes oficiais sobre a reforma tributária.

Verificar as regras tributárias vigentes em outubro de 2026.

Registrar fontes em FACTS.md.

Distinguir dados de arrecadação de dados de despesas e identificar os respectivos períodos.

### 14. IDENTIDADE E CAPA

Título obrigatório:

POR QUE PAGAMOS IMPOSTOS?

Criar uma capa com nota fiscal, dinheiro e uma cidade brasileira ao fundo.

Utilizar tipografia editorial forte, legível na grade do Instagram.

Não incluir expressões promocionais sobre inteligência artificial ou ferramentas de geração.

Cumprir eventuais obrigações de transparência das plataformas.

### 15. AUDITORIA E ENTREGA

Entregar:

1. MP4 final em 1080 × 1920, com música incorporada.
2. Projeto editável.
3. Roteiro final.
4. Storyboard.
5. FACTS.md.
6. Fontes das fotografias e notícias.
7. Trilha instrumental separada.
8. Capa vertical.
9. Legenda para Instagram com no máximo cinco hashtags.

Primeiro produzir e escutar uma prévia de 20 segundos da abertura, verificando a entonação das perguntas. Depois finalizar o vídeo.

Duração máxima absoluta: três minutos.

Não cortar a conclusão para adequar a duração.

EXECUTE A PRODUÇÃO COMPLETA COM O HYPERFRAMES.
