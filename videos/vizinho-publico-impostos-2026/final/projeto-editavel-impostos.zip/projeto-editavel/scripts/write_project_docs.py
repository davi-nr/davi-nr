#!/usr/bin/env python3
"""Generate the reader script and timing storyboard from the current source data."""
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'SCENE-DATA.json').read_text())
timeline=json.loads((root/'TIMELINE.json').read_text())
starts=timeline['scene_starts']; lengths=timeline['voice_durations']
def span(a,b):
    def f(x):
        m=round(x*1000); return f'{m//60000:02d}:{(m%60000)//1000:02d}.{m%1000:03d}'
    return f'{f(a)}–{f(b)}'
script=['# Roteiro integral — Por que pagamos impostos?','', 'Texto narrado conforme os doze arquivos de voz atuais. A redação de tela está em `SCENE-DATA.json`.','']
for d in data:
    script += [f"## Cena {d['scene']:02d} — {d['title']}",'',d['narration_text'],'']
(root/'SCRIPT.md').write_text('\n'.join(script),encoding='utf-8')
story=['# Storyboard — Por que pagamos impostos?','',f"Duração prevista pela soma das faixas e holds: {timeline['duration_seconds']:.3f} s a 30 fps. Confirmar a duração do MP4 exportado.",'']
for d,start,dur in zip(data,starts,lengths):
    voice_end=start+dur
    scene_end=20.0 if d['scene']==1 else (timeline['duration_seconds'] if d['scene']==12 else voice_end)
    displays=' · '.join(d['display_text'])
    story += [f"## Cena {d['scene']:02d} · {span(start,scene_end)}",'',f"**Fala:** {d['narration_text']}",'',f'**Tela:** {displays}','',f"**Direção:** {d['visual_notes']}",'',f'**Voz:** {span(start,voice_end)}','']
(root/'STORYBOARD.md').write_text('\n'.join(story),encoding='utf-8')
