#!/usr/bin/env bash
set -euo pipefail

src=${1:-deliverables/vizinho-impostos-master-hyperframes.mp4}
dst=${2:-deliverables/vizinho-impostos-final.mp4}
if [[ ! -f "$src" ]]; then
  echo "Master não encontrado: $src" >&2
  exit 2
fi
mkdir -p "$(dirname "$dst")"

# Loudnorm analysis recorded from the immutable HyperFrames master:
# I=-19.00 LUFS, TP=-1.86 dBTP, LRA=3.90 LU, threshold=-29.38 LUFS.
# Target gives AAC headroom below -1 dBTP after decoding.
ffmpeg -hide_banner -y -i "$src" -map 0:v:0 -map 0:a:0 \
  -c:v libx264 -preset medium -crf 20 -profile:v high -level:v 4.1 \
  -pix_fmt yuv420p -x264-params 'keyint=60:min-keyint=30:scenecut=40' \
  -vf format=yuv420p -c:a aac -b:a 192k -ar 48000 \
  -af 'loudnorm=I=-16:LRA=11:TP=-1.5:measured_I=-19.00:measured_TP=-1.86:measured_LRA=3.90:measured_thresh=-29.38:offset=-0.23:linear=true' \
  -movflags +faststart -shortest "$dst"
