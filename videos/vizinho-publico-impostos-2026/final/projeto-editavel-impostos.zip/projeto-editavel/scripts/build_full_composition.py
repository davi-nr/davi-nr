#!/usr/bin/env python3
"""Build the editable full-length HyperFrames HTML from the verified scene data."""
import json, subprocess, re, html
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DATA=json.loads((ROOT/'SCENE-DATA.json').read_text())
OPENING_SECONDS=22.0
OPENING_DIR=ROOT/'revision-opening/preview-conversacional-v1'
OPENING_VIDEO='assets/video/opening-conversacional-v6-seekable.mp4'
OPENING_TIMING=json.loads((ROOT/'assets/audio/opening/audio-timing-v2.json').read_text())['A']
GAP=.15
HOLDS={}
END_HOLD=1.7
def duration(path):
    return float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(path)],text=True).strip())

starts=[]; lengths=[]; cursor=0.0
for i,item in enumerate(DATA):
    if i==0: start=0.0
    elif i==1: start=OPENING_SECONDS
    else: start=cursor+GAP
    d=OPENING_SECONDS if i==0 else duration(ROOT/'assets/audio/scenes'/f"{item['scene']:02d}-scene.mp3")
    starts.append(start); lengths.append(d)
    cursor=start+d+HOLDS.get(item['scene'],0)
program=cursor+END_HOLD
timeline_doc={'fps':30,'duration_seconds':round(program,3),'opening_visual_seconds':OPENING_SECONDS,'opening_speech_end_seconds':OPENING_TIMING['speech_end_seconds'],'opening_voice_starts_seconds':OPENING_TIMING['starts_seconds'],'opening_voice_durations_seconds':OPENING_TIMING['durations_seconds'],'scene_starts':starts,'scene_slot_durations':lengths,'body_voice_durations_seconds':lengths[1:],'holds_after_scene':HOLDS,'endcard_hold':END_HOLD,'note':'scene_slot_durations[0] is the 22-second visual clip slot; opening speech is represented by nine takes and ends earlier.'}
(ROOT/'TIMELINE.json').write_text(json.dumps(timeline_doc,ensure_ascii=False,indent=2)+'\n')

def esc(s): return html.escape(s,quote=True)
def svg(kind):
    icons={
    'salary':'<circle cx="27" cy="18" r="9"/><path d="M10 50c2-13 8-20 17-20s15 7 17 20M8 52h39"/><rect x="47" y="34" width="17" height="21" rx="2"/><path d="M51 40h9m-9 5h9m-9 5h6"/>',
    'bread':'<path d="M8 39c0-13 10-23 24-23s24 10 24 23v9H8z"/><path d="M15 39c5-5 11-5 16 0m5 0c5-5 11-5 16 0M14 52h36"/>',
    'fuel':'<path d="M15 55V10h27v45M11 55h38M20 18h17v15H20zM42 20h7l7 8v21a5 5 0 0 1-10 0V35"/>',
    'light':'<path d="M14 8h28l9 9v39H14zM42 8v11h9M22 29h20M22 37h20M22 45h10"/><path d="m34 22-6 10h7l-5 10 12-14h-8z"/>',
    'school':'<path d="M8 27 32 12l24 15M14 26v29h36V26M22 55V38h20v17M22 31h4m12 0h4"/>',
    'health':'<path d="M12 14h40v40H12zM32 22v24M20 34h24"/>',
    'home':'<path d="M8 30 32 10l24 20M15 27v28h34V27M26 55V38h12v17"/>',
    'car':'<path d="M8 42h48l-5-16H18zM13 42v9h6m32-9v9h-6M19 51h-6m32 0h6M20 26l4-9h16l5 9"/>',
    'coin':'<circle cx="32" cy="32" r="23"/><path d="M39 23c-2-3-5-4-9-4-5 0-8 2-8 6 0 10 19 4 19 14 0 4-4 7-10 7-5 0-9-2-11-6M32 14v36"/>',
    'city':'<path d="M8 55V30h13v25M22 55V18h18v37M41 55V27h15v28M5 55h54M27 26h4m5 0h-1m-8 7h4m5 0h4m-9 8h4m5 0h3"/>'}
    return f'<svg viewBox="0 0 64 64" aria-hidden="true">{icons[kind]}</svg>'

# Each composition has a distinct visual grammar; captions remain in a fixed mobile-safe band.
SCENE_HTML=[]
SCENE_HTML.append(f'''<section class="scene scene01 opening-container" id="s01"><video id="opening-conversacional-v6" class="clip opening-video" src="{OPENING_VIDEO}" muted playsinline data-start="0" data-duration="{OPENING_SECONDS:.3f}" data-width="1080" data-height="1920" aria-label="Abertura conversacional v6, cenas ilustrativas 2D sobre salário, compras, combustível, luz e impostos"></video></section>''')

SCENE_HTML.append(f'''<section class="scene scene02" id="s02"><div class="topline"><span class="brand">VIZINHO PÚBLICO</span><span>02 · ORÇAMENTO</span></div><div class="kicker">UM CAMINHO COLETIVO</div><h1>POR QUE OS TRIBUTOS EXISTEM?</h1><p class="lede">Financiar o funcionamento do Estado e políticas públicas.</p><div class="flow-source reveal">TRIBUTOS</div><div class="flow-line line-a"></div><div class="flow-line line-b"></div><div class="flow-line line-c"></div><div class="flow-nodes">{''.join(f'<div class="flow-node reveal">{svg(k)}<b>{t}</b></div>' for k,t in [('school','ESCOLAS'),('health','SAÚDE'),('city','SERVIÇOS')])}</div><div class="note-card reveal">O orçamento não carimba automaticamente cada imposto para um serviço específico.</div></section>''')

SCENE_HTML.append(f'''<section class="scene scene03" id="s03"><div class="topline"><span class="brand">VIZINHO PÚBLICO</span><span>03 · CONCEITOS</span></div><div class="kicker">TRIBUTO É O NOME GERAL</div><h1>IMPOSTO NÃO É TODO TRIBUTO</h1><div class="three-cards">{''.join(f'<div class="type-card reveal"><div class="type-mark">{i:02}</div><h2>{title}</h2><p>{desc}</p></div>' for i,(title,desc) in enumerate([('IMPOSTO','Não corresponde a um serviço individual.'),('TAXA','Ligada a fiscalizações ou serviços específicos e divisíveis.'),('CONTRIBUIÇÃO','Tem finalidades previstas na Constituição, como previdência.')],1))}</div><div class="bottom-rule reveal">SEM ETIQUETA AUTOMÁTICA PARA CADA ESCOLA</div></section>''')

SCENE_HTML.append(f'''<section class="scene scene04" id="s04"><div class="topline"><span class="brand">VIZINHO PÚBLICO</span><span>04 · BASES</span></div><div class="kicker">AS REGRAS VARIAM</div><h1>TRIBUTOS EM BASES DIFERENTES</h1><div class="base-grid">{''.join(f'<div class="base-card reveal"><div class="base-icon">{svg(icon)}</div><div class="base-title">{title}</div><div class="base-examples">{examples}</div><div class="base-kind">{kind}</div></div>' for icon,title,examples,kind in [('salary','RENDA','IR','DIRETO'),('bread','CONSUMO','COMPRAS','INDIRETO'),('home','PATRIMÔNIO','IPTU · IPVA','DIRETO')])}</div><div class="note-card reveal">Nem todas as pessoas pagam imposto de renda.</div><div class="axis reveal"><span>RENDA / BENS</span><i></i><span>PREÇO DE BENS E SERVIÇOS</span></div></section>''')

SCENE_HTML.append(f'''<section class="scene scene05" id="s05"><div class="topline"><span class="brand">VIZINHO PÚBLICO</span><span>05 · FEDERAÇÃO</span></div><div class="kicker">QUEM ARRECADA?</div><h1>TRÊS NÍVEIS DE GOVERNO</h1><div class="federation">{''.join(f'<div class="fed-node reveal"><div class="fed-icon">{svg(k)}</div><div><b>{label}</b><small>COMPETÊNCIAS PRÓPRIAS</small></div><div class="fed-receipt">RECEITAS</div></div>' for k,label in [('city','UNIÃO'),('home','ESTADOS'),('school','MUNICÍPIOS')])}</div><div class="country-map reveal"><img src="assets/maps/brazil-outline.svg" alt="Contorno nacional do Brasil, sem divisão estadual"/><span>BRASIL</span></div><div class="transfer reveal"><span>TRANSFERÊNCIAS CONSTITUCIONAIS E LEGAIS</span><div class="transfer-line"></div><b>RECEITAS PRÓPRIAS + TRANSFERÊNCIAS</b></div><div class="bottom-rule reveal">O DINHEIRO NÃO VAI TODO PARA BRASÍLIA</div></section>''')

SCENE_HTML.append(f'''<section class="scene scene06" id="s06"><div class="topline"><span class="brand">VIZINHO PÚBLICO</span><span>06 · RECEITA FEDERAL</span></div><div class="kicker">CARGA TRIBUTÁRIA BRUTA · 2024</div><div class="big-number reveal">32,20<span>%</span></div><div class="percent-label reveal">DO PRODUTO INTERNO BRUTO</div><div class="ratio-track reveal"><div class="ratio-fill"></div><span>ARRECADAÇÃO TRIBUTÁRIA CONSOLIDADA</span></div><div class="method-card reveal"><b>O QUE SIGNIFICA?</b><p>Arrecadação dos três níveis de governo comparada à economia do país.</p></div><div class="caveat reveal">NÃO É ALÍQUOTA FAMILIAR<br>NEM MEDE O SERVIÇO RECEBIDO</div><div class="source-line">FONTE: RECEITA FEDERAL · CARGA TRIBUTÁRIA NO BRASIL 2024</div></section>''')

SCENE_HTML.append(f'''<section class="scene scene07" id="s07"><div class="topline"><span class="brand">VIZINHO PÚBLICO</span><span>07 · TESOURO NACIONAL</span></div><div class="kicker">UNIÃO · 2025 · R$ CORRENTES</div><h1>ONDE O GOVERNO CENTRAL PAGA</h1><div class="scope-label">PAGAMENTOS TOTAIS · DESPESAS PRIMÁRIAS<br>DESPESA PAGA + RESTOS A PAGAR PAGOS</div><div class="budget-bars">{''.join(f'<div class="budget-row reveal"><div class="budget-label">{name}</div><div class="bar-track"><div class="bar-fill" style="--w:{w}%"></div></div><div class="budget-value">{val}</div></div>' for name,val,w in [('SAÚDE','R$ 238 BI',21.6),('EDUCAÇÃO','R$ 169 BI',15.4),('PREVIDÊNCIA','R$ 1,1 TRI',100)])}</div><div class="budget-note reveal">EXEMPLOS DE UM RECORTE FEDERAL;<br>NÃO REPRESENTAM TODO O GASTO PÚBLICO.</div><div class="source-line">PAGAMENTO TOTAL · FUNÇÃO · EXERCÍCIO 2025</div></section>''')

SCENE_HTML.append(f'''<section class="scene scene08" id="s08"><div class="topline"><span class="brand">VIZINHO PÚBLICO</span><span>08 · DÍVIDA</span></div><div class="kicker">DESPESAS FINANCEIRAS</div><h1>TRÊS MOVIMENTOS DIFERENTES</h1><div class="debt-cards">{''.join(f'<div class="debt-card reveal"><div class="debt-num">{i:02}</div><h2>{title}</h2><p>{desc}</p><div class="debt-flow">{flow}</div></div>' for i,(title,desc,flow) in enumerate([('JUROS','Custo da dívida.','CUSTO'),('AMORTIZAÇÃO','Pagamento do principal.','PRINCIPAL ↓'),('REFINANCIAMENTO','Substitui uma dívida por outra.','DÍVIDA → DÍVIDA')],1))}</div><div class="warning reveal">NÃO SOME COMO SE FOSSE VERBA LIVRE PARA NOVOS SERVIÇOS</div></section>''')

SCENE_HTML.append(f'''<section class="scene scene09" id="s09"><div class="topline"><span class="brand">VIZINHO PÚBLICO</span><span>09 · SERVIÇOS</span></div><div class="kicker">ARRECADAR NÃO GARANTE QUALIDADE</div><h1>O QUE CHEGA ÀS PESSOAS?</h1><div class="photo-pair"><figure class="doc-photo reveal"><img class="camera" src="assets/images/escola-municipal-leonel-sorriso.jpg" alt="Escola municipal Leonel de Moura Brizola em Sorriso, registro documental de 2017"><figcaption>ESCOLA MUNICIPAL · SORRISO · 2017<br><small>EUGENIO HANSEN OFS · CC BY-SA 4.0</small></figcaption></figure><figure class="doc-photo reveal"><img class="camera" src="assets/images/hospital-municipal-mario-gatti.jpg" alt="Hospital Municipal Dr. Mário Gatti, Campinas, registro documental de 2016"><figcaption>HOSPITAL MUNICIPAL · CAMPINAS · 2016<br><small>RAPHAEL H. FIGUEIRA · CC BY-SA 4.0</small></figcaption></figure></div><div class="process-strip reveal"><span>PLANEJAMENTO</span><i>→</i><span>COMPRAS</span><i>→</i><span>EQUIPES</span><i>→</i><span>MANUTENÇÃO</span><i>→</i><span>FISCALIZAÇÃO</span></div><div class="photo-caveat reveal">FOTOS DOCUMENTAIS: NÃO MEDem SOZINHAS A QUALIDADE DOS SERVIÇOS NO PAÍS.</div><div class="source-line">FOTOS DOCUMENTAIS · DATAS E CRÉDITOS NA LEGENDA</div></section>''')

SCENE_HTML.append(f'''<section class="scene scene10" id="s10"><div class="topline"><span class="brand">VIZINHO PÚBLICO</span><span>10 · INCIDÊNCIA</span></div><div class="kicker">TRIBUTAÇÃO SOBRE O CONSUMO</div><h1>O PESO PODE SER DESIGUAL</h1><div class="basket-compare"><div class="basket reveal"><div class="income-label">MENOS RENDA DISPONÍVEL</div><div class="basket-art">{svg('bread')}</div><div class="same-price">MESMO PREÇO DA CESTA</div><b>COM MENOS RENDA, ELE PODE PESAR PROPORCIONALMENTE MAIS</b></div><div class="basket reveal"><div class="income-label">MAIS RENDA DISPONÍVEL</div><div class="basket-art">{svg('bread')}</div><div class="same-price">MESMO PREÇO DA CESTA</div><b>COM MAIS RENDA, O PESO PROPORCIONAL PODE SER MENOR</b></div></div><div class="illustration-tag">ESQUEMA EXPLICATIVO · SEM VALORES</div><div class="transition-panel reveal"><span>2026</span><i></i><span>IBS + CBS EM TRANSIÇÃO</span><i></i><span>MODELO ANTIGO AINDA NÃO FOI TOTALMENTE SUBSTITUÍDO</span></div><div class="source-line">RECEITA FEDERAL · CARGA TRIBUTÁRIA NO BRASIL 2024 · CF/88 E LC 214/2025</div></section>''')

SCENE_HTML.append(f'''<section class="scene scene11" id="s11"><div class="topline"><span class="brand">VIZINHO PÚBLICO</span><span>11 · TRANSPARÊNCIA</span></div><div class="kicker">COMO ACOMPANHAR</div><h1>SAIA DA PERGUNTA. ABRA OS DADOS.</h1><div class="portal-mock reveal"><div class="mock-title">FILTROS EDITORIAIS · NÃO É CAPTURA DE PORTAL</div><div class="mock-fields"><div>ÓRGÃO <b>▼</b></div><div>PERÍODO <b>▼</b></div></div><div class="mock-row"><span>EMPENHADO</span><i></i><b>VALOR RESERVADO</b></div><div class="mock-row"><span>PAGO</span><i></i><b>VALOR PAGO</b></div><div class="mock-row"><span>CONTRATOS</span><i></i><b>OBJETO · FORNECEDOR</b></div></div><div class="howto reveal"><div><b>01</b> Filtre por órgão e período.</div><div><b>02</b> Compare empenhado e pago.</div><div><b>03</b> Consulte contratos e execução.</div><div><b>04</b> Se faltar dado, peça acesso.</div></div><div class="access reveal">UNIÃO: PORTAL DA TRANSPARÊNCIA + FALA.BR<br>ESTADOS E MUNICÍPIOS: PORTAIS E CANAIS LOCAIS</div></section>''')

SCENE_HTML.append(f'''<section class="scene scene12" id="s12"><div class="topline"><span class="brand">VIZINHO PÚBLICO</span><span>12 · CONCLUSÃO</span></div><div class="end-city camera" role="img" aria-label="Panorama do Rio de Janeiro ao entardecer"></div><div class="end-shade"></div><div class="end-copy reveal"><div class="kicker">TRIBUTOS FINANCIAM SERVIÇOS E NECESSIDADES COLETIVAS</div><h1>PERGUNTAR TAMBÉM É<br>ACOMPANHAR.</h1><div class="end-questions"><span>O QUE CHEGA?</span><span>QUEM PAGA MAIS?</span><span>COMO CADA REAL É ADMINISTRADO?</span></div><div class="end-follow">SIGA <b>@VIZINHOPUBLICO</b></div></div></section>''')

def split_caption(text,maxchars=67):
    # Sentence-first, then a readable two-line maximum.
    sents=re.split(r'(?<=[.!?;])\s+',text.strip())
    chunks=[]
    for sent in sents:
        words=sent.split(); cur=[]
        for word in words:
            if cur and len(' '.join(cur+[word]))>maxchars:
                chunks.append(' '.join(cur));cur=[word]
            else:cur.append(word)
        if cur:chunks.append(' '.join(cur))
    return chunks

# Caption timing is allocated per scene proportional to word count, then refined by human-readable phrase boundaries.
caption_rows=[]
# Phrase-level cues use observed per-take ASR boundaries where available. The
# remaining scenes use sentence boundaries and preserve a two-line mobile cap.
manual_cues={
  1:[(.10,2.00,'No salário, pode haver imposto de renda,'),(2.15,3.50,'conforme a faixa e as regras.'),(3.68,5.08,'No pão, no combustível e na luz,'),(5.25,8.17,'tributos podem estar no preço.'),(8.55,10.22,'Mas por que pagamos impostos tantas vezes?'),(10.32,12.76,'E para onde vai esse dinheiro?')],
  2:[(.08,2.20,'Imposto é um tipo de tributo.'),(2.30,3.82,'Taxas e contribuições são outras.'),(3.92,6.20,'E nem todo salário paga imposto de renda.')],
  3:[(.05,4.65,'Tributo é o nome geral. Imposto não corresponde a um serviço individual.'),(4.75,9.50,'Taxas podem estar ligadas a fiscalizações ou a serviços específicos e divisíveis.'),(9.58,12.72,'Contribuições têm finalidades previstas na Constituição, como a previdência.'),(12.82,16.60,'Esses recursos financiam o Estado sem etiqueta automática para cada escola.')],
  4:[(.05,2.90,'Renda, consumo e patrimônio são bases distintas.'),(3.00,6.90,'Imposto de renda, compras, IPTU e IPVA são exemplos.'),(7.00,9.80,'Impostos diretos incidem sobre renda ou bens.'),(9.90,11.90,'Tributos sobre consumo podem aparecer no preço.'),(12.00,15.15,'As regras variam. Nem todas as pessoas pagam imposto de renda.')],
  5:[(.08,3.15,'União, estados e municípios têm competências para arrecadar.'),(3.25,5.60,'Também há transferências previstas em lei.'),(5.70,9.85,'Então, o dinheiro não vai todo para Brasília, nem as cidades dependem apenas da arrecadação.')],
  6:[(.05,4.45,'A Receita estimou a carga tributária bruta de dois mil e vinte e quatro'),(4.55,7.48,'em trinta e dois vírgula vinte por cento do produto interno bruto.'),(7.60,11.48,'A conta soma a arrecadação dos três níveis de governo e compara com a economia.'),(11.58,14.32,'Não é alíquota familiar nem mede o serviço recebido.')],
  7:[(.08,2.82,'No total de despesas primárias pagas pelo Governo Central em 2025,'),(2.92,5.42,'incluindo restos a pagar pagos:'),(5.52,8.86,'saúde somou cerca de duzentos e trinta e oito bilhões;'),(8.96,11.32,'educação, cento e sessenta e nove bilhões;'),(11.42,15.18,'previdência, um trilhão e cem bilhões.'),(15.28,17.62,'É um recorte federal, não todo o gasto público.')],
  8:[(.05,3.15,'O demonstrativo separa despesas primárias de financeiras.'),(3.25,4.78,'Juros são o custo da dívida.'),(4.88,6.62,'Amortização paga o principal.'),(6.72,9.22,'Refinanciamento substitui uma dívida por outra.'),(9.32,12.62,'Não some tudo como se fosse verba livre para novos serviços.')],
  9:[(.05,3.20,'Arrecadar não garante atendimento de qualidade.'),(3.30,7.65,'Planejamento, compras, equipes, manutenção, execução e fiscalização influenciam o que chega às pessoas.'),(7.75,12.85,'As fotos mostram equipamentos públicos reais, mas não medem, sozinhas, a qualidade dos serviços no país.')],
  10:[(.05,5.25,'A Receita Federal relaciona a dependência brasileira de tributos indiretos a um perfil mais regressivo.'),(5.36,9.83,'O consumo tende a pesar proporcionalmente mais para quem tem menos renda disponível.'),(9.94,14.08,'Em dois mil e vinte e seis, IBS e CBS estão em transição gradual.'),(14.18,17.20,'O novo modelo ainda não substituiu completamente o anterior.')],
  11:[(.05,1.08,'Qualquer pessoa pode acompanhar.'),(1.16,4.00,'No Portal da Transparência da União, filtre despesas por órgão e período,'),(4.08,7.48,'consulte contratos e compare empenhado e pago.'),(7.56,8.95,'Consulte também os portais locais.'),(9.03,13.45,'Pela Lei de Acesso, qualquer pessoa pode solicitar informações.'),(13.53,17.10,'Fala.BR na União e canais próprios nos estados e municípios.')],
  12:[(.05,3.90,'Impostos financiam serviços que usamos e outros que beneficiam toda a sociedade.'),(4.00,7.55,'Mas pagar também nos dá motivo para perguntar como o dinheiro é usado:'),(7.65,10.70,'o que chega, quem paga mais e como cada real é administrado.'),(10.80,12.92,'Siga arroba Vizinho Público.')],
}
for item,start,d in zip(DATA,starts,lengths):
    scene=item['scene']
    if scene==1:
        # The approved opening MP4 carries its own accurately timed captions.
        continue
    cues=manual_cues.get(scene)
    if cues:
        for a,b,text in cues:
            if a >= d: continue
            caption_rows.append((start+a,start+min(b,d-.04),text))
    else:
        chunks=split_caption(item['narration_text'])
        words=[max(1,len(x.split())) for x in chunks]; total=sum(words)
        gap=.10; span=d-.18; available=span-gap*max(0,len(chunks)-1); pos=.08
        for chunk,w in zip(chunks,words):
            seg=available*w/total
            caption_rows.append((start+pos,start+pos+seg,chunk))
            pos+=seg+gap

def cap_html(start,end,text,i):
    return f'<div class="caption" id="cap{i}">{esc(text)}</div>'

captions=''.join(cap_html(a,b,t,i) for i,(a,b,t) in enumerate(caption_rows,1))
def srt_time(t):
    ms=round(t*1000); hh=ms//3600000; mm=(ms%3600000)//60000; ss=(ms%60000)//1000; mmm=ms%1000
    return f'{hh:02}:{mm:02}:{ss:02},{mmm:03}'
for i,(a,b,text) in enumerate(caption_rows):
    if b-a < .80: raise ValueError(f'caption cue under .80s {i}: {b-a:.3f}s {text!r}')
    if len(text) > 120: raise ValueError(f'caption cue likely exceeds two lines {i}: {len(text)} chars')
    if not a < b: raise ValueError(f'invalid caption cue {i}: {a}..{b}')
    if i and a < caption_rows[i-1][1]: raise ValueError(f'overlapping caption cues {i-1}/{i}: {caption_rows[i-1][1]} > {a}')
(ROOT/'deliverables').mkdir(exist_ok=True)
opening_srt=(OPENING_DIR/'deliverables/captions-A-v2.srt').read_text(encoding='utf-8')
def parse_srt_rows(value):
    rows=[]
    def parse_time(t):
        hh,mm,rest=t.strip().split(':')
        ss,ms=rest.split(',')
        return int(hh)*3600+int(mm)*60+int(ss)+int(ms)/1000
    for block in re.split(r'\n\s*\n',value.strip()):
        lines=block.splitlines()
        if len(lines)<3 or '-->' not in lines[1]: continue
        a,b=lines[1].split('-->')
        rows.append((parse_time(a),parse_time(b),' '.join(lines[2:])))
    return rows
full_caption_rows=parse_srt_rows(opening_srt)+caption_rows
(ROOT/'deliverables/captions.srt').write_text(''.join(f'{i+1}\n{srt_time(a)} --> {srt_time(b)}\n{text}\n\n' for i,(a,b,text) in enumerate(full_caption_rows)),encoding='utf-8')
(ROOT/'deliverables/captions.json').write_text(json.dumps([{'start':round(a,3),'end':round(b,3),'text':text} for a,b,text in full_caption_rows],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
scenes=''.join(SCENE_HTML)
opening_audio=''.join(
    f'<audio id="opening-voice-{i+1}" data-audio-group="voiceover" src="assets/audio/opening/{name}.mp3" data-start="{st:.6f}" data-duration="{dur:.6f}" data-track-index="0"></audio>'
    for i,(name,st,dur) in enumerate(zip(OPENING_TIMING['clip_order'],OPENING_TIMING['starts_seconds'],OPENING_TIMING['durations_seconds']))
)
body_audio=''.join(f'<audio id="voice-{item["scene"]}" data-audio-group="voiceover" src="assets/audio/scenes/{item["scene"]:02d}-scene.mp3" data-start="{start:.6f}" data-duration="{d:.6f}" data-track-index="0"></audio>' for item,start,d in zip(DATA[1:],starts[1:],lengths[1:]))
audio=opening_audio+body_audio
old_index=(ROOT/'index.html').read_text(encoding='utf-8') if (ROOT/'index.html').exists() else ''
music_match=re.search(r'<audio id="music-bed"[^>]*></audio>',old_index)
music_source=ROOT/'assets/audio/music-original.wav'
music_full=ROOT/'assets/audio/music-full.wav'
source_music_duration=duration(music_source)
if source_music_duration+0.02 < program:
    # Preserve the original bed and extend it imperceptibly with pitch-safe
    # tempo compensation so its existing ending fade reaches the program end.
    tempo=source_music_duration/program
    subprocess.run(['ffmpeg','-y','-v','error','-i',str(music_source),'-filter:a',f'atempo={tempo:.8f},aresample=48000,apad=pad_dur=0.1,atrim=duration={program:.6f}','-c:a','pcm_s16le',str(music_full)],check=True)
else:
    music_full=music_source
if music_match:
    music=re.sub(r'src="[^"]+"',f'src="assets/audio/{music_full.name}"',music_match.group(0))
    music=re.sub(r'data-duration="[^"]+"',f'data-duration="{program:.6f}"',music)
else:
    music=f'<audio id="music-bed" data-audio-group="music" src="assets/audio/{music_full.name}" data-start="0" data-duration="{program:.6f}" data-volume="0.35" data-track-index="2"></audio>'

css='''
@font-face{font-family:Teko;src:url('assets/fonts/Teko-700.woff2')}@font-face{font-family:EBGaramond;src:url('assets/fonts/EBGaramond-400.woff2')}@font-face{font-family:EBGaramond;src:url('assets/fonts/EBGaramond-700.woff2');font-weight:700}@font-face{font-family:JetBrainsMono;src:url('assets/fonts/JetBrainsMono-400.woff2')}@font-face{font-family:JetBrainsMono;src:url('assets/fonts/JetBrainsMono-700.woff2');font-weight:700}
*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#263438;color:#263438}#root{position:relative;width:1080px;height:1920px;overflow:hidden;background:#F4F1DE;font-family:EBGaramond,serif}.scene{position:absolute;inset:0;width:1080px;height:1920px;overflow:hidden;background:#F4F1DE;isolation:isolate;opacity:0;visibility:hidden}.topline{position:absolute;left:70px;right:70px;top:66px;display:flex;justify-content:space-between;align-items:center;font:700 24px JetBrainsMono;letter-spacing:.06em;color:#263438}.brand{color:#347A70}.kicker,.eyebrow{position:absolute;left:76px;right:76px;top:155px;font:700 26px JetBrainsMono;color:#B9483D;letter-spacing:.08em}.scene h1{position:absolute;left:70px;right:70px;top:220px;margin:0;font:700 92px/.92 Teko;letter-spacing:.01em;text-transform:uppercase;color:#263438}.lede{position:absolute;left:76px;right:76px;top:380px;font:400 40px/1.08 EBGaramond}.caption{position:absolute;visibility:hidden;z-index:50;left:95px;right:95px;bottom:300px;min-height:100px;display:flex;align-items:center;justify-content:center;text-align:center;padding:18px 26px;background:rgba(38,52,56,.97);color:#fff;font:700 39px/1.05 Teko;letter-spacing:.015em;border-bottom:5px solid #D9A441;opacity:0}.source-line{position:absolute;left:74px;right:74px;bottom:130px;font:700 18px/1.2 JetBrainsMono;color:#263438;letter-spacing:.02em}.reveal{opacity:0}.grain{position:absolute;inset:0;pointer-events:none;opacity:.025;background-image:radial-gradient(#263438 .5px,transparent .7px);background-size:8px 8px}.scene01 .opening-title{position:absolute;left:70px;right:70px;top:210px;font:700 110px/.82 Teko;letter-spacing:.01em}.opening-title span{display:block;color:#263438}.opening-title span:nth-child(2){color:#946400}.opening-note{position:absolute;left:75px;right:75px;top:490px;font:400 34px/1.1 EBGaramond}.receipt{position:absolute;left:75px;top:715px;width:420px;height:435px;padding:28px;background:#fffdf3;border:3px solid #263438;box-shadow:13px 16px 0 #D9A441;transform:rotate(-2deg)}.doc-tag{font:700 23px JetBrainsMono;color:#B9483D}.receipt-main{margin-top:38px;font:700 54px/.9 Teko}.receipt-small{margin-top:20px;font:22px/1.2 JetBrainsMono}.salary-icon{position:absolute;right:22px;top:178px;width:82px;color:#347A70}.salary-icon svg,.icon svg,.base-icon svg,.fed-icon svg,.basket-art svg{width:100%;height:auto;stroke:currentColor;fill:none;stroke-width:2.8;stroke-linecap:round;stroke-linejoin:round}.receipt-foot{position:absolute;left:28px;bottom:25px;color:#347A70;font:700 19px JetBrainsMono}.daily-grid{position:absolute;right:70px;top:730px;width:490px;display:grid;gap:18px}.daily-card{min-height:126px;background:#263438;color:#F4F1DE;border-left:9px solid #D9A441;display:flex;align-items:center;gap:20px;padding:16px 20px}.icon{width:74px;flex:0 0 74px;color:#D9A441}.daily-card b{display:block;font:700 34px/1 Teko}.daily-card small{display:block;margin-top:7px;font:19px/1.12 JetBrainsMono;color:#f4f1de}.question{position:absolute;left:70px;right:70px;top:310px;text-align:center;font:700 92px/.9 Teko;color:#263438;opacity:0}.question strong{display:block;color:#B9483D}.city-photo{position:absolute;left:0;right:0;bottom:0;height:560px;overflow:hidden;clip-path:polygon(0 10%,100% 0,100% 100%,0 100%);opacity:0}.city-photo img{width:100%;height:100%;object-fit:cover;object-position:center 48%;filter:saturate(.8)}.city-photo:after{content:'';position:absolute;inset:0;background:linear-gradient(0deg,rgba(38,52,56,.55),transparent 75%)}.photo-line{position:absolute;left:70px;bottom:100px;color:#fff;font:700 22px JetBrainsMono;letter-spacing:.05em;opacity:0;z-index:4}
.flow-source{position:absolute;left:110px;top:700px;width:300px;height:150px;border-radius:18px;background:#263438;color:#fff;display:grid;place-items:center;font:700 45px Teko;box-shadow:12px 14px 0 #D9A441}.flow-nodes{position:absolute;right:78px;top:620px;width:430px;display:grid;gap:22px}.flow-node{height:165px;background:#347A70;color:#fff;display:flex;align-items:center;gap:25px;padding:24px;border-radius:12px;box-shadow:0 10px 0 rgba(38,52,56,.13)}.flow-node svg{width:75px;height:75px;stroke:#F4F1DE;fill:none;stroke-width:2.6}.flow-node b{font:700 42px Teko}.flow-line{position:absolute;left:408px;width:160px;border-top:5px solid #D9A441;transform-origin:left;opacity:0}.line-a{top:692px;transform:rotate(-8deg)}.line-b{top:770px}.line-c{top:846px;transform:rotate(9deg)}.note-card{position:absolute;left:76px;right:76px;bottom:470px;border:2px solid #347A70;padding:25px 30px;font:700 33px/1.1 Teko;color:#263438}
.three-cards{position:absolute;left:70px;right:70px;top:600px;display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.type-card{height:650px;background:#263438;color:#F4F1DE;padding:30px 25px;border-top:12px solid #D9A441;box-shadow:0 12px 0 rgba(38,52,56,.13)}.type-mark{font:700 24px JetBrainsMono;color:#D9A441}.type-card h2{font:700 52px/.9 Teko;margin:55px 0 24px}.type-card p{font:400 34px/1.08 EBGaramond}.bottom-rule{position:absolute;left:76px;right:76px;bottom:470px;padding:22px;border-bottom:5px solid #B9483D;text-align:center;font:700 31px Teko}
.base-grid{position:absolute;left:72px;right:72px;top:600px;display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.base-card{height:620px;padding:30px;background:#fffdf3;border:2px solid #263438;box-shadow:0 12px 0 #D9A441}.base-icon{width:115px;height:115px;color:#347A70}.base-title{margin-top:50px;font:700 48px Teko}.base-examples{margin-top:15px;font:700 28px JetBrainsMono;color:#B9483D}.base-kind{position:absolute;bottom:27px;font:700 21px JetBrainsMono;color:#347A70}.scene04 .note-card{bottom:420px}.axis{position:absolute;left:80px;right:80px;bottom:560px;display:flex;align-items:center;gap:18px;font:700 18px JetBrainsMono;color:#263438}.axis i{height:4px;background:#D9A441;flex:1;transform:scaleX(0);transform-origin:left}
.federation{position:absolute;left:72px;top:540px;width:525px;display:grid;gap:15px}.fed-node{height:130px;display:flex;align-items:center;gap:18px;padding:18px;background:#fffdf3;border:2px solid #263438;box-shadow:8px 8px 0 #D9A441}.country-map{position:absolute;right:75px;top:560px;width:360px;height:310px;background:#263438;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:8px;border-bottom:8px solid #D9A441}.country-map img{width:260px;height:238px;object-fit:contain}.country-map span{font:700 22px JetBrainsMono;color:#F4F1DE;letter-spacing:.12em}.fed-icon{width:110px;color:#347A70}.fed-node b{display:block;font:700 45px Teko}.fed-node small{display:block;font:700 17px JetBrainsMono;letter-spacing:.02em}.fed-receipt{margin-left:auto;padding:18px;background:#347A70;color:#fff;font:700 22px JetBrainsMono}.transfer{position:absolute;left:90px;right:90px;bottom:600px;text-align:center;font:700 24px JetBrainsMono}.transfer-line{height:5px;margin:22px;background:#B9483D;position:relative;transform:scaleX(0);transform-origin:left}.transfer-line:after{content:'›';position:absolute;right:-4px;top:-28px;font:700 54px Teko;color:#B9483D}.scene05 .transfer{left:75px;right:75px;bottom:530px}.scene05 .bottom-rule{bottom:450px}
.big-number{position:absolute;left:90px;top:520px;font:700 280px/.8 Teko;color:#946400}.big-number span{font-size:155px}.percent-label{position:absolute;left:106px;top:780px;font:700 54px Teko}.ratio-track{position:absolute;left:100px;right:100px;top:930px;height:150px;background:#d8ded6;border:2px solid #263438;padding:20px;font:700 20px JetBrainsMono}.ratio-fill{height:52px;width:0;background:#347A70}.method-card{position:absolute;left:100px;right:100px;top:1160px;padding:28px 35px;background:#263438;color:#fff}.method-card b{font:700 27px JetBrainsMono;color:#D9A441}.method-card p{font:400 33px/1.08 EBGaramond}.caveat{position:absolute;left:95px;right:95px;bottom:435px;text-align:center;font:700 33px/1.05 Teko;color:#B9483D}
.scope-label{position:absolute;top:410px;left:75px;right:75px;font:700 23px/1.2 JetBrainsMono;color:#347A70}.budget-bars{position:absolute;left:82px;right:82px;top:660px;display:grid;gap:80px}.budget-row{display:grid;grid-template-columns:240px 1fr 210px;align-items:center;gap:16px}.budget-label,.budget-value{font:700 32px Teko}.budget-value{text-align:right;color:#B9483D}.bar-track{height:88px;background:#d8ded6;border:2px solid #263438;overflow:hidden}.bar-fill{height:100%;width:0;background:#347A70}.budget-note{position:absolute;left:85px;right:85px;bottom:470px;text-align:center;padding:25px;border:2px solid #B9483D;font:700 27px/1.15 JetBrainsMono}
.debt-cards{position:absolute;left:72px;right:72px;top:570px;display:grid;gap:22px}.debt-card{min-height:260px;background:#fffdf3;border:2px solid #263438;padding:24px 30px 26px 145px;position:relative;box-shadow:9px 10px 0 #D9A441}.debt-num{position:absolute;left:30px;top:28px;color:#B9483D;font:700 64px Teko}.debt-card h2{margin:0;font:700 42px Teko}.debt-card p{margin:10px 0;font:400 30px/1.05 EBGaramond}.debt-flow{font:700 20px JetBrainsMono;color:#347A70}.warning{position:absolute;left:78px;right:78px;bottom:420px;background:#B9483D;color:#fff;padding:26px;text-align:center;font:700 29px/1.1 Teko}
.photo-pair{position:absolute;left:68px;right:68px;top:480px;display:grid;grid-template-columns:1fr 1fr;gap:22px}.doc-photo{margin:0;background:#263438;padding:10px 10px 62px;position:relative;box-shadow:0 12px 0 #D9A441}.doc-photo img{display:block;width:100%;height:470px;object-fit:cover;object-position:center}.doc-photo figcaption{position:absolute;left:13px;right:13px;bottom:8px;color:#fff;font:700 18px/1.12 JetBrainsMono;text-align:center}.doc-photo figcaption small{font:700 16px/1.1 JetBrainsMono;color:#F4F1DE}.process-strip{position:absolute;left:75px;right:75px;top:1050px;display:flex;justify-content:center;align-items:center;gap:12px;color:#263438;font:700 18px JetBrainsMono}.process-strip span,.process-strip i{opacity:0}.process-strip i{color:#B9483D;font-style:normal;font-size:28px}.photo-caveat{position:absolute;left:82px;right:82px;top:1150px;padding:18px 22px;text-align:center;background:#263438;color:#fff;font:700 21px/1.1 JetBrainsMono}
.basket-compare{position:absolute;left:78px;right:78px;top:530px;display:grid;grid-template-columns:1fr 1fr;gap:25px}.basket{padding:24px;background:#fffdf3;border:2px solid #263438;min-height:460px}.income-label{font:700 22px JetBrainsMono;color:#B9483D}.basket-art{width:90px;color:#347A70;margin:30px auto}.same-price{display:grid;place-items:center;min-height:74px;margin:20px 0;background:#263438;color:#F4F1DE;border-left:8px solid #D9A441;font:700 25px JetBrainsMono}.basket b{font:700 26px/1.05 Teko}.illustration-tag{position:absolute;left:80px;right:80px;top:1015px;text-align:center;font:700 17px JetBrainsMono;color:#263438}.transition-panel{position:absolute;left:74px;right:74px;top:1110px;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:20px;background:#263438;color:#fff;font:700 17px/1.1 JetBrainsMono}.transition-panel span,.transition-panel i{opacity:0}.transition-panel i{height:4px;flex:1;background:#D9A441}.scene10 .source-line{bottom:190px}
.portal-mock{position:absolute;left:75px;right:75px;top:475px;padding:24px;background:#263438;color:#fff;border:3px solid #347A70;box-shadow:12px 12px 0 #D9A441}.mock-title{color:#D9A441;font:700 18px JetBrainsMono}.mock-fields{display:flex;gap:16px;margin:25px 0}.mock-fields div{flex:1;background:#F4F1DE;color:#263438;padding:18px;font:700 20px JetBrainsMono}.mock-fields div,.mock-row{opacity:0}.mock-fields b{float:right;color:#B9483D}.mock-row{display:flex;align-items:center;gap:14px;padding:14px 0;border-top:1px solid #74817d;font:700 20px JetBrainsMono}.mock-row i{height:3px;background:#D9A441;flex:1}.mock-row b{font-size:16px}.howto{position:absolute;left:82px;right:82px;top:1050px;display:grid;gap:19px}.howto div{font:400 31px EBGaramond;opacity:0}.howto b{display:inline-grid;place-items:center;background:#347A70;color:#fff;width:52px;height:52px;margin-right:12px;font:700 19px JetBrainsMono}.access{position:absolute;left:82px;right:82px;bottom:470px;padding:20px;border-top:3px solid #B9483D;font:700 21px/1.35 JetBrainsMono}
.end-city{position:absolute;inset:-2%;overflow:hidden;background-image:url(assets/images/rio-de-janeiro-panorama.jpg);background-size:cover;background-position:center;background-repeat:no-repeat;filter:saturate(.65)}.end-shade{position:absolute;z-index:1;inset:0;background:linear-gradient(180deg,rgba(38,52,56,.78),rgba(38,52,56,.46) 55%,rgba(38,52,56,.88))}.end-copy{position:absolute;z-index:2;left:70px;right:70px;top:320px;color:#fff;text-align:center}.end-copy .kicker{position:static;color:#D9A441;font-size:24px}.end-copy h1{position:static;margin:60px 0 70px;color:#fff;font:700 108px/.9 Teko}.end-questions{display:grid;gap:25px;font:700 32px JetBrainsMono}.end-questions span{padding:18px;border-bottom:2px solid #D9A441}.end-copy h1,.end-questions span,.end-follow{opacity:0;visibility:hidden}.end-follow{margin-top:75px;font:700 30px JetBrainsMono}.end-follow b{color:#D9A441}.scene12 .topline{z-index:3;color:#F4F1DE}.scene12 .topline span{color:#F4F1DE}.end-city{transform-origin:center center}.scene12 .caption{background:rgba(38,52,56,.98)}
'''

timeline=['const tl=gsap.timeline({paused:true});']
def add_reveal(scene, selector, local, duration=.48, x=0, y=22, scale=.985):
    pos=starts[scene-1]+local
    frm=f'{{autoAlpha:0,x:{x},y:{y},scale:{scale}}}'
    to=f'{{autoAlpha:1,x:0,y:0,scale:1,duration:{duration},ease:"power2.out"}}'
    timeline.append(f'tl.fromTo("#s{scene:02d} {selector}",{frm},{to},{pos:.6f});')

for i,(start,d) in enumerate(zip(starts,lengths),1):
    hold=HOLDS.get(i,0)
    end=(OPENING_SECONDS if i==1 else start+d+hold+(END_HOLD if i==12 else 0))
    timeline.append(f'tl.fromTo("#s{i:02d}",{{autoAlpha:0,y:16}},{{autoAlpha:1,y:0,duration:.32,ease:"power2.out"}},{start:.6f});')
    timeline.append(f'tl.to("#s{i:02d}",{{autoAlpha:0,duration:.22,ease:"power1.in"}},{end-.22:.6f});')
    if i==2:
      add_reveal(2,'.flow-source',.35,.45,x=-45,y=0)
      for j,local in enumerate((1.15,2.35,3.55),1):
        add_reveal(2,f'.flow-node:nth-child({j})',local,.45,x=45,y=0)
        timeline.append(f'tl.fromTo("#s02 .line-{["a","b","c"][j-1]}",{{autoAlpha:0,scaleX:0}},{{autoAlpha:1,scaleX:1,duration:.42,ease:"power2.out"}},{starts[1]+local-.28:.6f});')
      add_reveal(2,'.note-card',4.55,.5,y=30)
    elif i==3:
      for j,local in enumerate((.45,4.65,8.85),1): add_reveal(3,f'.type-card:nth-child({j})',local,.55,y=30)
      add_reveal(3,'.bottom-rule',13.05,.5,y=20)
    elif i==4:
      for j,local in enumerate((.45,4.15,7.85),1): add_reveal(4,f'.base-card:nth-child({j})',local,.55,y=32)
      add_reveal(4,'.note-card',11.65,.5,y=20)
      add_reveal(4,'.axis',13.05,.45,y=0)
      timeline.append(f'tl.fromTo("#s04 .axis i",{{scaleX:0}},{'{'}scaleX:1,duration:.65,ease:"power2.out"{'}'},{start+13.25:.6f});')
    elif i==5:
      for j,local in enumerate((.35,2.55,4.75),1): add_reveal(5,f'.fed-node:nth-child({j})',local,.48,x=-45,y=0)
      add_reveal(5,'.country-map',6.05,.55,y=18)
      add_reveal(5,'.transfer',6.95,.5,y=22)
      timeline.append(f'tl.fromTo("#s05 .transfer-line",{{scaleX:0}},{'{'}scaleX:1,duration:.55,ease:"power2.out"{'}'},{start+7.48:.6f});')
      add_reveal(5,'.bottom-rule',8.55,.5,y=20)
    elif i==6:
      add_reveal(6,'.big-number',.35,.7,y=18)
      add_reveal(6,'.percent-label',.92,.4,y=0)
      add_reveal(6,'.ratio-track',1.65,.45,y=20)
      timeline.append(f'tl.fromTo("#s06 .ratio-fill",{{width:0}},{{width:"32.2%",duration:1.25,ease:"power2.out"}},{start+2.25:.6f});')
      add_reveal(6,'.method-card',4.45,.55,y=24)
      add_reveal(6,'.caveat',10.55,.45,y=0)
    elif i==7:
      for j,(local,w) in enumerate(zip((.4,4.1,7.8),(21.6,15.4,100)),1):
        add_reveal(7,f'.budget-row:nth-child({j})',local,.5,x=-30,y=0)
        timeline.append(f'tl.fromTo("#s07 .budget-row:nth-child({j}) .bar-fill",{{width:0}},{{width:"{w}%",duration:.9,ease:"power2.out"}},{start+local+.4:.6f});')
      add_reveal(7,'.budget-note',14.25,.45,y=16)
    elif i==8:
      for j,local in enumerate((.35,3.5,6.65),1): add_reveal(8,f'.debt-card:nth-child({j})',local,.52,x=45,y=0)
      add_reveal(8,'.warning',10.2,.45,y=18)
    elif i==9:
      add_reveal(9,'.doc-photo:nth-child(1)',.35,.5,x=-25,y=0)
      add_reveal(9,'.doc-photo:nth-child(2)',1.75,.5,x=25,y=0)
      timeline.append(f'tl.fromTo("#s09 .camera",{{scale:1.09,x:-15}},{{scale:1.01,x:15,duration:{max(6,d-1):.3f},ease:"none"}},{start+.55:.6f});')
      add_reveal(9,'.process-strip',6.0,.35,y=10)
      for j,local in enumerate((6.4,7.2,8.0,8.8,9.6),1):
        selector=f'.process-strip > {"span" if j%2 else "i"}:nth-child({j})'
        timeline.append(f'tl.fromTo("#s09 {selector}",{{autoAlpha:0,y:10}},{{autoAlpha:1,y:0,duration:.25,ease:"power1.out"}},{start+local:.6f});')
      add_reveal(9,'.photo-caveat',11.1,.45,y=16)
    elif i==10:
      add_reveal(10,'.basket:nth-child(1)',.35,.5,x=-40,y=0)
      add_reveal(10,'.basket:nth-child(2)',4.1,.5,x=40,y=0)
      add_reveal(10,'.illustration-tag',8.45,.35,y=0)
      add_reveal(10,'.transition-panel',9.35,.45,y=20)
      for j,local in enumerate((9.75,10.15,10.55,11.15,11.55),1):
        selector=f'.transition-panel > {"span" if j%2 else "i"}:nth-child({j})'
        timeline.append(f'tl.fromTo("#s10 {selector}",{{autoAlpha:0,scale:.92}},{{autoAlpha:1,scale:1,duration:.3,ease:"power1.out"}},{start+local:.6f});')
    elif i==11:
      add_reveal(11,'.portal-mock',.35,.48,y=24)
      for j,local in enumerate((1.75,2.3,4.0,6.0,8.0),1):
        selector={1:'.mock-fields > div:nth-child(1)',2:'.mock-fields > div:nth-child(2)',3:'.mock-row:nth-child(3)',4:'.mock-row:nth-child(4)',5:'.mock-row:nth-child(5)'}[j]
        timeline.append(f'tl.fromTo("#s11 {selector}",{{autoAlpha:0,x:-18}},{{autoAlpha:1,x:0,duration:.32,ease:"power1.out"}},{start+local:.6f});')
      add_reveal(11,'.howto',9.0,.4,y=12)
      for j,local in enumerate((9.35,10.4,11.45,12.5),1):
        timeline.append(f'tl.fromTo("#s11 .howto > div:nth-child({j})",{{autoAlpha:0,x:22}},{{autoAlpha:1,x:0,duration:.3,ease:"power1.out"}},{start+local:.6f});')
      add_reveal(11,'.access',14.65,.45,y=18)
    elif i==12:
      timeline.append(f'tl.fromTo("#s12 .end-city",{{scale:1.08,x:-12}},{{scale:1.01,x:12,duration:{d+END_HOLD:.3f},ease:"none"}},{start+.05:.6f});')
      add_reveal(12,'.end-copy',.3,.4,y=18)
      timeline.append(f'tl.fromTo("#s12 .end-copy h1",{{autoAlpha:0,y:28}},{{autoAlpha:1,y:0,duration:.5,ease:"power2.out"}},{start+1.75:.6f});')
      for j,local in enumerate((4.0,5.9,7.8),1):
        timeline.append(f'tl.fromTo("#s12 .end-questions span:nth-child({j})",{{autoAlpha:0,x:-24}},{{autoAlpha:1,x:0,duration:.35,ease:"power2.out"}},{start+local:.6f});')
      timeline.append(f'tl.fromTo("#s12 .end-follow",{{autoAlpha:0,y:18}},{{autoAlpha:1,y:0,duration:.42,ease:"power2.out"}},{start+10.7:.6f});')

for i,(a,b,text) in enumerate(caption_rows,1):
    timeline += [f'tl.fromTo("#cap{i}",{{autoAlpha:0,y:16}},{{autoAlpha:1,y:0,duration:.13}},{a:.3f});',f'tl.to("#cap{i}",{{autoAlpha:0,y:-10,duration:.12}},{b-.12:.3f});']

audio_end=program-END_HOLD
css += '.opening-container{background:#263438}.opening-video{position:absolute;inset:0;width:1080px;height:1920px;object-fit:cover;display:block}'
html_doc=f'''<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=1080,height=1920"><title>Por que pagamos impostos? — Vizinho Público</title><script src="assets/vendor/gsap.min.js"></script><style>{css}</style></head><body><main id="root" class="clip" data-composition-id="main" data-start="0" data-duration="{program:.6f}" data-width="1080" data-height="1920">{scenes}{captions}{audio}{music}</main><script>{''.join(timeline)}window.__timelines=window.__timelines||{{}};window.__timelines['main']=tl;</script></body></html>'''
(ROOT/'index-full.source.txt').write_text(html_doc)
(ROOT/'index.html').write_text(html_doc,encoding='utf-8')
print(json.dumps({'scene_starts':starts,'voice_durations':lengths,'program_duration':program,'caption_count':len(full_caption_rows),'html_chars':len(html_doc)},indent=2))
