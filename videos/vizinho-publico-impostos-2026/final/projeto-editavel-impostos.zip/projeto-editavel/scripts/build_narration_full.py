#!/usr/bin/env python3
"""Rebuild the full narration-only PCM track from current, manifested voice takes."""
import json, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
opening=json.loads((ROOT/'assets/audio/opening/audio-timing-v2.json').read_text())['A']
timeline=json.loads((ROOT/'TIMELINE.json').read_text())
inputs=[]; starts=[]
for name,start in zip(opening['clip_order'],opening['starts_seconds']):
    inputs.append(ROOT/'assets/audio/opening'/f'{name}.mp3'); starts.append(start)
for scene,start in zip(range(2,13),timeline['scene_starts'][1:]):
    inputs.append(ROOT/'assets/audio/scenes'/f'{scene:02d}-scene.mp3'); starts.append(start)
cmd=['ffmpeg','-y','-v','error']
for path in inputs: cmd += ['-i',str(path)]
filters=[]
for i,start in enumerate(starts):
    delay=round(start*1000)
    filters.append(f'[{i}:a]aformat=sample_rates=48000:channel_layouts=stereo,adelay={delay}|{delay}[v{i}]')
labels=''.join(f'[v{i}]' for i in range(len(inputs)))
filters.append(f'{labels}amix=inputs={len(inputs)}:duration=longest:normalize=0:dropout_transition=0,atrim=duration={timeline["duration_seconds"]:.6f},asetpts=PTS-STARTPTS[out]')
out=ROOT/'deliverables/narration-full-aligned.wav'
out.parent.mkdir(parents=True,exist_ok=True)
cmd += ['-filter_complex',';'.join(filters),'-map','[out]','-ar','48000','-ac','2','-c:a','pcm_s24le',str(out)]
subprocess.run(cmd,check=True)
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(out)],text=True))
print(json.dumps({'output':str(out.relative_to(ROOT)),'source_takes':len(inputs),'source_starts':starts,'program_duration':timeline['duration_seconds'],'rendered_duration':float(meta['format']['duration'])},indent=2))
