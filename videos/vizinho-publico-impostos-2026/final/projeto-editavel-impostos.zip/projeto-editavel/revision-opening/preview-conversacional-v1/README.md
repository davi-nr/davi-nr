# Revisão da abertura — prévia para aprovação

Esta pasta contém a nova abertura conversacional para “Por que pagamos impostos?”. O candidato atual para visualização é [`deliverables/preview-conversacional-v6-distribution.mp4`](deliverables/preview-conversacional-v6-distribution.mp4), uma prévia de 22 segundos em 1080×1920/30 fps. As versões v1–v5 são preservadas como intermediários e estão explicadas nos relatórios de auditoria; v4 não deve ser compartilhado por usar uma mixagem anterior.

Ouça as três opções já niveladas em [`deliverables/ALTERNATIVAS-DE-PERGUNTA-v3.md`](deliverables/ALTERNATIVAS-DE-PERGUNTA-v3.md): A é a fala do MP4; B e C mudam somente a pergunta principal. A interpretação e a entonação precisam ser avaliadas pelo usuário ao ouvir.

O HTML editável desta prévia é `index.html`; a música, os takes TTS, os mixes originais e os mixes nivelados estão em `assets/audio/`. `SCRIPT` e storyboard descrevem a abertura e suas pausas. `AUDIT-PREVIEW-CONVERSACIONAL-v6.md` registra captura, codificação, métricas e limites de validação.

O vídeo completo permanece suspenso até aprovação explícita desta abertura. As cenas 2–12 ficam fora desta revisão e foram preservadas.
