# Alternativas reais para a nova abertura

Todas as versões foram sintetizadas pelo Fish Audio com a voz de referência Mulher do Criativo top, referência `ceaf7f569bef42c7bd322d88e3a356b7`, alias solicitado/aceito `s2.1-pro-free`, temperature 0.85, top-p 0.85, speed 1.0 e `normalize:false`. A resposta da API não atesta independentemente o backend que executou o alias.

O take base é comum às três versões: “Você recebe seu salário. Vai ao supermercado. Abastece o carro. Paga a conta de luz. E sabe o que tudo isso tem em comum? Impostos!”

- **A — mais próxima do gancho obrigatório** (`assets/audio/question-A.mp3`, 7,993 s): “Mas espera aí... se a gente já paga tantos tributos no dia a dia, por que precisamos pagar tudo isso? E para onde vai esse dinheiro?” A prévia animada usa esta versão.
- **B — curiosidade cotidiana** (`assets/audio/question-B.mp3`, 7,131 s): “Mas espera aí... por que tantos tributos aparecem em momentos diferentes do nosso dia? E como saber para onde vai esse dinheiro?”
- **C — foco no destino** (`assets/audio/question-C.mp3`, 5,877 s): “Mas espera aí... quem decide quais tributos pagamos no cotidiano? E para onde vai o dinheiro arrecadado?”

Os arquivos A/B/C são takes gerados individualmente, não reescritas de transcrição. A prévia de vídeo tem 23 segundos. O ambiente não fornece audição humana direta; duração, decodificação e transcrição automática são triagem técnica, não avaliação de entonação. A escolha da naturalidade interrogativa fica aberta à escuta do usuário.
