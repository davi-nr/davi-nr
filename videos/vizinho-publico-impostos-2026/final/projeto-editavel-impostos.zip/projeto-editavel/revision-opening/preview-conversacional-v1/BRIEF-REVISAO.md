# Correção da abertura — orientação do usuário

Esta é uma revisão pontual. Preservar o restante do projeto e os arquivos anteriores. Produzir somente a prévia de abertura, com música, narração e animação sincronizadas, para aprovação.

## Gancho de referência obrigatório

“Você recebe seu salário. Vai ao supermercado. Abastece o carro. Paga a conta de luz.

E sabe o que tudo isso tem em comum?

Impostos!

Mas espera aí... se a gente já paga tantos tributos no dia a dia, por que precisamos pagar tudo isso?

E para onde vai esse dinheiro?”

Ajustar para aproximadamente vinte a vinte e quatro segundos, sem acelerar artificialmente a voz. Buscar ritmo conversacional, ênfase natural em “Impostos!”, pequena mudança de ritmo em “Mas espera aí...” e perguntas genuinamente interrogativas. Gerar alternativas reais de áudio para comparação.

## Voz

Fish Audio S2.1 Pro Free, Mulher do Criativo top, referência `ceaf7f569bef42c7bd322d88e3a356b7`. Manter a identidade da voz. As alternativas devem ser disponibilizadas para audição: transcrição e métricas acústicas não constituem avaliação perceptiva da entonação.

## Sequência visual

1. Pessoa recebendo salário no celular.
2. Compra em supermercado.
3. Bomba abastecendo um carro.
4. Conta de luz.
5. Conexão visual dessas situações à palavra “IMPOSTOS”.
6. Pergunta “POR QUE PAGAMOS IMPOSTOS?”.

Motion design editorial 2D contínuo, com ações/objetos acompanhando a fala. Não repetir a abertura de grandes palavras sobre fundo vazio nem uma sequência de cartões estáticos. Não usar movimentos corporais complexos.

## Precisão e preservação

Não afirmar que todas as pessoas pagam imposto de renda sobre o salário, nem que todos os tributos são impostos. A distinção das incidências precisa ficar clara na cena seguinte quando a abertura aprovada for integrada. Preservar o corpo, música, identidade e conclusão. O documentário integrado deverá permanecer abaixo de três minutos.

## Aprovação exigida pelo usuário

> “Não renderizar o documentário completo antes da aprovação da abertura.”

Esta instrução suspende a finalização integral até a aprovação explícita desta nova prévia. Renders de trabalho já existentes permanecem preservados e não são apresentados como a versão final aprovada.
