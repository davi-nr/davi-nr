# Direção de arte — Vizinho Público

**Conceito:** fazer o caminho do tributo ser visível: da rotina de uma pessoa, passando pelos orçamentos de diferentes governos, até a possibilidade concreta de acompanhar despesas e contratos.

**Referência visual aprovada:** documentário editorial do Vizinho Público. Paleta petróleo `#263438`, creme `#F4F1DE`, ocre `#D9A441`, tijolo `#B9483D`, verde `#347A70`. Teko para manchetes e números, EB Garamond para texto narrativo e JetBrains Mono para datas, fontes e pequenas etiquetas documentais. Fontes locais e respectivas licenças OFL ficam em `assets/fonts/`.

**Focal e composição:** pessoa trabalhadora e uma nota fiscal ilustrativa claramente identificada, em primeiro plano; cidade brasileira documental em fundo licenciado. Margens de segurança para o Reels, áreas de legenda preservadas e alta legibilidade em tela de telefone. Imagens reais são identificadas por local, instituição, data e crédito quando a fonte permitir.

**Movimento:** animação 2D editorial contínua, com recortes por máscara, contadores, trajetórias entre salário/preço/orçamento, mapas e gráficos com unidades explícitas. Fotografias recebem panorâmicas e zooms lentos. Sem transformar serviços públicos em promessa automática de um tributo específico; sem falsa manchete ou captura que pareça documento oficial quando for apenas composição editorial.

**Som:** voz documental natural, curiosa na pergunta inicial e calma na apresentação de dados; trilha original discreta de piano, textura e pulsação leve, com ducking e fade final.
