# Candidata v7 — extensão visual da abertura conversacional

Esta é uma nova candidata, separada da v6. A v6 permanece intacta. A alteração editorial se limita à progressão visual dos 12,9 segundos finais: os quatro motivos cotidianos continuam no quadro, convergem para um documento ilustrativo e se ramificam visualmente enquanto a pergunta e o título são revelados. A narração, o mix, os quadros iniciais e as legendas não devem ser alterados sem necessidade demonstrada.

O novo MP4 será gerado separadamente após a composição.
