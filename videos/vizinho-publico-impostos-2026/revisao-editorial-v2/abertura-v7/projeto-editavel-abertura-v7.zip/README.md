# Prévia de abertura v7 — Por que pagamos impostos?

Esta é uma candidata nova e isolada para avaliação. A prévia v6 e o documentário completo anterior permanecem preservados; nenhum deles foi sobrescrito. O arquivo final desta candidata é `deliverables/preview-opening-conversacional-v7-A.mp4`.

## Arquivos

- `deliverables/preview-opening-conversacional-v7-A.mp4`: prévia vertical de 22,016 s.
- `deliverables/audio/opening-v6-a.mp3`: narração contínua usada na prévia, sem música.
- `deliverables/audio/opening-v6-b.mp3` e `opening-v6-c.mp3`: alternativas reais de síntese, sem vídeo.
- `deliverables/audio/preview-mix-v6-A.wav`: mix de voz e trilha usada na prévia.
- `remotion-opening-app/`: composição Remotion editável; `src/Opening.jsx` contém a animação.
- `deliverables/verification/`: transcrições automáticas e quadros extraídos do MP4.
- `archive/`: renders v7 preliminares preservados durante o ajuste do documento ilustrativo.

## Render

Com Remotion 4.0.535 instalado a partir do `package-lock.json`, execute em `remotion-opening-app/`:

```sh
npx remotion render src/index.jsx Opening ../deliverables/preview-opening-conversacional-v7-A-master.mp4 \
  --codec=h264 --crf=18 --x264-preset=medium --pixel-format=yuv420p \
  --audio-codec=aac --audio-bitrate=192k \
  --browser-executable=/usr/bin/chromium --concurrency=2 --overwrite
```

O master foi remuxado para o MP4 de prévia com `ffmpeg -i MASTER -map 0 -c copy -movflags +faststart PREVIA`; nenhum stream foi reencodado nessa etapa. O áudio contínuo já contém a trilha original mixada com ducking. A fonte instrumental separada continua em `remotion-opening-app/public/audio/music-original.wav`.

## Avaliação

A API Fish confirmou o alias pedido (`s2.1-pro-free`), mas não atestou independentemente o backend de execução. Não havia escuta humana direta disponível nesta sessão. ASR, decodificação, medição de loudness e inspeção de quadros não demonstram que a interpretação vocal soa natural. A escolha de locução deve ser feita ouvindo as alternativas. Esta prévia também permanece sujeita à avaliação visual/editorial do usuário; não autoriza substituir qualquer corte anterior.
