import React from "react";
import { Composition } from "remotion";
import { Opening } from "./Opening";
import "./styles.css";

export const RemotionRoot = () => (
  <Composition
    id="Opening"
    component={Opening}
    durationInFrames={660}
    fps={30}
    width={1080}
    height={1920}
  />
);
