import React from "react";
import {AbsoluteFill, Audio, Easing, interpolate, staticFile, useCurrentFrame} from "remotion";

const C={petrol:"#263438",cream:"#F4F1DE",ochre:"#D9A441",brick:"#B9483D",green:"#347A70",ink:"#17272B",paper:"#FFFEF7"};
const clamp={extrapolateLeft:"clamp",extrapolateRight:"clamp"};
const ease=Easing.bezier(.22,1,.36,1), f=s=>s*30;
const mix=(fr,a,b,x,y)=>interpolate(fr,[f(a),f(b)],[x,y],{...clamp,easing:ease});
const presence=(fr,start,end,fade=.35)=>Math.min(mix(fr,start,start+fade,0,1),1-mix(fr,end-fade,end,0,1));
const SceneLabel=({n,title,sub,fr,start,end})=><div style={{position:"absolute",top:260,left:84,right:84,opacity:presence(fr,start,end),transform:`translateY(${mix(fr,start,start+.4,32,0)}px)`}}><div className="scene-kicker">{n} / {title}</div><div className="scene-copy">{sub}</div></div>;
function Phone({fr}){
 const enter=presence(fr,0,2.18,.35), pulse=mix(fr,.35,1.1,.92,1.04), notif=mix(fr,.7,1.2,0,1);
 return <div style={{position:"absolute",top:250,left:0,right:0,height:840,opacity:enter,transform:`translateY(${mix(fr,0,.5,70,0)}px) scale(${pulse})`}}>
  <svg viewBox="0 0 1080 840" width="1080" height="840">
   <path d="M0 735 C140 650 230 670 350 720 L470 770 L420 840 H0Z" fill="#D89B79"/>
   <path d="M1080 690 C950 620 825 650 730 710 L625 780 L675 840 H1080Z" fill="#D89B79"/>
   <rect x="336" y="35" width="408" height="720" rx="62" fill={C.petrol}/><rect x="356" y="58" width="368" height="675" rx="44" fill={C.paper}/>
   <rect x="455" y="77" width="170" height="16" rx="8" fill={C.ochre}/>
   <circle cx="540" cy="220" r="81" fill={C.green}/><path d="M495 220 L527 253 L590 183" fill="none" stroke={C.cream} strokeWidth="17" strokeLinecap="round" strokeLinejoin="round"/>
   <text x="540" y="355" textAnchor="middle" className="phone-main">SALÁRIO</text>
   <text x="540" y="405" textAnchor="middle" className="phone-small">DEPÓSITO RECEBIDO</text>
   <rect x="405" y="455" width="270" height="105" rx="18" fill="#E7E5D6"/><text x="540" y="500" textAnchor="middle" className="phone-small">ENTRADA NA CONTA</text><path d="M445 530 H635" stroke={C.ochre} strokeWidth="11" strokeLinecap="round"/>
   <circle cx="540" cy="668" r="9" fill={C.ochre}/>
   <path d="M250 198 C175 165 138 130 110 80" fill="none" stroke={C.brick} strokeWidth="9" strokeDasharray="14 18" strokeDashoffset={mix(fr,.1,1.4,390,0)}/>
   <circle cx="110" cy="80" r="20" fill={C.ochre} opacity={notif}/>
  </svg>
 </div>
}
function Market({fr}){
 const op=presence(fr,2.08,6.22,.45), cartX=mix(fr,2.05,3.0,130,0), scan=mix(fr,4.65,5.8,0,1);
 return <div style={{position:"absolute",top:0,left:0,right:0,height:1260,opacity:op,transform:`translateX(${cartX}px)`}}>
  <SceneLabel n="02" title="SUPERMERCADO" sub={<>A compra<br/>passa pelo caixa.</>} fr={fr} start={2.1} end={6.15}/>
  <svg viewBox="0 0 900 780" width="900" height="780" style={{position:"absolute",left:90,top:500}}>
   <path d="M100 200 H760 L690 520 H205Z" fill="none" stroke={C.petrol} strokeWidth="24" strokeLinejoin="round"/>
   <path d="M100 200 L20 110 M210 520 H700" stroke={C.petrol} strokeWidth="24" strokeLinecap="round"/>
   <circle cx="275" cy="605" r="63" fill={C.ochre}/><circle cx="625" cy="605" r="63" fill={C.ochre}/><circle cx="275" cy="605" r="25" fill={C.petrol}/><circle cx="625" cy="605" r="25" fill={C.petrol}/>
   <path d="M245 195 C230 110 315 77 365 170 C368 190 310 211 245 195Z" fill={C.brick}/><path d="M290 125 L305 190" stroke={C.cream} strokeWidth="12"/>
   <path d="M380 200 C390 120 500 105 542 165 C570 210 530 250 458 254 C408 252 375 230 380 200Z" fill={C.ochre}/><path d="M432 153 L450 175 M475 143 L493 165" stroke="#FFF3CF" strokeWidth="12" strokeLinecap="round"/>
   <rect x="585" y="202" width="86" height="170" rx="15" fill={C.green}/><path d="M604 202 V175 H650 V202" fill="none" stroke={C.green} strokeWidth="15"/>
   <path d={`M190 ${mix(fr,4.65,5.8,170,470)} H710`} stroke={C.brick} strokeWidth="14" strokeDasharray="18 17" opacity={scan}/>
   <path d="M145 660 C260 730 450 735 700 660" fill="none" stroke={C.ochre} strokeWidth="10" strokeDasharray="20 18" strokeDashoffset={mix(fr,2.1,6.0,800,0)}/>
  </svg><div className="scene-chip" style={{top:1260,left:100,opacity:op}}>PÃO · CESTA · CAIXA</div>
 </div>
}
function Fuel({fr}){
 const op=presence(fr,5.92,9.12,.35), carX=mix(fr,5.92,6.7,120,0), nozzle=mix(fr,6.4,7.1,0,1);
 return <div style={{position:"absolute",top:0,left:0,right:0,height:1240,opacity:op}}>
  <SceneLabel n="03" title="ABASTECIMENTO" sub={<>O carro para.<br/>A bomba aciona.</>} fr={fr} start={6.1} end={9.1}/>
  <svg viewBox="0 0 1000 700" width="1000" height="700" style={{position:"absolute",left:35,top:500}}>
   <g transform={`translate(${carX} 0)`}>
    <path d="M60 405 L130 260 Q160 215 220 215 H550 Q620 215 680 285 L760 330 Q795 350 805 405 V495 H60Z" fill={C.green}/>
    <path d="M220 245 H365 V335 H165Z M400 245 H545 Q595 245 635 320 H400Z" fill={C.cream}/>
    <circle cx="230" cy="500" r="75" fill={C.petrol}/><circle cx="230" cy="500" r="32" fill={C.ochre}/><circle cx="650" cy="500" r="75" fill={C.petrol}/><circle cx="650" cy="500" r="32" fill={C.ochre}/>
   </g>
   <rect x="765" y="85" width="180" height="430" rx="22" fill={C.petrol}/><rect x="790" y="115" width="130" height="125" rx="12" fill={C.cream}/><text x="855" y="171" textAnchor="middle" className="pump-label">BOMBA</text><text x="855" y="208" textAnchor="middle" className="pump-small">ABASTECER</text><rect x="800" y="272" width="110" height="190" rx="15" fill={C.green}/><path d="M825 412 L850 378 L872 395 L897 340" fill="none" stroke={C.cream} strokeWidth="13" strokeLinecap="round" strokeLinejoin="round"/>
   <path d="M780 240 C710 260 716 370 755 392 C780 406 803 387 800 360" fill="none" stroke={C.ochre} strokeWidth="22" strokeDasharray="280" strokeDashoffset={280*(1-nozzle)} strokeLinecap="round"/><path d="M756 381 L726 418 L765 425" fill="none" stroke={C.brick} strokeWidth="14" strokeLinecap="round" strokeLinejoin="round" opacity={nozzle}/>
   <path d="M120 610 C360 660 610 630 760 560" fill="none" stroke={C.brick} strokeWidth="10" strokeDasharray="18 20" strokeDashoffset={mix(fr,6,9,740,0)}/>
  </svg><div className="scene-chip" style={{top:1220,left:100,opacity:op}}>ABASTECIMENTO · ILUSTRATIVO</div>
 </div>
}
function Bill({fr}){
 const op=presence(fr,8.96,12.65,.35), fold=mix(fr,8.98,9.7,8,0), glow=mix(fr,9.1,10.1,.35,1);
 return <div style={{position:"absolute",top:0,left:0,right:0,height:1240,opacity:op}}>
  <SceneLabel n="04" title="EM CASA" sub={<>A conta chega.<br/>A rotina continua.</>} fr={fr} start={9.1} end={12.55}/>
  <svg viewBox="0 0 780 860" width="780" height="860" style={{position:"absolute",right:5,top:450,transform:`rotate(${fold}deg)`,transformOrigin:"60% 15%"}}>
   <path d="M120 80 H470 L650 260 V760 H120Z" fill={C.paper} stroke={C.petrol} strokeWidth="18" strokeLinejoin="round"/><path d="M470 80 V260 H650" fill="none" stroke={C.petrol} strokeWidth="18" strokeLinejoin="round"/>
   <text x="175" y="190" className="bill-label">CONTA DE LUZ</text><path d="M175 250 H550 M175 300 H500 M175 350 H540" stroke={C.ochre} strokeWidth="15" strokeLinecap="round"/><path d="M175 430 H555 M175 475 H520" stroke="#BFC9C2" strokeWidth="13" strokeLinecap="round"/>
   <rect x="165" y="540" width="410" height="100" rx="18" fill={C.cream}/><path d="M175 590 H555" stroke={C.brick} strokeWidth="14" strokeLinecap="round"/>
   <circle cx="400" cy="700" r="84" fill={C.ochre} opacity={.18+.32*glow}/><path d="M405 622 L355 718 H408 L380 790 L470 680 H418 L450 622Z" fill={C.brick}/>
  </svg><div className="scene-chip" style={{top:1330,left:100,opacity:op}}>FATURA ILUSTRATIVA</div>
 </div>
}
// After the four everyday scenes, keep their objects in the visual story:
// the routes converge on an illustrative, value-free receipt, then split into
// two open questions. No invented amounts or allocation claims are shown.
function MoneyFlow({fr}){
 const op=presence(fr,12.58,22,.35);
 const gather=mix(fr,12.58,14.85,0,1), branch=mix(fr,16.35,17.5,0,1);
 const pulse=1+0.025*Math.sin(fr/8);
 const pts=[[142,515],[360,366],[720,366],[938,515]];
 const pathD=[
  "M142 515 C205 520 300 540 433 548",
  "M360 366 C390 430 425 490 485 536",
  "M720 366 C690 430 650 490 595 536",
  "M938 515 C875 520 780 540 647 548"
 ];
 const dot=(i)=>{
   const p=Math.max(0,Math.min(1,(gather-(i*.11))/.89));
   const x=pts[i][0]+(540-pts[i][0])*p;
   const y=pts[i][1]+(548-pts[i][1])*p+Math.sin(p*Math.PI)*(-26);
   return <circle key={i} cx={x} cy={y} r="12" fill={[C.green,C.ochre,C.brick,C.petrol][i]} opacity={op*(p>0.05?1:0)}/>;
 };
 const stamp=mix(fr,15.05,15.35,.72,1.04);
 const receipt=presence(fr,13.75,22,.3);
 const qA=presence(fr,17.1,22,.3);
 return <svg viewBox="0 0 1080 1920" width="1080" height="1920" style={{position:"absolute",inset:0,zIndex:7,pointerEvents:"none",opacity:op}}>
  <g fill="none" strokeLinecap="round" strokeLinejoin="round">
   {pathD.map((d,i)=><path key={i} d={d} pathLength="1000" stroke={[C.green,C.ochre,C.brick,C.petrol][i]} strokeWidth="7" strokeOpacity=".72" strokeDasharray="1000" strokeDashoffset={1000*(1-gather)}/>)}
   <path d="M540 584 C520 640 410 650 325 690" pathLength="1000" stroke={C.green} strokeWidth="8" strokeDasharray="1000" strokeDashoffset={1000*(1-branch)} opacity={qA}/>
   <path d="M540 584 C560 640 670 650 755 690" pathLength="1000" stroke={C.brick} strokeWidth="8" strokeDasharray="1000" strokeDashoffset={1000*(1-branch)} opacity={qA}/>
  </g>
  {pts.map(([x,y],i)=><g key={i} opacity={op*(1-.55*gather)}>
   <circle cx={x} cy={y} r="57" fill={C.cream} stroke={[C.green,C.ochre,C.brick,C.petrol][i]} strokeWidth="7"/>
   {i===0&&<g><rect x={x-19} y={y-30} width="38" height="61" rx="7" fill={C.petrol}/><rect x={x-14} y={y-22} width="28" height="40" rx="3" fill={C.paper}/><path d={`M${x-8} ${y+6} l7 7 14-16`} fill="none" stroke={C.green} strokeWidth="5"/></g>}
   {i===1&&<g fill="none" stroke={C.petrol} strokeWidth="6"><path d={`M${x-28} ${y-14}h10l8 31h32l9-23h-42`}/><circle cx={x-3} cy={y+27} r="4" fill={C.ochre}/><circle cx={x+20} cy={y+27} r="4" fill={C.ochre}/></g>}
   {i===2&&<g><path d={`M${x-30} ${y+12}l10-22q3-7 13-7h20q8 0 15 10l8 8v18h-66z`} fill={C.green}/><circle cx={x-13} cy={y+20} r="8" fill={C.petrol}/><circle cx={x+24} cy={y+20} r="8" fill={C.petrol}/></g>}
   {i===3&&<g><path d={`M${x-22} ${y-32}h28l18 18v47h-46z`} fill={C.paper} stroke={C.petrol} strokeWidth="4"/><path d={`M${x+6} ${y-32}v18h18`} fill="none" stroke={C.petrol} strokeWidth="4"/><path d={`M${x+1} ${y-5}l-10 18h10l-5 13 15-20H1z`} fill={C.brick}/></g>}
  </g>)}
  <g opacity={receipt} transform={`translate(540 550) scale(${mix(fr,13.5,14.3,.78,1)}) translate(-540 -550) translate(0 ${mix(fr,13.5,14.25,28,0)})`}>
   <path d="M420 430 H640 L676 466 V630 H420Z" fill={C.paper} stroke={C.petrol} strokeWidth="8"/>
   <path d="M640 430 V466 H676" fill="none" stroke={C.petrol} strokeWidth="8"/>
   <text x="540" y="476" textAnchor="middle" fill={C.petrol} fontFamily="JetBrains Mono" fontSize="14" letterSpacing="1">DOCUMENTO ILUSTRATIVO</text>
   <path d="M456 528 H640 M456 552 H615 M456 576 H640" stroke={C.ochre} strokeWidth="8" strokeLinecap="round"/>
   <path d="M445 606 H650" stroke={C.brick} strokeWidth="5" strokeDasharray="9 9"/>
  </g>
  {dot(0)}{dot(1)}{dot(2)}{dot(3)}
  <g opacity={qA}>
   <circle cx="300" cy="730" r={mix(fr,17.05,17.7,0,46)*pulse} fill={C.cream} stroke={C.green} strokeWidth="7"/>
   <circle cx="780" cy="730" r={mix(fr,17.05,17.7,0,46)*pulse} fill={C.cream} stroke={C.brick} strokeWidth="7"/>
   <text x="300" y="748" textAnchor="middle" fill={C.green} fontFamily="Teko" fontWeight="700" fontSize="60">?</text>
   <text x="780" y="748" textAnchor="middle" fill={C.brick} fontFamily="Teko" fontWeight="700" fontSize="60">?</text>
  </g>
 </svg>
}
const captions=[
 [0,2.08,"Você recebe seu salário no celular."],
 [2.08,4.40,"Confere o depósito, depois vai ao supermercado,"],
 [4.40,6.12,"escolhe o pão e passa no caixa."],
 [6.12,9.12,"Abastece o carro. Em casa, abre a conta de luz."],
 [9.12,12.56,"São cenas comuns, mas o caminho do dinheiro quase nunca aparece."],
 [12.56,15.16,"E sabe o que pode aparecer em todos esses momentos?"],
 [15.16,16.16,"Impostos!"],
 [16.16,19.00,"Mas espera aí... por que pagamos tantos impostos?"],
 [19.00,20.48,"E para onde vai esse dinheiro?"],
];
function Caption({fr}){
 const sec=fr/30,cue=captions.find(([a,b])=>sec>=a&&sec<b);if(!cue)return null;
 const alpha=Math.min(mix(fr,cue[0],cue[0]+.12,0,1),1-mix(fr,cue[1]-.10,cue[1],0,1));
 return <div className="caption-rail" style={{opacity:alpha}}>{cue[2]}</div>
}
function ProgressPath({fr}){
 const prog=mix(fr,0,14.8,0,1);
 return <svg viewBox="0 0 1080 1920" width="1080" height="1920" style={{position:"absolute",inset:0,pointerEvents:"none",zIndex:1}}>
  <path d="M44 350 C44 460 44 590 44 745 S44 950 44 1080 S44 1240 44 1370" fill="none" stroke={C.ochre} strokeOpacity=".28" strokeWidth="7" strokeDasharray="12 18"/>
  <path d="M44 350 C44 460 44 590 44 745 S44 950 44 1080 S44 1240 44 1370" fill="none" stroke={C.brick} strokeWidth="6" strokeDasharray="1200" strokeDashoffset={1200*(1-prog)} />
  {[370,745,1080,1370].map((y,i)=>{const active=prog>(i+.45)/4;return <g key={y}><circle cx="44" cy={y} r="13" fill={C.cream} stroke={active?C.green:C.ochre} strokeWidth="6"/><circle cx="44" cy={y} r="5" fill={C.brick}/></g>})}
 </svg>
}
export const Opening=()=>{
 const fr=useCurrentFrame();
 const common=presence(fr,12.56,15.18,.12), trib=presence(fr,15.16,16.25,.18);
 const titleK=mix(fr,16.12,16.35,0,1), titleOne=mix(fr,16.35,16.72,0,1), titleTwo=mix(fr,17.05,17.42,0,1), titleSub=mix(fr,19.00,19.3,0,1);
 return <AbsoluteFill style={{background:C.cream,color:C.petrol,overflow:"hidden"}}>
  <Audio src={staticFile("audio/preview-mix-v6-A.wav")} />
  <div className="paper-grain"/><div className="brand-line"><span className="brand-mark">VP</span><span>VIZINHO PÚBLICO</span><span className="brand-divider"/>O DINHEIRO NO DIA A DIA</div>
  <div className="edge-index">ABERTURA<br/><span>ROTINA</span></div>
  <ProgressPath fr={fr}/>
  <Phone fr={fr}/><Market fr={fr}/><Fuel fr={fr}/><Bill fr={fr}/>
  <MoneyFlow fr={fr}/>
  <div className="common-question" style={{opacity:common,transform:`translateY(${mix(fr,12.56,12.9,34,0)}px)`}}>O QUE PODE APARECER EM COMUM?</div>
  <div className="trib-title" style={{opacity:trib,transform:`translateY(${mix(fr,15.16,15.42,35,0)}px) scale(${mix(fr,15.16,15.42,.92,1)})`}}>IMPOSTOS!</div>
  <div className="main-question"><div className="question-kicker" style={{opacity:titleK}}>A PERGUNTA QUE FICA</div><div className="question-line" style={{opacity:titleOne,transform:`translateY(${mix(fr,16.35,16.72,24,0)}px)`}}>POR QUE PAGAMOS</div><div className="question-line highlight" style={{opacity:titleTwo,transform:`translateY(${mix(fr,17.05,17.42,24,0)}px)`}}>IMPOSTOS?</div><div className="question-sub" style={{opacity:titleSub}}>E PARA ONDE VAI ESSE DINHEIRO?</div></div>
  <div className="question-path" style={{opacity:titleTwo,transform:`scaleX(${mix(fr,17.25,18.4,.1,1)})`}}><svg width="900" height="130" viewBox="0 0 900 130"><path d="M20 60 C220 10 330 122 510 60 S740 20 880 73" fill="none" stroke={C.brick} strokeWidth="7" strokeDasharray="13 15"/></svg></div>
  <Caption fr={fr}/><div className="bottom-rule"/>
 </AbsoluteFill>
}
