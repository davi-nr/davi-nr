# Alternativas reais de locução — abertura v6

As três opções foram sintetizadas em takes contínuos pelo Fish Audio, solicitando o alias `s2.1-pro-free`, a referência vocal `ceaf7f569bef42c7bd322d88e3a356b7`, temperature/top-p 0.85, speed 1.0 e normalize=false. A resposta confirmou o alias e a referência; a API não forneceu atestação independente do backend executado.

Os arquivos abaixo permitem comparar pausas e cadência. O ambiente não disponibiliza escuta humana direta; a transcrição automática e as medidas de silêncio confirmam conteúdo/decodificação, não naturalidade vocal. A escolha subjetiva fica disponível ao ouvinte.

### Opção A — Gancho conversacional direto

Duração: `20.480 s`  
Arquivo: `deliverables/audio/opening-v6-a.mp3`

> Você recebe seu salário no celular. Confere o depósito, depois vai ao supermercado, escolhe o pão e passa no caixa. Abastece o carro. Em casa, abre a conta de luz. São cenas comuns, mas o caminho do dinheiro quase nunca aparece. E sabe o que pode aparecer em todos esses momentos? Impostos! Mas espera aí... por que pagamos tantos impostos? E para onde vai esse dinheiro?

### Opção B — Ênfase na pergunta de conexão

Duração: `14.132 s`  
Arquivo: `deliverables/audio/opening-v6-b.mp3`

> Você recebe salário no celular. Vai ao supermercado, escolhe o pão, abastece o carro e depois abre a conta de luz. São partes da rotina. E o que pode surgir em comum entre elas? Impostos! Mas espera aí... por que pagamos tantos impostos? E para onde vai esse dinheiro?

### Opção C — Cadência pausada entre as cenas

Duração: `13.296 s`  
Arquivo: `deliverables/audio/opening-v6-c.mp3`

> O salário chega no celular. Você faz uma compra, abastece o carro, paga a conta de luz. O dinheiro percorre a rotina. E sabe o que pode aparecer nessas situações? Impostos! Mas espera aí... por que pagamos tantos impostos? E para onde vai esse dinheiro?
