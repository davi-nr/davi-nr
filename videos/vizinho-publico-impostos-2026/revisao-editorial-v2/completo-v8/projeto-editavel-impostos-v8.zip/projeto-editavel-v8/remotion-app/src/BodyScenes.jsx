import React from "react";
import {AbsoluteFill, Img, Sequence, interpolate, staticFile, useCurrentFrame} from "remotion";
import captions from "../../deliverables/captions-source.json";

const C={petrol:"#263438",cream:"#F4F1DE",ochre:"#D9A441",brick:"#B9483D",green:"#347A70",paper:"#FFFEF7",muted:"#d8ded6"};
const clamp={extrapolateLeft:"clamp",extrapolateRight:"clamp"};
const S=30;
const e=(x)=>x*x*(3-2*x);
const v=(f,a,b,from,to)=>interpolate(f,[a*S,b*S],[from,to],{...clamp,easing:e});
const opacity=(f,a,b,d=.45)=>Math.min(v(f,a,a+d,0,1),1-v(f,b-d,b,0,1));
const rise=(f,a,d=.55,dy=28)=>({opacity:v(f,a,a+d,0,1),transform:`translateY(${v(f,a,a+d,dy,0)}px)`});

const Header=({num,kicker,title,sub,fr})=><>
  <div className="vp-topline"><span>VIZINHO PÚBLICO</span><span>{String(num).padStart(2,"0")} · {kicker.toUpperCase()}</span></div>
  <div className="vp-kicker" style={rise(fr,.05,.35,14)}>{kicker}</div>
  <h1 className="vp-title" style={rise(fr,.1,.45,24)}>{title}</h1>
  {sub&&<div className="vp-sub" style={rise(fr,.42,.48,15)}>{sub}</div>}
</>;

function Icon({type,color=C.green,size=84}){
 const common={fill:"none",stroke:color,strokeWidth:3,strokeLinecap:"round",strokeLinejoin:"round"};
 const paths={
  school:<><path d="M8 31 42 9l34 22M16 29v39h52V29M32 68V45h20v23"/><path d="M25 37h7m20 0h7"/></>,
  health:<><path d="M15 13h54v57H15z"/><path d="M42 25v33M25 41h34"/></>,
  road:<><path d="M19 70 31 12h22l12 58M35 23h14M32 38h20M28 54h28"/></>,
  coin:<><circle cx="42" cy="42" r="30"/><path d="M51 30c-3-5-16-7-20 1-4 8 5 12 12 13 9 2 12 10 7 16-6 7-20 5-24-2M42 21v42"/></>,
  cart:<><path d="M9 16h11l8 36h39l10-28H23"/><circle cx="36" cy="67" r="4"/><circle cx="62" cy="67" r="4"/></>,
  home:<><path d="M9 36 42 9l33 27M18 31v38h48V31M35 69V48h17v21"/></>,
  tax:<><path d="M18 16h47v53H18zM27 28h27M27 40h27M27 52h17"/><path d="m49 59 7 7 12-15"/></>,
  transfer:<><circle cx="18" cy="42" r="8"/><circle cx="66" cy="19" r="8"/><circle cx="66" cy="65" r="8"/><path d="M27 39 57 23M27 45l30 16"/></>
 };
 return <svg width={size} height={size} viewBox="0 0 84 84" style={{flex:"none",overflow:"visible"}} {...common}>{paths[type]}</svg>
}

function Scene2({fr}){
 const steps=[
  {label:"REMUNERAÇÃO",detail:"salário recebido",start:.4,color:C.green},
  {label:"IMPOSTO DE RENDA",detail:"quando devido, conforme regras",start:2.1,color:C.ochre},
  {label:"NÃO É UNIVERSAL",detail:"nem todo salário paga IR",start:4.0,color:C.brick},
 ];
 return <AbsoluteFill className="vp-scene">
  <Header num={2} kicker="Do bolso ao orçamento" title="Nem todo salário paga IR" sub="Imposto é uma espécie de tributo; a incidência depende das regras." fr={fr}/>
  <div className="payslip">
   <div className="payslip-head"><span>COMPROVANTE ILUSTRATIVO</span><b>RENDA RECEBIDA</b></div>
   <div className="payslip-rule" style={{transform:`scaleX(${v(fr,.25,5.7,0,1)})`}}/>
   {steps.map((s,i)=><div className="payslip-entry" key={s.label} style={{...rise(fr,s.start,.42,18),borderLeftColor:s.color}}><span className="entry-dot" style={{background:s.color}}/><div><b>{s.label}</b><small>{s.detail}</small></div><span className="entry-mark">{i===0?"01":i===1?"02":"03"}</span></div>)}
   <div className="payslip-seal" style={{opacity:v(fr,4.15,4.55,0,1),transform:`rotate(${v(fr,4.15,4.55,-7,-3)}deg)`}}>EXEMPLO<br/>SEM VALORES</div>
  </div>
 </AbsoluteFill>
}

function Scene3({fr}){
 const items=[
  {n:"01",title:"IMPOSTO",body:"Não depende de um serviço individual.",symbol:"I",color:C.green,start:.7},
  {n:"02",title:"TAXA",body:"Ligada a fiscalização ou serviço específico e divisível.",symbol:"T",color:C.ochre,start:4.65},
  {n:"03",title:"CONTRIBUIÇÃO",body:"Tem finalidade prevista na Constituição, como a previdência.",symbol:"C",color:C.brick,start:9.25},
 ];
 return <AbsoluteFill className="vp-scene">
  <Header num={3} kicker="Conceitos" title="Tributo é o nome geral" sub="Imposto, taxa e contribuição não significam a mesma coisa." fr={fr}/>
  <div className="tax-ledger">
    <div className="ledger-top"><span>REGISTRO DE ENTRADA</span><b>TRIBUTO</b><small>categoria jurídica</small></div>
    <div className="taxonomy-spine"><div className="tax-spine-fill" style={{transform:`scaleY(${v(fr,.45,14.4,0,1)})`}}/></div>
    {items.map((it,i)=><div key={it.n} className={`taxonomy-row ledger-row ledger-row-${i}`} style={{top:250+i*190,...rise(fr,it.start,.5,20)}}>
      <div className="tax-bullet" style={{borderColor:it.color,color:it.color}}>{it.symbol}</div>
      <div className="tax-copy"><div className="tax-number">{it.title}</div><div className="tax-description">{it.body}</div></div>
      <div className="tax-line" style={{background:it.color,transform:`scaleX(${v(fr,it.start+.25,it.start+.8,0,1)})`}}/>
      <span className="ledger-mark" style={{color:it.color}}>{it.n}</span>
    </div>)}
    <div className="aggregate-flow" style={rise(fr,13,.45,18)}><Icon type="transfer" color={C.petrol} size={55}/><span>RECURSOS SEGUEM O ORÇAMENTO PÚBLICO</span><small>SEM DESTINAÇÃO AUTOMÁTICA A UMA ESCOLA</small></div>
    <div className="ledger-bottom">IMPOSTO · TAXA · CONTRIBUIÇÃO <i/></div>
  </div>
 </AbsoluteFill>
}

function Scene4({fr}){
 const stages=[
  {x:120,label:"RENDA",example:"Imposto de renda",icon:"coin",start:.7,color:C.green},
  {x:390,label:"CONSUMO",example:"Compras e serviços",icon:"cart",start:5.0,color:C.ochre},
  {x:660,label:"PATRIMÔNIO",example:"IPTU · IPVA",icon:"home",start:9.25,color:C.brick},
 ];
 const rail=v(fr,.45,13.8,0,1);
 return <AbsoluteFill className="vp-scene">
  <Header num={4} kicker="Bases diferentes" title="Onde a tributação aparece" sub="As regras variam conforme renda, consumo e patrimônio." fr={fr}/>
  <div className="incidence-ledger"><div className="incidence-label">BASES DE INCIDÊNCIA <span>EXEMPLOS · REGRAS VARIAM</span></div><div className="base-rail"><div className="base-rail-active" style={{transform:`scaleX(${rail})`}}/>
    {stages.map((s,i)=><div key={s.label} className="base-stop" style={{left:s.x,...rise(fr,s.start,.55,24)}}>
      <div className="base-entry" style={{borderTopColor:s.color}}><div className="base-icon-ring" style={{borderColor:s.color}}><Icon type={s.icon} color={s.color} size={68}/></div>
      <b style={{color:i===1?C.petrol:s.color}}>{s.label}</b><span>{s.example}</span><small>{i===0?"RENDA RECEBIDA":i===1?"BENS E SERVIÇOS":"BENS E VEÍCULOS"}</small></div>
    </div>)}
  </div></div>
  <div className="direct-indirect" style={rise(fr,12.45,.4,12)}><span>IMPOSTOS DIRETOS → RENDA OU BENS</span><i/><span>CONSUMO → TRIBUTOS PODEM ESTAR NO PREÇO</span></div>
  <div className="vp-footnote" style={rise(fr,14.4,.4,10)}>Nem todo salário paga imposto de renda.</div>
 </AbsoluteFill>
}

function Scene5({fr}){
 const nodes=[{label:"UNIÃO",x:730,y:585,color:C.green},{label:"ESTADOS",x:730,y:825,color:C.ochre},{label:"MUNICÍPIOS",x:730,y:1065,color:C.brick}];
 const p=v(fr,.55,6.4,0,1);
 return <AbsoluteFill className="vp-scene">
  <Header num={5} kicker="Federalismo" title="Quem arrecada e transfere" sub="Competências e repasses dividem recursos entre governos." fr={fr}/>
  <div className="federation-map" style={rise(fr,.65,.5,14)}><Img src={staticFile("maps/brazil-outline.svg")}/><div>BRASIL<br/><small>CONTORNO NACIONAL</small></div></div>
  <div className="federation-source" style={rise(fr,.7,.45,14)}>RECEITAS<br/>PRÓPRIAS</div>
  <svg className="federation-lines" viewBox="0 0 1080 980"><path d="M520 280 C620 300 630 220 720 220 M520 490 C620 490 640 460 720 460 M520 700 C620 680 640 700 720 700" fill="none" stroke={C.ochre} strokeWidth="8" strokeDasharray="700" strokeDashoffset={700*(1-p)}/><path d="M995 170 C1060 260 1060 430 995 535" fill="none" stroke={C.brick} strokeWidth="7" strokeDasharray="700" strokeDashoffset={700*(1-v(fr,4.1,7.8,0,1))}/></svg>
  {nodes.map((n,i)=><div className="federation-node" key={n.label} style={{left:n.x,top:n.y,borderColor:n.color,...rise(fr,1.35+i*1.1,.4,20)}}><span style={{background:n.color}}>{i+1}</span><b>{n.label}</b><small>COMPETÊNCIAS PRÓPRIAS</small></div>)}
  <div className="transfer-stamp" style={rise(fr,4.6,.4,10)}>TRANSFERÊNCIAS PREVISTAS EM LEI</div>
  <div className="vp-footnote" style={rise(fr,7.3,.35,12)}>O dinheiro não vai todo para Brasília — e as cidades também arrecadam.</div>
 </AbsoluteFill>
}

function Scene6({fr}){
 const percent=v(fr,.4,4.0,0,32.2), fill=v(fr,3.8,7.1,0,32.2);
 return <AbsoluteFill className="vp-scene">
  <Header num={6} kicker="Contexto nacional · 2024" title="Quanto a arrecadação representa?" sub="Carga tributária bruta — Receita Federal, três níveis de governo." fr={fr}/>
  <div className="gdp-figure"><div className="gdp-value">{percent.toFixed(2).replace(".",",")}<span>%</span></div><div className="gdp-caption">DO PRODUTO INTERNO BRUTO</div>
    <div className="gdp-scale"><div className="gdp-fill" style={{width:`${fill}%`}}/><span>ARRECADAÇÃO</span><b>ECONOMIA · 100%</b></div>
  </div>
  <div className="gdp-method" style={rise(fr,7.4,.45,18)}><div>ARRECADAÇÃO DOS TRÊS NÍVEIS</div><span>÷</span><div>ECONOMIA DO PAÍS</div></div>
  <div className="vp-footnote" style={rise(fr,11.5,.45,10)}>Não é uma alíquota familiar nem uma medida direta do serviço recebido.</div>
 </AbsoluteFill>
}

function Scene7({fr}){
 const bars=[{label:"SAÚDE",value:"R$ 238 BI",ratio:237.893303/1099.807957,color:C.green,start:.55},{label:"EDUCAÇÃO",value:"R$ 169 BI",ratio:169.054306/1099.807957,color:C.ochre,start:4.2},{label:"PREVIDÊNCIA",value:"R$ 1,100 TRI",ratio:1,color:C.brick,start:8.4}];
 return <AbsoluteFill className="vp-scene">
  <Header num={7} kicker="Governo Central · 2025" title="Despesas primárias pagas" sub="Inclui restos a pagar pagos · mesma fonte e unidade monetária." fr={fr}/>
  <div className="budget-chart">
    {bars.map((b,i)=><div key={b.label} className="budget-line" style={rise(fr,b.start,.45,18)}>
      <div className="budget-line-head"><b>{b.label}</b><strong>{b.value}</strong></div>
      <div className="budget-track"><div className="budget-fill" style={{background:b.color,width:`${v(fr,b.start+.25,b.start+1.5,0,b.ratio*100)}%`}}/></div>
    </div>)}
    <div className="budget-scale"><span>0</span><span>COMPARAÇÃO ATÉ R$ 1,100 TRI</span></div>
  </div>
  <div className="vp-footnote" style={rise(fr,13.7,.4,10)}>Exemplos federais; não representam todo o gasto público nem somam o orçamento completo.</div>
 </AbsoluteFill>
}

function Scene8({fr}){
 const stages=[
  {num:"01",name:"JUROS",desc:"Custo da dívida",color:C.brick,t:.7,from:"ESTOQUE DE DÍVIDA",to:"CUSTO FINANCEIRO"},
  {num:"02",name:"AMORTIZAÇÃO",desc:"Pagamento do principal",color:C.green,t:4.45,from:"PRINCIPAL",to:"SALDO MENOR"},
  {num:"03",name:"REFINANCIAMENTO",desc:"Uma dívida substitui outra",color:C.ochre,t:8.0,from:"DÍVIDA VENCIDA",to:"NOVA DÍVIDA"},
 ];
 return <AbsoluteFill className="vp-scene">
  <Header num={8} kicker="Dívida pública" title="Nem todo pagamento é dinheiro novo" sub="A execução distingue despesas primárias e financeiras." fr={fr}/>
  {stages.map((s,i)=><div className="debt-route" key={s.num} style={{top:500+i*290,...rise(fr,s.t,.5,20)}}>
    <div className="debt-num" style={{color:s.color}}>{s.num}</div><div className="debt-name"><b>{s.name}</b><span>{s.desc}</span></div>
    <div className="debt-flow"><span>{s.from}</span><div className="debt-flow-line" style={{background:s.color,transform:`scaleX(${v(fr,s.t+.35,s.t+1.4,0,1)})`}}/><strong>{s.to}</strong></div>
  </div>)}
  <div className="vp-footnote" style={rise(fr,11.0,.4,10)}>Juros, amortização e refinanciamento não equivalem a verba livre para novos serviços.</div>
 </AbsoluteFill>
}

function Scene9({fr}){
 const photoA=v(fr,.25,12.2,0,1), pan=v(fr,.1,12.4,1.02,1.10);
 return <AbsoluteFill className="vp-scene">
  <Header num={9} kicker="Serviços no território" title="Arrecadar não garante qualidade" sub="Planejamento, equipes, compras, manutenção e fiscalização também contam." fr={fr}/>
  <div className="documentary-pair">
    <figure style={{opacity:photoA}}><div className="photo-window"><Img src={staticFile("images/escola-municipal-leonel-sorriso.jpg")} style={{transform:`scale(${pan}) translateX(${v(fr,.1,12.4,-1,1)}%)`}}/></div><figcaption><b>Escola Municipal Leonel de Moura Brizola</b><span>Sorriso/MT · 2017 · registro documental</span><small>Foto: Eugenio Hansen OFS · CC BY-SA 4.0</small></figcaption></figure>
    <figure style={{opacity:v(fr,1.3,12.4,0,1)}}><div className="photo-window"><Img src={staticFile("images/hospital-municipal-mario-gatti.jpg")} style={{transform:`scale(${pan}) translateX(${v(fr,.1,12.4,1,-1)}%)`}}/></div><figcaption><b>Hospital Municipal Dr. Mário Gatti</b><span>Campinas/SP · 2016 · atendimento SUS</span><small>Foto: Raphael H. Figueira · CC BY-SA 4.0</small></figcaption></figure>
  </div>
  <div className="photo-context" style={rise(fr,7.2,.45,14)}>Fotografias reais de contexto; não são uma avaliação nacional da qualidade dos serviços.</div>
 </AbsoluteFill>
}

function Scene10({fr}){
 const phase1=opacity(fr,.45,8.7,.35), phase2=opacity(fr,8.2,17,.45);
 const sweep=v(fr,.7,5.5,0,1);
 return <AbsoluteFill className="vp-scene">
  <Header num={10} kicker="Peso no orçamento familiar" title="O consumo pode pesar mais" sub="A Receita descreve dependência elevada de tributação indireta e perfil regressivo." fr={fr}/>
  <div className="regressive-graphic" style={{opacity:phase1}}>
    <div className="basket-row"><div className="basket-person"><span>RENDA MENOR</span><div className="person-shape small"/></div><div className="basket-icon"><Icon type="cart" color={C.ochre} size={95}/><b>MESMA CESTA</b></div><div className="budget-share"><div className="concept-bar"><i style={{transform:`scaleX(${sweep})`}}/></div><span>MAIOR PESO PROPORCIONAL</span></div></div>
    <div className="basket-divider">MESMO PREÇO · PARCELA DIFERENTE DA RENDA</div>
    <div className="basket-row"><div className="basket-person"><span>RENDA MAIOR</span><div className="person-shape large"/></div><div className="basket-icon"><Icon type="cart" color={C.ochre} size={95}/><b>MESMA CESTA</b></div><div className="budget-share"><div className="concept-bar shorter"><i style={{transform:`scaleX(${sweep})`}}/></div><span>MENOR PESO PROPORCIONAL</span></div></div>
    <div className="concept-note">ESQUEMA CONCEITUAL · SEM ESCALA NUMÉRICA</div>
  </div>
  <div className="tax-reform" style={{opacity:phase2,transform:`translateY(${v(fr,8.2,8.8,35,0)}px)`}}>
    <div className="reform-title">TRANSIÇÃO DO CONSUMO · 2026</div><div className="reform-track"><span>MODELO ATUAL</span><i style={{transform:`scaleX(${v(fr,8.5,16.5,0,1)})`}}/><strong>IBS + CBS</strong></div><small>A mudança é gradual; o sistema anterior ainda não foi totalmente substituído.</small>
  </div>
 </AbsoluteFill>
}

function Scene11({fr}){
 const steps=[{n:"01",t:"ÓRGÃO E PERÍODO",sub:"Filtre as despesas",start:.45},{n:"02",t:"CONTRATOS",sub:"Consulte objeto e fornecedor",start:3.3},{n:"03",t:"EMPENHADO × PAGO",sub:"Compare as etapas da despesa",start:6.1},{n:"04",t:"PEDIDO DE INFORMAÇÃO",sub:"Fala.BR na União; canais locais nos demais entes",start:9.0}];
 return <AbsoluteFill className="vp-scene">
  <Header num={11} kicker="Acesso e transparência" title="Como acompanhar o dinheiro" sub="O acesso à informação é direito de qualquer pessoa." fr={fr}/>
  <div className="audit-path"><div className="audit-line" style={{transform:`scaleY(${v(fr,.2,13.7,0,1)})`}}/>
   {steps.map((s,i)=><div className="audit-step" key={s.n} style={{top:20+i*175,...rise(fr,s.start,.45,18)}}><span style={{background:[C.green,C.ochre,C.brick,C.petrol][i]}}>{s.n}</span><div><b>{s.t}</b><small>{s.sub}</small></div><div className="audit-check" style={{opacity:v(fr,s.start+1,s.start+1.4,0,1)}}>✓</div></div>)}
  </div>
  <div className="audit-links" style={rise(fr,12.8,.4,12)}><span>PORTAL DA TRANSPARÊNCIA</span><i/> <span>PORTAL LOCAL</span><i/><span>LEI DE ACESSO</span></div>
 </AbsoluteFill>
}

function Scene12({fr}){
 const bgScale=v(fr,.1,12.7,1.04,1.12), question=opacity(fr,1.5,8.2,.4), cta=v(fr,8.2,8.7,0,1);
 return <AbsoluteFill className="vp-scene scene-end">
  <Img src={staticFile("images/rio-de-janeiro-panorama.jpg")} className="end-photo" style={{transform:`scale(${bgScale})`}}/>
  <div className="end-overlay"/>
  <div className="vp-topline end-top"><span>VIZINHO PÚBLICO</span><span>ENCERRAMENTO</span></div>
  <div className="end-question" style={{opacity:question,transform:`translateY(${v(fr,1.5,2.0,25,0)}px)`}}><div>O QUE A POPULAÇÃO RECEBE?</div><div>QUEM PAGA MAIS?</div><div>COMO CADA REAL É ADMINISTRADO?</div></div>
  <div className="end-mark" style={{opacity:cta,transform:`translateY(${v(fr,8.2,8.7,22,0)}px)`}}><strong>VIZINHO<br/>PÚBLICO</strong><span>Siga @vizinhopublico</span><i/></div>
 </AbsoluteFill>
}

const sceneStarts=[22.0,28.445438,45.418188,61.084813,71.187376,85.887501,103.879064,116.776752,129.909502,147.430815,164.717065,179.366667];
const sceneData=[Scene2,Scene3,Scene4,Scene5,Scene6,Scene7,Scene8,Scene9,Scene10,Scene11,Scene12];

function TimedScene({Component}){
 const fr=useCurrentFrame();
 return <Component fr={fr}/>;
}

export const BodySceneSequence=()=>{
 const scenes=[];
 for(let i=0;i<sceneData.length;i++){
  const start=Math.round(sceneStarts[i]*S), next=Math.round(sceneStarts[i+1]*S), dur=next-start;
  const Comp=sceneData[i];
  scenes.push(<Sequence key={i} from={start} durationInFrames={dur}><TimedScene Component={Comp}/></Sequence>);
 }
 return <>{scenes}</>;
};

export const Captions=()=>{
 const fr=useCurrentFrame(); const sec=fr/S;
 const cue=captions.find(c=>c.start>=22&&sec>=c.start&&sec<c.end); if(!cue)return null;
 const a=v(fr,cue.start,cue.start+.12,0,1), b=1-v(fr,cue.end-.10,cue.end,0,1);
 return <div className="vp-caption" style={{opacity:Math.min(a,b)}}>{cue.text}</div>;
};
