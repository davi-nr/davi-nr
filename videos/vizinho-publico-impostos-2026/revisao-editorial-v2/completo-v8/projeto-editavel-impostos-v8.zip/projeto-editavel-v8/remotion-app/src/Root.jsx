import React from "react";
import { Composition } from "remotion";
import { FullVideo, TOTAL_FRAMES } from "./FullVideo";

export const RemotionRoot = () => (
  <Composition
    id="FullVideo"
    component={FullVideo}
    durationInFrames={TOTAL_FRAMES}
    fps={30}
    width={1080}
    height={1920}
  />
);
