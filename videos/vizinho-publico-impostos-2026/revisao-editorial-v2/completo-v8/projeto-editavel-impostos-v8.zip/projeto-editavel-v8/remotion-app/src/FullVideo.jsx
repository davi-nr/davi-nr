import React from "react";
import { AbsoluteFill, Audio, OffthreadVideo, Sequence, staticFile } from "remotion";
import { BodySceneSequence, Captions } from "./BodyScenes";

// HyperFrames remains the authoring source for the documentary scenes.
// Remotion joins the separately preserved V7 opening visual to the existing
// body picture and continuous final audio without changing body timing.
export const OPENING_FRAMES = 660;
export const BODY_FRAMES = 4721;
export const TOTAL_FRAMES = OPENING_FRAMES + BODY_FRAMES;

export const FullVideo = () => (
  <AbsoluteFill style={{ backgroundColor: "#263438" }}>
    <Sequence from={0} durationInFrames={OPENING_FRAMES}>
      <OffthreadVideo
        src={staticFile("video/opening-v7-a.mp4")}
        muted
        volume={0}
        style={{ width: 1080, height: 1920, objectFit: "cover" }}
      />
    </Sequence>
    <BodySceneSequence />
    <Audio src={staticFile("audio/full-master-audio.wav")} />
    <Captions />
  </AbsoluteFill>
);
