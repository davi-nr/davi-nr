# Relatório de auditoria — candidato completo revisado

O arquivo de distribuição é `deliverables/reviewed-v8/impostos-candidato-corpo-revisado-v8-final.mp4`. É um candidato novo, separado dos masters anteriores; não representa aprovação editorial automática.

## Integridade e formato

- H.264 High, level 4.0, 1080 × 1920, 30 fps; 5.381 quadros.
- AAC-LC, 48 kHz, estéreo.
- Duração do arquivo final: 179,400 s; tamanho: 22.938.007 bytes.
- A distribuição preserva o vídeo do master e normaliza apenas a faixa AAC. `ffmpeg` decodificou integralmente o MP4 sem erro.
- O MP4 foi exportado com `+faststart`; a estrutura coloca o átomo `moov` antes de `mdat`.
- Loudnorm na faixa do MP4: −16,02 LUFS integrados, LRA 3,0 LU, true peak −1,46 dBTP.
- SHA-256: `ce91ac9be9f031980625e7145b468747ef0c6e66b26834c936d7ef3f145c4394`.

## Áudio e sincronização

A faixa ativa foi reconstruída para usar uma única tomada conversacional Fish Audio na abertura (`assets/audio/opening/opening-v6-a.mp3`, SHA-256 `76cf6e68b5a583b595fc2be90b45794293d6ed45d316c7d42da2b599b224171b`) e os takes existentes das cenas 2–12, nos pontos do roteiro. A trilha contínua foi mantida com ducking side-chain. O WAV e a narração sem música estão disponíveis separadamente; `scripts/build_candidate_audio.py` reproduz o mix.

Whisper.cpp small, sem prompt, aplicado ao AAC real do MP4 V8 nos primeiros 22 segundos, reconheceu a locução conversacional: salário no celular, depósito, supermercado, pão, carro, conta de luz, “Impostos!” e as perguntas sobre por que pagamos impostos e para onde vai o dinheiro. A transcrição e os parâmetros estão em `verification/asr-opening-v7-small.txt` e `verification/asr-opening-v7-info.json`. O ambiente não disponibilizou escuta humana direta; ASR e medições não atestam naturalidade ou interpretação vocal.

## Revisão visual

A prancha `deliverables/reviewed-v7/contact-final.jpg` registra a revisão visual anterior. Para a correção da cena 11, consulte a prancha e os quadros V8 em `deliverables/reviewed-v8/` e o relatório `REVISION-CENA11-V8.md`. Foram conferidos estados da abertura, fases das cenas 2–5, gráficos, fiscalização e encerramento até 179,33 s. A revisão substituiu as composições estáticas encontradas no master anterior nas cenas 3 e 4 por progressões narrativas integradas; a cena 5 agora usa o contorno nacional do Brasil e fluxos próprios/transferências separados. O texto “CONSUMO” foi escurecido para melhorar o contraste, mantendo o símbolo ocre. A cena 11 foi reposicionada na V8 para manter os quatro passos acima das legendas; o CTA permanece visível no quadro final.

Os componentes Remotion não foram validados pelo check legado do HyperFrames, que examina o `index.html`; esse check não é apresentado como aprovação automática de motion, layout ou conteúdo da composição React. A validação audiovisual descrita aqui se refere ao MP4 e aos quadros extraídos. O candidato permanece sujeito à avaliação editorial do usuário.
