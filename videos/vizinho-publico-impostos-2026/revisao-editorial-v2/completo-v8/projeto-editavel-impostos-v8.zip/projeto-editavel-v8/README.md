# Projeto editavel V8

Consulte README-PACOTE.md para requisitos, restauracao dos audios, instalacao e renderizacao do corpo e da abertura. Esta entrega e candidata a avaliacao editorial. As versoes anteriores foram preservadas.
