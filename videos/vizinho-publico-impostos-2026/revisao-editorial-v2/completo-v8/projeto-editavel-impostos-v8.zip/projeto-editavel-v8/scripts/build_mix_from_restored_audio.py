#!/usr/bin/env python3
"""Rebuild the Remotion audio mix from restored, consolidated voice and music."""
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
duration = 179.366667
voice = ROOT / 'deliverables/narration-full-conversational-v7.wav'
music = ROOT / 'assets/audio/music-full.wav'
out = ROOT / 'remotion-app/public/audio/full-master-audio.wav'
out.parent.mkdir(parents=True, exist_ok=True)
graph = (
    f'[0:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,asplit=2[key][voice];'
    f'[1:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,volume=0.10,'
    f'apad=whole_dur={duration:.6f},atrim=duration={duration:.6f}[bed];'
    '[bed][key]sidechaincompress=threshold=0.018:ratio=7:attack=18:release=420[duck];'
    f'[voice][duck]amix=inputs=2:duration=longest:normalize=0:dropout_transition=0,'
    f'alimiter=limit=0.95,atrim=duration={duration:.6f},asetpts=PTS-STARTPTS[out]'
)
subprocess.run([
    'ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(voice),'-i',str(music),
    '-filter_complex',graph,'-map','[out]','-ar','48000','-ac','2','-c:a','pcm_s24le',str(out)
],check=True)
print(f'Wrote {out}')
