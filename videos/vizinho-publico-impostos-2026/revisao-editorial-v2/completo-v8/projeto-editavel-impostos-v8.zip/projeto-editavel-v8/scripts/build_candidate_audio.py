#!/usr/bin/env python3
"""Build the full candidate narration/mix with the conversational V7 opening.

The opening is a single Fish Audio take; body takes remain individually sourced
and aligned to TIMELINE.json. Music is continuous and side-chain ducked by voice.
"""
import json, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
timeline = json.loads((ROOT / "TIMELINE.json").read_text())
duration = float(timeline["duration_seconds"])
inputs = [ROOT / "assets/audio/opening/opening-v6-a.mp3"]
starts = [0.0]
for scene, start in zip(range(2, 13), timeline["scene_starts"][1:]):
    inputs.append(ROOT / f"assets/audio/scenes/{scene:02d}-scene.mp3")
    starts.append(float(start))

voice_out = ROOT / "deliverables/narration-full-conversational-v7.wav"
mix_out = ROOT / "remotion-app/public/audio/full-master-audio.wav"
voice_out.parent.mkdir(parents=True, exist_ok=True)
mix_out.parent.mkdir(parents=True, exist_ok=True)

# Consolidate narration with the conversational opening at zero and scenes 2–12
# at their existing program start times.
voice_filters = []
for i, start in enumerate(starts):
    delay = round(start * 1000)
    voice_filters.append(
        f"[{i}:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,"
        f"adelay={delay}|{delay}[v{i}]"
    )
labels = "".join(f"[v{i}]" for i in range(len(inputs)))
voice_filters.append(
    f"{labels}amix=inputs={len(inputs)}:duration=longest:normalize=0:dropout_transition=0,"
    f"alimiter=limit=0.95,apad=whole_dur={duration:.6f},"
    f"atrim=duration={duration:.6f},asetpts=PTS-STARTPTS[out]"
)
voice_cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"]
for path in inputs:
    voice_cmd += ["-i", str(path)]
voice_cmd += [
    "-filter_complex", ";".join(voice_filters), "-map", "[out]", "-ar", "48000",
    "-ac", "2", "-c:a", "pcm_s24le", str(voice_out)
]
subprocess.run(voice_cmd, check=True)

# Reuse manifested voice WAV and continuous bed for the final mix so they are
# independently available as deliverables and reproducible project inputs.
mix_graph = (
    f"[0:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,"
    f"asplit=2[voice-key][voice];"
    f"[1:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,"
    f"volume=0.10,apad=whole_dur={duration:.6f},atrim=duration={duration:.6f}[bed];"
    "[bed][voice-key]sidechaincompress=threshold=0.018:ratio=7:attack=18:release=420[duck];"
    f"[voice][duck]amix=inputs=2:duration=longest:normalize=0:dropout_transition=0,"
    f"alimiter=limit=0.95,atrim=duration={duration:.6f},asetpts=PTS-STARTPTS[out]"
)
subprocess.run([
    "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
    "-i", str(voice_out), "-i", str(ROOT / "assets/audio/music-full.wav"),
    "-filter_complex", mix_graph, "-map", "[out]", "-ar", "48000", "-ac", "2",
    "-c:a", "pcm_s24le", str(mix_out)
], check=True)

print(json.dumps({
    "opening_source": inputs[0].relative_to(ROOT).as_posix(),
    "opening_sha256": subprocess.check_output(["sha256sum", str(inputs[0])], text=True).split()[0],
    "opening_duration_seconds": float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(inputs[0])], text=True).strip()),
    "body_take_count": 11,
    "program_duration_seconds": duration,
    "narration_output": voice_out.relative_to(ROOT).as_posix(),
    "full_mix_output": mix_out.relative_to(ROOT).as_posix(),
}, ensure_ascii=False, indent=2))
