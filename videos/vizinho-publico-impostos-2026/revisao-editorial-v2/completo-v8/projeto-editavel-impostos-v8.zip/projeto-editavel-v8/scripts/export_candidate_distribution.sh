#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
  echo "Usage: $0 <remotion-master.mp4> <distribution.mp4>" >&2
  exit 2
fi
input_path=$1
output_path=$2
analysis_log=$(mktemp)
trap 'rm -f "$analysis_log"' EXIT

ffmpeg -hide_banner -nostats -i "$input_path" \
  -map 0:a:0 -af 'loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json' \
  -f null - 2>"$analysis_log"

readarray -t measurements < <(python3 - "$analysis_log" <<'PY'
import json, re, sys
text=open(sys.argv[1], encoding='utf-8', errors='replace').read()
blocks=re.findall(r'\{[^{}]*"input_i"[^{}]*\}', text, re.S)
if not blocks: raise SystemExit('Could not parse loudnorm analysis')
d=json.loads(blocks[-1])
for k in ('input_i','input_tp','input_lra','input_thresh','target_offset'):
 print(d[k])
PY
)
if [[ ${#measurements[@]} -ne 5 ]]; then
  echo "Unexpected loudnorm analysis result" >&2
  exit 1
fi

ffmpeg -hide_banner -y -i "$input_path" \
  -map 0:v:0 -map 0:a:0 -c:v copy \
  -af "loudnorm=I=-16:TP=-1.5:LRA=11:measured_I=${measurements[0]}:measured_TP=${measurements[1]}:measured_LRA=${measurements[2]}:measured_thresh=${measurements[3]}:offset=${measurements[4]}:linear=true:print_format=summary" \
  -c:a aac -b:a 192k -ar 48000 -ac 2 -movflags +faststart \
  "$output_path"
