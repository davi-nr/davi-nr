#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,wave
root=Path(__file__).resolve().parent
items=json.loads((root/'AUDIO-RESTORE-MANIFEST.json').read_text())
for x in items:
 p=root/x['wav']; p.parent.mkdir(parents=True,exist_ok=True)
 codec={1:'pcm_u8',2:'pcm_s16le',3:'pcm_s24le',4:'pcm_s32le'}[x['sample_width_bytes']]
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(root/x['flac']),'-c:a',codec,str(p)],check=True)
 with wave.open(str(p),'rb') as w:
  assert (w.getnchannels(),w.getframerate(),w.getsampwidth(),w.getnframes())==(x['channels'],x['sample_rate'],x['sample_width_bytes'],x['frames'])
  got=hashlib.sha256(w.readframes(w.getnframes())).hexdigest()
 assert got==x['pcm_sha256'],(x['wav'],got,x['pcm_sha256'])
 print('Restored and verified:',x['wav'])
