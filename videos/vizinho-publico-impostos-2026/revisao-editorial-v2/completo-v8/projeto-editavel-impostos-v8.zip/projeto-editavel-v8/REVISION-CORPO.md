# Revisão do corpo — candidato Remotion V7

Esta pasta é um candidato separado. Os masters e o projeto original permanecem preservados; este corte não é apresentado como aprovado.

## O que mudou no corpo

A auditoria do master anterior encontrou duas composições que se liam como cartões colocados num fundo: a cena 3 apenas acumulava três blocos em uma área vazia, e a cena 4 mostrava três retângulos isolados. A revisão substitui esses layouts por progressões ligadas ao conteúdo falado:

- **Cena 2 — salário e IR:** um comprovante ilustrativo se preenche conforme a fala diferencia incidência de IR e lembra que nem todo salário paga o imposto. Nenhum valor individual é inventado.
- **Cena 3 — categorias de tributo:** um único livro-caixa recebe, em sequência, imposto, taxa e contribuição; linhas e marcadores conectam cada categoria à sua definição. O fechamento mostra recursos seguindo o orçamento sem destinação automática a uma escola.
- **Cena 4 — bases de incidência:** uma linha contínua avança por renda, consumo e patrimônio, com exemplos ligados a cada etapa. A conclusão visual distingue incidência direta e indireta e preserva a ressalva sobre IR.
- **Cena 5 — federação:** o contorno nacional verificado se conecta aos níveis União, estados e municípios. Fluxos próprios e transferências previstas em lei têm trajetos distintos; não há percentuais ou limites estaduais inventados.
- **Cena 12 — encerramento:** o CTA permanece visível no quadro final, em vez de desaparecer antes do fim do programa.

As cenas 6–11 foram recompostas como componentes Remotion com contagem, escalas compatíveis, fluxos, fotografia documental com crédito, progressão de orçamento, etapas de dívida e navegação de transparência. As falas das cenas 2–12 foram reaproveitadas do master preservado. A abertura visual V7 e sua locução conversacional de uma tomada foram integradas ao candidato; o áudio completo foi reconstruído com a trilha contínua e ducking para evitar reutilizar a abertura anterior.

## Fonte editável e validação

A composição do candidato é `remotion-app/src/FullVideo.jsx`; cenas e animações estão em `remotion-app/src/BodyScenes.jsx` e `remotion-app/src/styles.css`. Remotion 4.0.535 foi usado para compor/renderizar, sob direção HyperFrames. A checagem HyperFrames disponível analisa o `index.html` legado copiado do projeto, não os componentes React desta versão; portanto seus resultados não são apresentados como validação da composição Remotion. A validação visual deste candidato deve ser feita nos quadros e no MP4 exportado.

A ferramenta não forneceu escuta humana direta. Nenhuma afirmação de escuta ou aprovação de interpretação vocal é feita. ASR, timestamps, decodificação e medição de áudio são verificações técnicas e não substituem avaliação auditiva.
