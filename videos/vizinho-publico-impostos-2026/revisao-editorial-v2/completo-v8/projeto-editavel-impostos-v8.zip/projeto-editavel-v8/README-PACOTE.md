# Projeto editável V8 — Por que pagamos impostos?

Candidato V8 em revisão; não substitui as versões anteriores nem implica aprovação editorial. O arquivo de entrada do vídeo completo é `remotion-app/src/index.jsx` (`FullVideo`), com corpo em `remotion-app/src/BodyScenes.jsx`. A abertura V7 editável está separada em `opening-v7/remotion-opening-app/`; o corte completo usa `remotion-app/public/video/opening-v7-a.mp4`.

## Preparação e renderização

Requisitos: Node.js compatível com Remotion 4.0.535, npm, FFmpeg/ffprobe e Chromium. Primeiro execute `python3 restore_audio.py` na raiz do pacote. O script restaura a narração consolidada, a trilha completa e o áudio de referência da abertura a partir de FLAC, conferindo formato, número de amostras e SHA-256 PCM. Em seguida, rode `python3 scripts/build_mix_from_restored_audio.py` para reconstruir o WAV combinado referenciado pelo vídeo. Depois rode `npm ci` em `remotion-app/` e use os comandos abaixo. A aplicação de abertura é editável/re-renderizável separadamente no seu próprio diretório.

```bash
python3 restore_audio.py
python3 scripts/build_mix_from_restored_audio.py
cd remotion-app
npm ci
npx remotion compositions src/index.jsx --browser-executable=/usr/bin/chromium
npx remotion render src/index.jsx FullVideo ../deliverables/reviewed-v8/impostos-candidato-corpo-revisado-v8-master.mp4 --codec=h264 --crf=18 --x264-preset=medium --pixel-format=yuv420p --audio-codec=aac --audio-bitrate=192k --browser-executable=/usr/bin/chromium --concurrency=4 --overwrite
cd ..
bash scripts/export_candidate_distribution.sh deliverables/reviewed-v8/impostos-candidato-corpo-revisado-v8-master.mp4 deliverables/reviewed-v8/impostos-candidato-corpo-revisado-v8-final.mp4
```

A distribuição final foi obtida com normalização EBU R128 em duas passagens (alvo −16 LUFS/−1,5 dBTP), copiando o fluxo de vídeo sem recodificá-lo. As medições e SHA estão em `deliverables/reviewed-v8/`. A duração/mix usam `TIMELINE.json`, `assets/audio/opening/opening-v6-a.mp3`, takes 02–12 e `assets/audio/music-full.wav`; `scripts/build_candidate_audio.py` reconstrói a locução consolidada e o mix após restauração. O áudio abre com o take conversacional A e a trilha contínua, sem importar o fade da prévia.

## Conteúdo e verificação

`SCRIPT.md`, `STORYBOARD.md`, `SCENE-DATA.json`, `FACTS.md`, `ASSET-ATTRIBUTIONS.md`, `CAPTION.md` e `REVISION-CENA11-V8.md` registram conteúdo, dados, créditos e a correção localizada. `deliverables/captions-source.json` alimenta as legendas do programa. As imagens e fontes necessárias à composição estão em `remotion-app/public/`; fontes factuais usadas estão em `assets/research/`. O check legado do HyperFrames sobre `index.html` não valida os componentes React/Remotion. A auditoria audiovisual foi feita em quadros do MP4 exportado. Não acompanha este pacote uma afirmação de escuta humana ou aprovação editorial automática.

As faixas Fish Audio originais 02–12 e abertura A são mantidas como MP3, junto dos manifestos de texto/hash. Nenhuma credencial acompanha o pacote. Para nova síntese, configure a credencial no ambiente seguro; ela não é necessária para reproduzir o vídeo existente.
