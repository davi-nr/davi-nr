# Vizinho Público — Estatal dá prejuízo. E daí?

Projeto editável completo do episódio de aproximadamente 174,43 segundos. A abertura de 25 segundos foi aprovada pelo usuário em 13/10/2026. O projeto e os episódios anteriores permanecem preservados no ambiente de origem.

## Abrir e renderizar

Requisitos: Node.js/npm, Python 3 e FFmpeg. As dependências do CLI são fixadas em HyperFrames 0.8.147 nos scripts do package.json. A configuração de acesso de rede e autenticação depende do ambiente onde este pacote for aberto.

1. Execute `python restore_audio.py` nesta pasta. O script restaura os WAV do manifesto a partir de FLAC sem perdas e verifica os hashes PCM. Os MP3 individuais de narração são os originais vigentes.
2. Execute `npm run check` para verificar a composição. `index.html` é o episódio completo; `index-full.html` conserva a mesma fonte, e `index-preview.html` conserva a prévia aprovada.
3. Para editar/rever, use o Studio do HyperFrames conforme AGENTS.md. Para exportar, use `npm run render`; para replicar a captura fiel, consulte o relatório e os scripts de distribuição. A exportação de distribuição deve ser 1080×1920, 30 fps, H.264 High nível 4.1, AAC e faststart.

`compositions/cover.html` é a fonte da capa. Fontes locais, biblioteca GSAP, imagens e arquivos de voz usados estão incluídos. Os scripts de regeneração da voz dependem de credenciais fornecidas por variáveis de ambiente; nenhuma chave acompanha este pacote. Renderizar os áudios já incluídos não exige chamar o Fish Audio novamente.

## Fontes e direitos

Consulte FACTS.md e ASSET-ATTRIBUTIONS.md para balanços, leis, ressalvas causais, fotografias, autores, licenças e créditos. Os originais fotográficos estão incluídos quando preservados pelo produtor; as transformações editoriais são documentadas. A foto da ETE Barueri é arquivo de 2017, não registro de investimento em 2025.

Manchetes foram citadas em composição própria. Páginas jornalísticas integrais, caches, previews de diagnóstico, tentativas antigas de áudio, node_modules e o master de captura não são redistribuídos neste ZIP. Permanecem preservados no ambiente de origem quando existentes.
