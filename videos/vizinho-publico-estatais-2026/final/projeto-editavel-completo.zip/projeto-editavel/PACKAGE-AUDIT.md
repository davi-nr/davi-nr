# Verificação do pacote editável

- Restauração dos WAV do manifesto a partir de FLAC executada com sucesso; número de amostras, canais, taxa e hashes PCM conferidos.
- 28 referências locais de imagens, fontes, áudio e script das composições incluídas foram verificadas; nenhuma ausente após a restauração.
- index.html corresponde byte a byte à fonte do episódio completo index-full.html. O sidecar de movimento da composição completa acompanha a entrada padrão.
- As onze narrações originais têm SHA256 e hashes de texto conferidos contra o manifesto e o JSON de falas. Caminhos do manifesto foram convertidos para caminhos relativos somente nesta cópia de distribuição.
- WAV não acompanham o ZIP para evitar duplicação; FLAC conservam as amostras sem perdas e restore_audio.py repõe os caminhos que as composições usam.
- Relatório da produção em AUDIT-REPORT.md; verificação independente do MP4 em AUDIT-INDEPENDENTE.md, quando presente.
