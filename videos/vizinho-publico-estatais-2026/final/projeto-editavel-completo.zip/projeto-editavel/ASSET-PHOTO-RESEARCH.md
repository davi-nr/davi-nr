# Pesquisa de mídia visual

## Ativos selecionados para o gate de 25 s

- Correios: agência em Cachoeira do Arari, Pará — `assets/photos/correios-agencia-cachoeira-do-arari.jpg`; derivado 1080 × 1920 da imagem original 6086 × 4057 preservada em `assets/photos/originals/correios-agencia-cachoeira-do-arari-original.jpg`; Prburley, CC BY 4.0, atribuição completa em `ASSET-ATTRIBUTIONS.md`.
- Metrô-SP: estação Santana — `assets/photos/metro-santana-station-2024.jpg`; Jcornelius, CC BY-SA 4.0; foto real de 2024; original Commons 4000 × 1800 px usado, com recorte vertical.
- Manchetes aparecem como texto em layout editorial original, com fonte e data; não são screenshots de notícias.

## Limites

A foto dos Correios mostra uma agência local, não a sede/centro operacional. A foto de Santana situa a estação Metrô-SP, mas não evidencia causa nem desempenho da companhia. Não há imagens licenciadas de empresas usadas para simular operações não fotografadas; a Sabesp será mostrada em gráfico de dados atribuídos, não com instalação genérica.
