# Checagem documental independente — Metrô-SP (setor de transporte)

**Achado utilizável:** exemplo negativo em 2025. A Companhia do Metropolitano de São Paulo registrou **prejuízo líquido contábil (prejuízo do exercício) de R$ 1.058 milhões, isto é, R$ 1,058 bilhão**, no exercício encerrado em 31/12/2025; comparação oficial: R$ 348 milhões em 2024 (+204,02%). É um resultado contábil da empresa, não uma medida isolada de déficit operacional nem o valor de aporte do Tesouro.

## Documento primário e localização

- **Relatório Integrado 2025**, Companhia do Metropolitano de São Paulo, publicação oficial no Portal da Transparência do Metrô: [PDF](https://transparencia.metrosp.com.br/sites/default/files/Relat%C3%B3rio%20Integrado%202025.pdf), dataset [Relatório Integrado – Metrô SP](https://transparencia.metrosp.com.br/dataset/relat%C3%B3rio-integrado%E2%80%93metr%C3%B4-sp). Página impressa 140 (PDF p. 140/163): “prejuízo de R$ 1.058 milhões”; quadro “Resultado Contábil”, unidade “Em milhões de R$”, linha “Prejuízo do Exercício” 2025 -1.058, 2024 -348. No mesmo quadro constam Receita líquida 2.761 vs 3.020, custos dos serviços -2.614 vs -2.652, despesas gerais/administrativas/vendas -1.251 vs -749, resultado financeiro líquido 24 vs 23; o relatório apresenta prejuízo como valor negativo. A descrição corrige possível ambiguidade: R$ 1.058 milhões = R$ 1,058 bilhão.
- Também consultado diretamente o **Relatório Integrado 2024**, mesma série oficial: [PDF](https://transparencia.metrosp.com.br/sites/default/files/RI%202024%20Metr%C3%B4%20de%20S%C3%A3o%20Paulo.pdf), pp. impressas 268–270 (PDF pp. equivalentes 268–270): prejuízo de R$ 348 mi contra R$ 900 mi em 2023; tarifa subiu em 01/01/2024; receitas de breakage de R$ 368 mi; depreciação e amortização R$ 830 mi em 2024 e R$ 731 mi em 2023. A tabela de 2024 registra “Zero de subvenção GESP em 2024” (p. impressa 8, diagrama de materialidade; dado contextual, não reconciliação de todo apoio estatal).
- O site oficial descreve os relatórios integrados e declara que as demonstrações financeiras seguem IFRS/legislação societária, são parte do relatório e auditadas por auditor independente registrado na CVM: [página institucional](https://www.metro.sp.gov.br/metro/sustentabilidade/relatorio-integrado/).

## Causas e limites de inferência

Relatório 2025, p. impressa 140: a companhia aponta como principal razão para a redução de 8,6% na receita operacional líquida a receita de breakage de créditos BU/BOM não usados reconhecida em 2024 (R$ 368 mi), que não se repetiu em 2025. A mesma página diz que despesas gerais/administrativas/vendas aumentaram 67,02%, a R$ 1.251 mi; associa o aumento principalmente a provisão do processo do Consórcio Via Amarela de R$ 167,8 mi e à reversão de R$ 199,7 mi do Consórcio Construcap em 2024. Receita não tarifária caiu de R$ 285 mi para R$ 252 mi. Depreciação e amortização: R$ 838 mi em 2025 vs R$ 830 mi em 2024; componentes do EBITDA ajustam eventos não recorrentes e itens não caixa, portanto não substituem o lucro/prejuízo líquido.

O relatório não sustenta atribuir todo o prejuízo a um fator único. Não chamar os R$ 1,058 bi de “aporte”, “subsídio” ou “rombo pago pelo contribuinte”. Há dados de ressarcimento das gratuidades pelo Estado (R$ 563 mi em 2025) e a estrutura acionária é majoritariamente do Estado (FESP 98,20%), mas isso não prova aporte de capital no mesmo montante do prejuízo. A taxa de cobertura do próprio relatório é outro indicador: receitas operacionais com efeito caixa / gastos operacionais com efeito caixa; foi 100,35% em 2025 (p. 141), enquanto o resultado contábil foi negativo. Distinguir explicitamente esses conceitos.

## Manchete real sobre o mesmo exercício/resultados

- **Diário do Transporte**, Alexandre Pelegi, 08/04/2026, publicado no próprio site: [“Metrô de São Paulo transporta mais passageiros, bate recorde de satisfação, mas prejuízo dispara em 2025”](https://diariodotransporte.com.br/2026/04/08/metro-de-sao-paulo-transporta-mais-passageiros-bate-recorde-de-satisfacao-mas-prejuizo-dispara-em-2025/). Texto da página consultada confirma publicação em 8/4/2026 e informa R$ 1,058 bi, alta de 204%, ausência de R$ 368 mi de breakage do ano anterior e redução das receitas não tarifárias; inclui contexto operacional positivo (892,7 mi passageiros, aprovação alta). A página diz que o balanço foi publicado no Diário Oficial estadual em 8/4/2026. Headline fiel e com contexto, boa referência jornalística.
- Alternativa também real e consultada: **Metrô CPTM**, 15/04/2025, [“Metrô de São Paulo viu prejuízo cair 60% em 2024”](https://www.metrocptm.com.br/metro-de-sao-paulo-viu-prejuizo-cair-60-em-2024/). Texto destaca queda de R$ 900 mi (2023) para R$ 347,5 mi (2024), tarifa de R$ 4,40 para R$ 5,00 e ganhos de receita. O número R$ 347,5 mi diverge ligeiramente do valor arredondado oficial de R$ 348 mi; usar o oficial nas artes. Esta é manchete positiva sobre existência de prejuízo; se narrativa requer manchete negativa, preferir a de 2025 acima.

## Nota editorial sugerida

“Em 2025, o Metrô-SP reportou prejuízo contábil de R$ 1,058 bilhão. A companhia relaciona a piora, entre outros fatores, ao fim de receitas de créditos não usados reconhecidas em 2024 e a provisões judiciais; o valor não corresponde automaticamente a aporte do Tesouro nem ao déficit operacional de caixa.”

## Arquivos efetivamente obtidos/consultados

- `metro-ri-2024.pdf` (32,5 MB) e `metro-ri-2024.txt` (extração local).
- `metro-ri-2025.pdf` (18,1 MB) e `metro-ri-2025.txt` (extração local).
- HTML da página de reportagem de 2025 do Diário do Transporte e da alternativa Metrô CPTM.

Arquivos neste diretório temporário: `/tmp/vp-priv-rebuild-crosscheck`. Nenhum projeto anterior foi alterado.
