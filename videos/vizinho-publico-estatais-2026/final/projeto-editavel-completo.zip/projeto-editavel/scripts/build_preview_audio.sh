#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# The gate is exactly 25 seconds. The three opening voice takes retain their natural lengths;
# 0.75 s separators follow the same plan used by the full script.
ffmpeg -hide_banner -loglevel error -y \
  -i assets/audio/scenes/01-scene.mp3 \
  -i assets/audio/scenes/02-scene.mp3 \
  -i assets/audio/scenes/03-scene.mp3 \
  -i assets/audio/music-original.wav \
  -i assets/audio/newsprint-sfx.wav \
  -filter_complex \
  "[0:a]aformat=sample_rates=48000:channel_layouts=stereo,adelay=0|0[a0];[1:a]aformat=sample_rates=48000:channel_layouts=stereo,adelay=4433|4433[a1];[2:a]aformat=sample_rates=48000:channel_layouts=stereo,adelay=11609|11609[a2];[a0][a1][a2]amix=inputs=3:duration=longest:normalize=0,apad=whole_dur=25,atrim=0:25,asplit=2[voice][side];[3:a]atrim=0:25,asetpts=PTS-STARTPTS,volume=0.15[bed];[bed][side]sidechaincompress=threshold=0.018:ratio=5:attack=60:release=420:makeup=1[duck];[duck][voice]amix=inputs=2:duration=longest:normalize=0[base];[4:a]adelay=0|0,volume=0.55[sfx];[base][sfx]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.89:attack=5:release=60[out]" \
  -map '[out]' -t 25 -ar 48000 -ac 2 -c:a pcm_s16le assets/audio/preview-mix.wav
