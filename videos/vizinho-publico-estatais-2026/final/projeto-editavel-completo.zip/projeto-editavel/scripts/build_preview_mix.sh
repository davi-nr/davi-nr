#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 scripts/build_preview_voice.py
python3 - <<'PY'
import json, pathlib
p=pathlib.Path('assets/audio/preview-voice-timing.json')
d=json.loads(p.read_text())
print(f"Preview voice ends at {d['voice_end_s']:.3f}s")
PY
ffmpeg -hide_banner -loglevel error -y \
  -i assets/audio/preview-voice.wav \
  -i assets/audio/music-original.wav \
  -i assets/audio/newsprint-sfx.wav \
  -filter_complex "[0:a]apad=whole_dur=25,atrim=0:25,asplit=2[voice][side];[1:a]atrim=0:25,asetpts=PTS-STARTPTS,volume=0.15[bed];[bed][side]sidechaincompress=threshold=0.018:ratio=5:attack=60:release=420:makeup=1[duck];[duck][voice]amix=inputs=2:duration=longest:normalize=0[base];[2:a]adelay=0|0,volume=0.55[sfx];[base][sfx]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.89:attack=5:release=60[out]" \
  -map '[out]' -t 25 -ar 48000 -ac 2 -c:a pcm_s16le assets/audio/preview-mix.wav
python3 scripts/normalize_master.py assets/audio/preview-mix.wav assets/audio/preview-mix-normalized.wav
mv assets/audio/preview-mix-normalized.wav assets/audio/preview-mix.wav
