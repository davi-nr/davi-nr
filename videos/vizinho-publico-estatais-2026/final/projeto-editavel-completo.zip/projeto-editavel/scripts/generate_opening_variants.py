#!/usr/bin/env python3
import json, pathlib
from generate_voice import call
P=pathlib.Path(__file__).resolve().parents[1]
variants=json.loads((P/'assets/audio/opening-question-variants.json').read_text())
out=P/'assets/audio/opening-variants'; out.mkdir(parents=True,exist_ok=True)
for i,v in enumerate(variants,30):
 path=out/f"take-{v['id']}.mp3"
 d=call(v['text'],path,i)
 print(json.dumps({'take':v['id'],'bytes':path.stat().st_size,'model':d.get('model'),'normalize':False,'text':v['text']},ensure_ascii=False),flush=True)
