#!/usr/bin/env python3
"""Create timed captions from the approved preview cues plus current full-voice ASR timing."""
from __future__ import annotations

import json
import re
from pathlib import Path

P = Path(__file__).resolve().parents[1]
ASR = P / "assets/audio/verification/full-narration-whisper-small.srt"
PREVIEW = P / "deliverables/preview-captions.srt"
OUT = P / "assets/audio/full-captions.srt"
JSON_OUT = P / "assets/audio/full-captions.json"

BODY_TEXT = [
    "Uma estatal pode ter uma função social importante.",
    "A Lei das Estatais fala em interesse coletivo, mas também em eficiência e acesso economicamente sustentável.",
    "Função social não é carta branca: custos e resultados precisam ser explicados.",
    "Nos Correios, a administração aponta queda de receitas postais tradicionais, custos operacionais,",
    "passivos judiciais, concorrência logística e a manutenção de uma rede ampla.",
    "Esses fatores, por si, não permitem atribuir toda a perda à função social, nem a uma causa só.",
    "No Metrô, a própria companhia aponta uma diferença importante.",
    "Em 2024, reconheceu 368 milhões de reais em créditos de passagem não usados.",
    "Essa receita não se repetiu em 2025.",
    "Isso pesa na comparação, mas não explica sozinho todo o prejuízo.",
    "E atenção: prejuízo contábil não é automaticamente repasse do Tesouro, nem equivale ao caixa da operação.",
    "O Metrô reportou fluxo operacional positivo em 2025.",
    "Também informou 890 milhões de reais para apoiar as linhas concedidas e cobrir perdas na arrecadação do sistema.",
    "São contas diferentes, que precisam ser lidas separadamente.",
    "Privatizar, aqui, significa vender o controle da empresa.",
    "Concessão é diferente: delega um serviço por prazo e contrato.",
    "PPP também é outra estrutura e prevê contraprestação pública.",
    "Em todos os modelos, tarifa, metas, fiscalização e investimento importam.",
    "Trocar o operador não elimina os custos de manter o serviço.",
    "Um estudo comparou três distribuidoras privatizadas e duas públicas de energia no Nordeste, entre 1997 e 2008.",
    "Encontrou melhora financeira nas privatizadas, mas não achou efeito demonstrável na qualidade medida.",
    "É um recorte histórico, não uma regra para todo o setor.",
    "Em saneamento, o governo paulista informou que a Sabesp investiu 15 bilhões e 200 milhões de reais em 2025.",
    "Ante 6 bilhões e 900 milhões no ano anterior.",
    "É um dado atribuído, não prova isolada de causalidade.",
    "No Metrô, a companhia registra apoio público às linhas concedidas.",
    "Contratos, tarifa e fiscalização continuam importando.",
    "Uma estatal não deve ser avaliada só pelo lucro,",
    "mas também não pode usar sua função social como desculpa para desperdício.",
    "E privatizar não é uma solução automática.",
    "O que precisamos perguntar é: quanto custa, quem se beneficia, quem fiscaliza e quem paga essa conta?",
    "Siga o Vizinho Público.",
]


def parse_srt(path: Path):
    chunks = re.split(r"\n\s*\n", path.read_text(encoding="utf-8").strip())
    out = []
    for chunk in chunks:
        lines = chunk.splitlines()
        m = re.match(r"(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})", lines[1])
        if m:
            out.append((parse_time(m.group(1)), parse_time(m.group(2)), " ".join(lines[2:]).strip()))
    return out


def parse_time(s: str) -> float:
    h, m, rest = s.split(":")
    sec, ms = rest.split(",")
    return int(h) * 3600 + int(m) * 60 + int(sec) + int(ms) / 1000


def stamp(t: float) -> str:
    ms = round(t * 1000)
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def split_lines(text: str, limit: int = 68) -> list[str]:
    words = text.split()
    lines, cur = [], []
    for word in words:
        candidate = " ".join(cur + [word])
        if cur and len(candidate) > limit:
            lines.append(" ".join(cur))
            cur = [word]
        else:
            cur.append(word)
    if cur:
        lines.append(" ".join(cur))
    # Two-line cues are preferred. Longer passages become timed subcues.
    return ["\n".join(lines[i:i+2]) for i in range(0, len(lines), 2)]


def main() -> None:
    preview = [
        (0.06, 1.80, "Você já ouviu que uma estatal"),
        (1.80, 3.75, "com prejuízo deveria ser privatizada?"),
        (4.05, 5.43, "Os Correios fecharam"),
        (5.47, 6.47, "dois mil e vinte e cinco"),
        (6.50, 8.05, "com prejuízo líquido de"),
        (8.20, 11.36, "oito vírgula quarenta e seis bilhões de reais."),
        (11.45, 13.19, "E o Metrô de São Paulo, em outro setor,"),
        (13.19, 15.40, "teve prejuízo de pouco mais de um bilhão."),
        (15.46, 17.41, "Mas será que privatizar resolveria?"),
        (17.41, 19.40, "Toda estatal precisa dar lucro?"),
    ]
    asr = parse_srt(ASR)
    if len(asr) != 36 or len(BODY_TEXT) != 32:
        raise SystemExit(f"Unexpected caption inputs: ASR={len(asr)}, body={len(BODY_TEXT)}")
    cues = [{"start": a, "end": b, "text": text, "source": "prévia aprovada; cue revisado"} for a, b, text in preview]
    for (start, end, _), text in zip(asr[4:], BODY_TEXT):
        start = max(start, 25.0)
        parts = split_lines(text)
        weights = [max(1, len(x.split())) for x in parts]
        total = sum(weights)
        cursor = start
        usable = max(0.1, end - start - 0.04)
        for i, (part, weight) in enumerate(zip(parts, weights)):
            duration = usable * weight / total
            finish = end - 0.02 if i == len(parts) - 1 else cursor + duration
            cues.append({"start": cursor, "end": finish, "text": part, "source": "segmento ASR sem prompt; texto corrigido para roteiro"})
            cursor = finish + 0.02
    for c in cues:
        if c["start"] >= c["end"] or c["end"] - c["start"] < 0.45:
            raise SystemExit(f"Caption cue too short/invalid: {c}")
    cues.sort(key=lambda x: x["start"])
    for a, b in zip(cues, cues[1:]):
        if a["end"] > b["start"] + 0.001:
            raise SystemExit(f"Caption overlap: {a} / {b}")
    blocks = []
    for i, c in enumerate(cues, 1):
        blocks.append(f"{i}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}")
    OUT.write_text("\n\n".join(blocks) + "\n", encoding="utf-8")
    JSON_OUT.write_text(json.dumps(cues, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"cues": len(cues), "min_s": round(min(c['end']-c['start'] for c in cues), 3), "max_lines": max(len(c['text'].splitlines()) for c in cues), "last_end_s": round(cues[-1]['end'], 3)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
