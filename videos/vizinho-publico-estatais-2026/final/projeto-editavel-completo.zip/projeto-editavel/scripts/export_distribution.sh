#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
INPUT="${1:-$ROOT/deliverables/estatal-da-prejuizo-hyperframes-master.mp4}"
OUTPUT="${2:-$ROOT/deliverables/estatal-da-prejuizo-final.mp4}"
ffmpeg -hide_banner -y -i "$INPUT" -map 0:v:0 -map 0:a:0 -c:v libx264 -preset medium -crf 20 -profile:v high -level:v 4.1 -pix_fmt yuv420p -c:a copy -movflags +faststart "$OUTPUT"
