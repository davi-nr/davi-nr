#!/usr/bin/env python3
import json,subprocess,wave
from pathlib import Path
P=Path(__file__).resolve().parents[1]; A=P/'assets/audio'; S=A/'scenes'
rate=48000; channels=2; width=2; gap=.75; spans=[]; cursor=0
with wave.open(str(A/'preview-voice.wav'),'wb') as w:
 w.setnchannels(channels);w.setsampwidth(width);w.setframerate(rate)
 for i in range(1,4):
  src=S/f'{i:02d}-scene.mp3'
  raw=subprocess.run(['ffmpeg','-v','error','-i',str(src),'-f','s16le','-acodec','pcm_s16le','-ar',str(rate),'-ac',str(channels),'-'],stdout=subprocess.PIPE,check=True).stdout
  dur=len(raw)/(rate*channels*width)
  if i>1:
   w.writeframes(b'\0'*(round(gap*rate)*channels*width));cursor+=gap
  start=cursor;w.writeframes(raw);cursor+=dur
  spans.append({'scene':i,'start_s':round(start,6),'end_s':round(cursor,6),'duration_s':round(dur,6)})
(A/'preview-voice-timing.json').write_text(json.dumps({'scenes':spans,'gap_s':gap,'voice_end_s':round(cursor,6),'program_s':25},indent=2)+'\n')
print(json.dumps({'voice_end_s':cursor,'program_s':25,'scenes':spans},indent=2))
