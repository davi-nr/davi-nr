#!/usr/bin/env python3
"""Build the post-gate full narration while preserving the approved 25 s intro."""
from __future__ import annotations

import json
import subprocess
import wave
from pathlib import Path

P = Path(__file__).resolve().parents[1]
A = P / "assets/audio"
SCENES = A / "scenes"
RATE, CHANNELS, WIDTH = 48_000, 2, 2
GAP = 0.75
PREVIEW_PROGRAM_S = 25.0
PROGRAM_HOLD_S = 5.0
OUT = A / "narration-full-aligned.wav"
TIMING = A / "full-voice-timing.json"


def decode(path: Path) -> tuple[bytes, float]:
    raw = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(path), "-f", "s16le", "-acodec", "pcm_s16le", "-ar", str(RATE), "-ac", str(CHANNELS), "-"],
        stdout=subprocess.PIPE, check=True,
    ).stdout
    return raw, len(raw) / (RATE * CHANNELS * WIDTH)


def main() -> None:
    preview = A / "preview-voice.wav"
    with wave.open(str(preview), "rb") as r:
        if (r.getframerate(), r.getnchannels(), r.getsampwidth()) != (RATE, CHANNELS, WIDTH):
            raise SystemExit("Preview voice must be PCM16, 48 kHz stereo")
        intro = r.readframes(r.getnframes())
    intro_duration = len(intro) / (RATE * CHANNELS * WIDTH)
    if intro_duration > PREVIEW_PROGRAM_S:
        raise SystemExit("Approved preview narration exceeds 25 seconds")

    spans = []
    cursor = 0.0
    with wave.open(str(OUT), "wb") as w:
        w.setnchannels(CHANNELS)
        w.setsampwidth(WIDTH)
        w.setframerate(RATE)
        w.writeframes(intro)
        preview_timing = json.loads((A / "preview-voice-timing.json").read_text())
        for item in preview_timing["scenes"]:
            spans.append({"scene": item["scene"], "voice_start_s": item["start_s"], "voice_end_s": item["end_s"], "duration_s": item["duration_s"], "timing_status": "medido; take aprovado na prévia"})
        cursor = intro_duration
        pre_body_silence = max(0.0, PREVIEW_PROGRAM_S - cursor)
        w.writeframes(b"\0" * round(pre_body_silence * RATE) * CHANNELS * WIDTH)
        cursor += pre_body_silence
        for scene in range(4, 12):
            if scene > 4:
                w.writeframes(b"\0" * round(GAP * RATE) * CHANNELS * WIDTH)
                cursor += GAP
            raw, duration = decode(SCENES / f"{scene:02d}-scene.mp3")
            start = cursor
            w.writeframes(raw)
            cursor += duration
            spans.append({"scene": scene, "voice_start_s": round(start, 6), "voice_end_s": round(cursor, 6), "duration_s": round(duration, 6), "timing_status": "medido no take vigente"})
        voice_end = cursor
        w.writeframes(b"\0" * round(PROGRAM_HOLD_S * RATE) * CHANNELS * WIDTH)
        cursor += PROGRAM_HOLD_S

    timing = {
        "inter_scene_gap_s": GAP,
        "approved_preview_s": PREVIEW_PROGRAM_S,
        "preview_voice_end_s": round(intro_duration, 6),
        "body_start_s": PREVIEW_PROGRAM_S,
        "voice_end_s": round(voice_end, 6),
        "program_hold_s": PROGRAM_HOLD_S,
        "program_duration_s": round(cursor, 6),
        "scenes": spans,
        "status": "provisional timing from decoded current MP3 takes; not a rendered-film audit",
    }
    TIMING.write_text(json.dumps(timing, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"voice_end_s": round(voice_end, 6), "program_duration_s": round(cursor, 6), "scenes": spans}, ensure_ascii=False))


if __name__ == "__main__":
    main()
