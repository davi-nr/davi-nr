#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 scripts/build_full_narration.py
duration=$(python3 -c "import json; print(json.load(open('assets/audio/full-voice-timing.json'))['program_duration_s'])")
python3 scripts/generate_original_music.py "$duration" assets/audio/music-full-original.wav
ffmpeg -hide_banner -loglevel error -y \
  -i assets/audio/narration-full-aligned.wav \
  -i assets/audio/music-full-original.wav \
  -i assets/audio/newsprint-sfx.wav \
  -filter_complex "[0:a]atrim=0:${duration},asplit=2[voice][side];[1:a]atrim=0:${duration},asetpts=PTS-STARTPTS,volume=0.15[bed];[bed][side]sidechaincompress=threshold=0.018:ratio=5:attack=60:release=420:makeup=1[duck];[duck][voice]amix=inputs=2:duration=longest:normalize=0[base];[2:a]adelay=0|0,volume=0.55[sfx];[base][sfx]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.89:attack=5:release=60[out]" \
  -map '[out]' -t "$duration" -ar 48000 -ac 2 -c:a pcm_s16le assets/audio/full-mix-pre-normalized.wav
python3 scripts/normalize_master.py assets/audio/full-mix-pre-normalized.wav assets/audio/full-mix.wav
