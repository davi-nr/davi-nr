from pathlib import Path
import json,subprocess,wave,hashlib
root=Path(__file__).resolve().parent
for row in json.loads((root/'AUDIO-RESTORE-MANIFEST.json').read_text()):
    target=root/row['wav']
    subprocess.run(['ffmpeg','-v','error','-i',str(root/row['flac']),'-c:a','pcm_s16le','-y',str(target)],check=True)
    with wave.open(str(target),'rb') as w:
        assert w.getnchannels()==row['channels'] and w.getframerate()==row['sample_rate'] and w.getsampwidth()==row['sample_width'] and w.getnframes()==row['frames']
        assert hashlib.sha256(w.readframes(w.getnframes())).hexdigest()==row['pcm_sha256']
    print('Restaurado e verificado:',row['wav'])
