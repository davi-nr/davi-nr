HYPERFRAMES — REVISÃO FINAL DO VÍDEO DOS TRABALHADORES

MISSÃO

Revisar e aprimorar o vídeo existente:
vizinho-publico-trabalhadores-2026-final.mp4
Projeto: Vizinho Público
Tema: Lula × Flávio Bolsonaro — Propostas para os trabalhadores.

Esta é uma revisão de pós-produção, não uma nova produção do zero.
O Codex deve localizar e acionar efetivamente o subagente HyperFrames, delegando a ele a revisão audiovisual completa.
O Remotion poderá ser utilizado pelo HyperFrames como ferramenta técnica, mas não deve substituir a orquestração do subagente.
Preserve o projeto editável original, a identidade visual, as caricaturas, os documentos, os gráficos e as boas transições já existentes.

1. PROBLEMAS IDENTIFICADOS

O vídeo está visualmente satisfatório, mas precisa de quatro correções principais.

A. Pronúncia da narração
Corrigir imediatamente erros como a leitura de “40 h” como “quarenta agá”.
Na entrada do Fish Audio, escrever:
“quarenta horas semanais”
Nunca enviar abreviações de unidades ao sintetizador.
Exemplos:
* 44h → quarenta e quatro horas
* 40h → quarenta horas
* 5x2 → cinco por dois
* 6x1 → seis por um
* 13º → décimo terceiro
* R$ 5.000 → cinco mil reais
As abreviações podem continuar aparecendo nos elementos gráficos, mas não no texto de síntese vocal.
Verificar também PEC, CLT, FGTS, valores monetários, nomes próprios e siglas.

B. Clareza narrativa
A explicação ficou confusa em determinados momentos.
Simplificar as transições entre os temas.
Cada bloco deve responder claramente:
1. Qual é a proposta?
2. Como ela funcionaria?
3. O que mudaria para o trabalhador?
4. Quais vantagens e riscos podem existir?
5. A medida já está em vigor ou ainda depende de aprovação?
Não misturar o texto de uma PEC com promessas eleitorais genéricas.

C. Aplicação prática
O vídeo precisa mostrar efeitos sobre:
* Jornada semanal.
* Salário mensal.
* Folgas remuneradas.
* Férias.
* Décimo terceiro.
* FGTS.
* Atestados médicos e faltas justificadas.
* Segurança e previsibilidade da renda.
* Negociação individual e coletiva.

D. Conclusão insuficiente
Substituir o encerramento anterior por uma conclusão que apresente os impactos concretos e os pontos ainda indefinidos das duas propostas.
Não transformar riscos hipotéticos em fatos consumados.

2. ROTEIRO REVISADO DE NARRAÇÃO

Utilizar o texto abaixo como nova referência editorial.
Ajustar a distribuição entre cenas após gerar a narração, buscando uma duração entre três minutos e três minutos e quarenta segundos.

ABERTURA
“Lula e Flávio Bolsonaro apresentam caminhos diferentes para mudar a vida de quem trabalha.
Mas o que aconteceria com seu salário, suas folgas e seus direitos?
Vamos olhar as propostas e entender como elas funcionariam na prática.”

A ESCALA ATUAL
“Hoje, muitos brasileiros trabalham seis dias e descansam apenas um.
E é justamente essa realidade que está no centro de duas propostas diferentes.”

PROPOSTA APOIADA POR LULA
“A primeira é a proposta de emenda constitucional número duzentos e vinte e um, de dois mil e dezenove, apoiada pelo governo Lula.
Ela prevê reduzir a jornada máxima semanal de quarenta e quatro para quarenta horas.
Com cinco dias de trabalho, dois dias de descanso remunerado e sem redução salarial.
A mudança seria gradual.
Mas atenção: essa proposta ainda precisa concluir sua tramitação no Congresso.”

PROPOSTA APOIADA POR FLÁVIO BOLSONARO
“Já Flávio Bolsonaro apoia a proposta de emenda constitucional número doze, de dois mil e vinte e seis, apresentada por Rogério Marinho, da qual Flávio também é signatário.
Ela permite optar entre o regime tradicional e um contrato com jornada flexível, remunerada por hora trabalhada.
A ideia defendida pelos autores é dar maior liberdade para negociar horários e quantidade de trabalho.
Mas existe uma diferença fundamental.
Nesse regime flexível, menos horas também podem representar um salário menor.
Férias, décimo terceiro e depósitos do FGTS continuariam previstos, mas calculados proporcionalmente à jornada.”

FOLGAS REMUNERADAS
“E as folgas?
Na proposta apoiada por Lula, os dois dias de descanso semanal seriam remunerados, sem redução do salário.
No regime flexível defendido por Flávio, trabalhar menos dias não significa necessariamente receber pelos dias sem trabalho.
Tudo depende das regras aplicáveis ao contrato.”

E SE O TRABALHADOR FICAR DOENTE?
“Agora, imagine uma situação comum: você fica doente e precisa apresentar um atestado médico.
Pela legislação atual, existem proteções para faltas justificadas por doença e para o pagamento dos primeiros dias de afastamento, nos casos previstos em lei.
A proposta de trabalho por hora não declara que essas proteções deixam de existir.
Mas ela levanta uma dúvida importante: como seriam calculados os pagamentos nos períodos em que o trabalhador não consegue cumprir as horas previstas por motivo de saúde?
Essa questão precisa ser esclarecida juridicamente, antes de qualquer conclusão sobre perda de direitos.”

PREVISIBILIDADE DA RENDA
“Existe outra preocupação: a renda no fim do mês.
Quem recebe por uma jornada fixa consegue planejar suas contas com maior previsibilidade.
Num modelo remunerado pelas horas realizadas, uma jornada reduzida pode significar remuneração menor.
Por outro lado, os defensores da flexibilidade argumentam que ela pode facilitar a conciliação entre trabalho, estudo e vida pessoal.”

A REALIDADE DA PROPOSTA DE LULA
“E a proposta apoiada por Lula também tem desafios.
Reduzir a jornada mantendo o salário aumenta o custo da hora de trabalho para a empresa.
Negócios podem precisar reorganizar escalas, contratar mais pessoas ou melhorar sua produtividade.
Possíveis impactos sobre preços e empregos dependem do setor e de como as empresas se adaptariam.
Não são consequências automáticas.”

A REALIDADE DA PROPOSTA APOIADA POR FLÁVIO
“Já a alternativa apoiada por Flávio oferece maior flexibilidade contratual, mas também pode trazer renda menos previsível e benefícios de menor valor, quando a jornada é reduzida.
Outra diferença é que o texto dá mais força aos acordos individuais, inclusive diante de negociações coletivas.
Por isso, é fundamental discutir a proteção de quem tem menor poder de negociação e esclarecer regras para folgas, afastamentos por doença e remuneração.”

CONCLUSÃO
“Então, as duas propostas não são iguais.
Uma estabelece redução da jornada com manutenção salarial e dois descansos remunerados, mas exige adaptação das empresas.
A outra amplia a flexibilidade e a negociação individual, mas permite remuneração e benefícios proporcionais, além de deixar questões importantes que precisam ser esclarecidas.
E nenhuma das duas deve ser apresentada como uma mudança já implementada.
Conhecer as regras é essencial para entender seus possíveis efeitos.
Siga @vizinhopublico.”

3. DIREÇÃO VISUAL DOS NOVOS BLOCOS

Preservar as cenas visualmente aprovadas.
Reaproveitar os gráficos, contracheques, calendários e documentos existentes.
Adicionar somente as composições necessárias para esclarecer os efeitos reais das propostas.

Cena — Folgas remuneradas
Dividir a tela em duas áreas.
Na primeira:
“PEC 221”
“DOIS DESCANSOS REMUNERADOS”
“SALÁRIO PRESERVADO”
Na segunda:
“PEC 12”
“JORNADA FLEXÍVEL”
“REMUNERAÇÃO PROPORCIONAL”
A composição deve representar precisamente cada regime, sem sugerir que a PEC 12 elimina automaticamente o repouso semanal remunerado ou outros direitos atuais.

Cena — Atestado médico
Criar um documento médico ilustrativo.
Revelar a pergunta:
“E SE VOCÊ FICAR DOENTE?”
Em seguida, apresentar três etiquetas:
“DIREITO ATUAL”
“CONTRATO FLEXÍVEL”
“PONTO A ESCLARECER”
Não colocar um carimbo falso de “ATESTADO NEGADO”.
Não utilizar afirmações como “atestados deixam de valer” ou “folgas abonadas deixam de existir”.
Mostrar visualmente a diferença entre proteção legal atual e dúvidas de implementação do novo regime.

Cena — Previsibilidade de renda
Criar dois contracheques ilustrativos:
* Um com remuneração mensal fixa.
* Outro com remuneração variável de acordo com as horas contratadas ou realizadas.
Se utilizar valores em reais, definir hipóteses matemáticas explícitas, respeitar os pisos aplicáveis e validar os cálculos.
Não apresentar simulações como previsões econômicas.

Cena — Custos e adaptações
Mostrar calendário de trabalho, escala de funcionários e gráfico de custo por hora.
Diferenciar aumento do custo por hora de aumento necessariamente proporcional do custo total da empresa.
Indicar que eventuais efeitos sobre contratações, preços e produtividade dependem de fatores econômicos e organizacionais.

Cena — Comparação final
Criar dois painéis editoriais.
PEC 221 — Apoiada por Lula
* Jornada máxima de quarenta horas.
* Dois descansos remunerados.
* Salário preservado.
* Necessidade de adaptação empresarial.
PEC 12 — Apresentada por Rogério Marinho e apoiada por Flávio Bolsonaro
* Opção de jornada flexível.
* Pagamento proporcional.
* Benefícios proporcionais à jornada.
* Maior peso do contrato individual.
* Questões de proteção e previsibilidade a esclarecer.
Dar tratamento visual equivalente aos dois painéis.
Nenhum painel deve conter símbolos de aprovação, reprovação, vencedor ou perdedor.

4. AUDITORIA JURÍDICA OBRIGATÓRIA

Consultar os textos originais das duas PECs e a legislação atual.
PEC 12/2026 — Senado Federal:
https://www25.senado.leg.br/web/atividade/materias/-/materia/174362
Texto integral da PEC 12/2026:
https://legis.senado.leg.br/sdleg-getter/documento?disposition=inline&dm=10233767
PEC 221/2019 — Câmara dos Deputados:
https://www.camara.leg.br/propostas-legislativas/2212204
Lei 605/1949 — Repouso semanal e faltas justificadas:
https://www.planalto.gov.br/ccivil_03/leis/l0605.htm
Lei 8.213/1991 — Benefícios previdenciários:
https://www.planalto.gov.br/ccivil_03/leis/l8213cons.htm
Verificar especialmente:
* Como as duas PECs tratam as folgas.
* Remuneração por hora.
* Proporcionalidade dos benefícios.
* Ausências justificadas.
* Atestados médicos.
* Afastamentos por doença.
* Repouso semanal remunerado.
* Regras de negociação individual e coletiva.
Diferenciar rigorosamente:
1. Direito atualmente garantido.
2. Alteração expressa no projeto.
3. Consequência possível da mudança.
4. Questão ainda não regulamentada.
5. Interpretação ou crítica de especialistas.
Não inventar supressão de direitos.
Verificar o andamento legislativo até 11/10/2026 e atualizar as informações se a publicação ocorrer posteriormente.

5. CORREÇÃO DO FISH AUDIO

Utilizar novamente:
Fish Audio S2.1 Pro Free
Voz oficial:
“Mulher do Criativo top”
Reference ID:
ceaf7f569bef42c7bd322d88e3a356b7
Preservar a identidade vocal do vídeo anterior.
Corrigir a preparação dos textos enviados ao sintetizador.
Manter dois campos separados por cena:
* display_text: texto exibido na tela, podendo conter abreviações.
* narration_text: texto escrito conforme deve ser pronunciado.
Não enviar ao sintetizador elementos de layout, tags visuais, números abreviados ou instruções técnicas.
Regenerar os áudios problemáticos e os blocos modificados.
Validar os arquivos e ouvir os segmentos para conferir a pronúncia.
Conferir especialmente “quarenta horas”, “quarenta e quatro horas”, “décimo terceiro”, “CLT”, “FGTS” e “PEC”.
Não alterar a voz oficial para resolver problemas de pronúncia que podem ser solucionados pela normalização do texto.

6. PRESERVAÇÃO E RENDERIZAÇÃO

Manter as animações e transições corretas do vídeo anterior.
Não refazer o projeto inteiro.
Para as cenas cuja narração mudou:
1. Gerar o novo áudio.
2. Recalcular os tempos.
3. Ajustar elementos gráficos.
4. Reconferir legendas.
5. Renderizar e auditar.
O arquivo de revisão recebido está em 512 × 910 pixels.
Caso o projeto original possua composições e assets em maior resolução, exportar o novo vídeo diretamente em 1080 × 1920, sem apenas ampliar artificialmente o arquivo comprimido.
Manter o vídeo vertical em 9:16.
Executar a auditoria visual sobre o MP4 final, verificando sobreposições, cortes de texto, sincronização e legendas.
Criar uma nova versão final, preservando a anterior para comparação.

7. ENTREGÁVEIS

Entregar:
* Novo vídeo MP4 revisado.
* Projeto editável.
* Narrações corrigidas.
* Roteiro final.
* Lista dos trechos alterados.
* FACTS.md atualizado.
* Relatório da verificação jurídica.
* Relatório da auditoria audiovisual.
Não encerrar após produzir o roteiro. Executar a revisão completa usando o HyperFrames.
O objetivo é preservar a qualidade visual já alcançada, corrigir a locução e transformar uma comparação abstrata entre propostas em uma explicação concreta sobre o cotidiano dos trabalhadores.
