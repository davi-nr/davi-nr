# Vizinho Público — Lula × Flávio e trabalho

Documentário editorial vertical em português brasileiro sobre jornada, folgas, renda e propostas trabalhistas. Corte factual: 11/10/2026. Composição e exportação pelo HyperFrames 0.8.147, em 1080 × 1920, 30 fps.

## Arquivos principais

- Vídeo final auditado: `deliverables/vizinho-publico-trabalhadores-2026-revisado.mp4` (arquivo disponibilizado separadamente do ZIP editável).
- Capa: `deliverables/capa-instagram.jpg`; composição editável em `cover/index.html`.
- Narração por cena: `assets/audio/scenes/01-scene.mp3` a `11-scene.mp3`.
- Narração consolidada: `assets/audio/narration-consolidated.wav`.
- Trilha original: `assets/audio/music-original.wav`; versão estendida com crossfade e fade-out: `assets/audio/music-extended.wav`; mix e master normalizada: `assets/audio/final-mix.wav` e `assets/audio/final-mix-normalized.wav`.
- Legendas: `assets/audio/captions.srt`.
- Roteiro e temporização: `SCRIPT.md`, `scene-text.json`, `STORYBOARD.md`, `NARRATION-TIMING.md`.
- Pesquisa, fontes e limitações: `FACTS.md`, `LEGAL-VERIFICATION.md`, `TSE-IA-NOTE.md`, `ASSET-ATTRIBUTIONS.md`.
- Histórico das alterações: `REVISION-CHANGES.md`.
- Projeto editável: `index.html`, `compositions/frames/`, `scripts/`, `assets/`.
- Folha de contato extraída do MP4 final: `snapshots/final-mp4/contact-sheet-final-mp4.jpg`; relatório: `AUDIT-REPORT.md`.

O pacote editável conserva os WAVs em FLAC lossless para reduzir o tamanho. Após extrair o ZIP, no diretório `project/`, execute `bash scripts/restore_audio.sh` para restaurar os WAVs referenciados pelo projeto; em seguida, siga os comandos de instalação/renderização abaixo. O script requer FFmpeg e preserva as amostras de áudio.

## Abrir, conferir e renderizar

Requisitos: Node.js 20+, Python 3.11+, FFmpeg e Chrome/Chromium compatível. Na pasta `project/`:

```sh
npm ci
python scripts/assemble_index.py
npx hyperframes check --json
npx hyperframes preview
```

Para reproduzir a exportação fiel por screenshots (sem fast capture):

```sh
PRODUCER_BROWSER_GPU_MODE=software npx hyperframes render --fps 30 --workers 2 --quality delivery --resolution portrait --experimental-fast-capture=false --no-page-side-compositing --output deliverables/vizinho-publico-trabalhadores-2026-revisado.mp4
```

O projeto fixa HyperFrames 0.8.147 e GSAP 3.14.2 em `package.json`; `npm ci` reinstala as dependências locais, sem depender de caminho absoluto do plugin. A master usada pelo `index.html` é `assets/audio/final-mix-normalized.wav`. `bash scripts/build_mix.sh` executa `scripts/extend_music.py` para reutilizar um trecho interior da trilha com crossfade suave e fade-out ao fim do programa, remixa voz e trilha, e normaliza uma cópia WAV em dois passes para −16 LUFS e true peak máximo de −1 dBTP. A faixa original `music-original.wav` não é alterada. Depois, `python scripts/assemble_index.py` regenera a composição que referencia a master.

## Fish Audio

A voz solicitada foi o alias `s2.1-pro-free`, referência `ceaf7f569bef42c7bd322d88e3a356b7`, temperatura/top_p 0.85 e velocidade 1.0. A API aceitou as requisições; não forneceu uma atestação independente do backend que executou o modelo. A API tem normalização de texto ativa por padrão. Após ambiguidade de reconhecimento em duas unidades, somente as tomadas 03 e 08 foram regeneradas com `normalize:false`; o manifest registra a opção em cada faixa. Para gerar novamente, `scripts/generate_voice.py` usa `scripts/fish_audio_mcp.mjs` e lê configuração segura do ambiente Codex. Chaves e outros segredos não fazem parte do projeto nem deste pacote; não os grave em arquivos ou commits.

## Pesquisa e publicação

A proposta 221/2019 e a PEC 12/2026 foram verificadas separadamente como propostas e seus estados no corte. A versão visual não trata nenhum dos textos como lei em vigor. As regras atuais sobre repouso e doença são diferenciadas das questões que os textos das PECs não detalham. Veja `FACTS.md` e `LEGAL-VERIFICATION.md`.

A abertura usa ilustrações sintéticas rotuladas; existe uma composição alternativa de abertura documental licenciada em `compositions/alternatives/opening-documentary.html`, mas esta alternativa não foi exportada como um segundo vídeo. Antes de publicar, revise `TSE-IA-NOTE.md`, decisões eleitorais posteriores e as regras atuais do Instagram/Meta. Nenhuma publicação no Instagram foi feita.

Consulte `AUDIT-REPORT.md` para dados do MP4, verificações técnicas e limites declarados, incluindo a checagem automática de fala sem afirmar audição humana.
