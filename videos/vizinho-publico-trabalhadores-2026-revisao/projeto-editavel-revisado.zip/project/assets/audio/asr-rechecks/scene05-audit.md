# Cena 05 — revisão da ambiguidade

Take anterior preservado em `../originals-before-diction-fix/05-scene-v1.mp3`; novo take em `../scenes/05-scene.mp3`. Uma segunda transcrição Whisper medium q5_0, em português e sem prompt, reconhece a nova redação: “Na proposta apoiada por Lula, a jornada diminui com salário preservado, mas ainda depende do Senado. Na alternativa apoiada por Flávio, a remuneração acompanha as horas trabalhadas.” A saída small com DTW fornece os timestamps usados pelas legendas. A checagem é automática; não houve alegação de escuta humana.

`asr-dtw.json` conserva as cenas 1–4 do mapa vigente, substitui os segmentos/timestamps da cena 5 pelos novos e desloca as cenas seguintes em 2,012 segundos, com base nos inícios reais medidos em `voice-timing.json`.
