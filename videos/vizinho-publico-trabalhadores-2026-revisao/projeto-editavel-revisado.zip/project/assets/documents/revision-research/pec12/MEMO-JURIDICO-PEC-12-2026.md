# PEC 12/2026 — auditoria textual e situação legislativa

**Data de corte:** 11/10/2026. **Verificação:** consulta aos registros públicos do Senado, com snapshot do serviço de Dados Abertos marcado `11/10/2026 21:41`; os arquivos baixados foram preservados nesta pasta. Este memo descreve o texto apresentado, não substitui parecer jurídico.

## Fontes primárias e método

- Senado Federal, [página da PEC 12/2026, matéria 174362](https://www25.senado.leg.br/web/atividade/materias/-/materia/174362).
- Senado Federal, serviço Dados Abertos: [dados básicos](https://legis.senado.leg.br/dadosabertos/materia/174362), [documentos/textos da matéria](https://legis.senado.leg.br/dadosabertos/materia/textos/174362), [situação atual](https://legis.senado.leg.br/dadosabertos/materia/situacaoatual/174362) e [processo legislativo 9055580](https://legis.senado.leg.br/dadosabertos/processo/9055580).
- Texto original em PDF: [proposição PEC 12/2026](PEC-12-2026-proposicao-original.pdf); [avulso inicial integral](PEC-12-2026-avulso-inicial-integral.pdf). Extrações textuais estão ao lado. O endpoint inline informado no briefing serviu uma página de verificação HTML; não foi tratado como PDF nem contornado. O PDF primário foi obtido pelo endpoint público de documentos/Dados Abertos listado pelo Senado.

A ficha identifica Rogério Marinho como primeiro autor e Flávio Bolsonaro entre os signatários. A ementa propõe opção do empregado entre o regime comum da CLT e regime flexível baseado em horas trabalhadas.

## O que o texto diz expressamente

O art. 1º acrescentaria §§ 2º, 3º e 4º ao art. 7º da Constituição:

1. **Acordos e precedência individual (§ 2º):** compensação de horários e redução de jornada poderiam ocorrer por acordo individual, convenção coletiva ou “livre pactuação contratual direta” — inclusive por hora trabalhada. O dispositivo determina que o contrato individual prevaleça sobre instrumentos de negociação coletiva. O comando não é limitado textualmente ao trabalhador flexível: sua abrangência é uma questão de interpretação e potencial conflito constitucional, mas a prevalência está escrita de forma expressa.
2. **Pagamento e proporcionalidade (§ 3º):** se houver redução da jornada máxima indicada no inciso XIII, a hora não poderá ficar abaixo da proporção do salário mínimo nacional ou piso profissional, tomando como base aquela jornada máxima. A mesma proporcionalidade regeria o cálculo dos “demais direitos trabalhistas”, com menção expressa a férias, 13º, FGTS e “outros benefícios legais”, conforme a carga horária efetivamente trabalhada. Logo, a PEC não extingue expressamente férias, 13º ou FGTS; prevê cálculo proporcional, que pode resultar em valores menores quando se trabalha menos horas. O texto não detalha a fórmula de cada verba nem define o que conta como horas efetivamente trabalhadas.
3. **Horário flexível (§ 4º):** o contrato individual poderia prever jornada flexível, respeitado o limite semanal do inciso XIII e o § 3º. A regra não especifica distribuição diária, quantidade mínima de horas, aviso prévio para mudanças de escala ou cálculo de horas não realizadas por doença.
4. **Vigência (art. 2º):** 180 dias depois de eventual publicação da emenda. A proposta, portanto, não estava em vigor no corte.

## Direitos e pontos sem resposta expressa

- **Repouso semanal remunerado (RSR) e feriados:** a PEC não altera expressamente o inciso XV do art. 7º (repouso semanal remunerado, preferencialmente aos domingos), não menciona nominalmente RSR, domingos ou feriados e não diz que o direito deixa de existir. Também não contém cláusula geral dizendo que todos os direitos são preservados “sem alteração”. A regra ampla de proporcionalidade dos “outros benefícios legais” pode suscitar dúvida sobre o cálculo do RSR no regime por hora; o projeto não resolve essa interação. A Lei 605/1949, arts. 1º, 6º e 7º, prevê repouso semanal de 24 horas, disciplina faltas justificadas e remuneração do repouso inclusive para quem trabalha por hora. Assim, não é correto afirmar que a PEC automaticamente elimina folgas remuneradas; tampouco é correto prometer, apenas com base no texto, que o cálculo atual do RSR ficaria invariável em qualquer contrato flexível.
- **Atestados e doença:** o texto da PEC não menciona atestado, falta por doença, licença médica ou auxílio por incapacidade, nem os revoga expressamente. Na legislação atual, a Lei 605/1949, art. 6º, § 1º, “f”, trata doença devidamente comprovada como motivo justificado para ausência; a Lei 8.213/1991, art. 60, § 3º, atribui à empresa o pagamento do salário integral do empregado nos primeiros 15 dias consecutivos de afastamento por doença. A PEC não esclarece como aplicar o critério de horas efetivamente trabalhadas/proporcionalidade às horas não realizadas durante doença, sobretudo quando a escala for variável. A conclusão sobre valor devido e método de cálculo exigiria interpretação jurídica e eventual legislação/regulamentação; não há base no texto para dizer que o atestado “deixa de valer” ou que a proteção foi abolida.
- **Negociação coletiva:** a possibilidade de pactuação individual e a prevalência do contrato individual sobre negociação coletiva são alteração expressa, não hipótese. A consequência em contratos concretos, a compatibilidade com garantias constitucionais e o alcance do comando dependeriam de interpretação e controle legislativo/judicial.
- **Preservação:** os incisos constitucionais que estabelecem direitos — inclusive repouso semanal, férias, 13º e FGTS — não são substituídos ou apagados pelo texto proposto. Não há, porém, uma cláusula expressa de salvaguarda integral: o § 3º expressamente manda aplicar proporcionalidade no cálculo de direitos e benefícios. Falar em “direitos continuam previstos, com cálculo proporcional” é fiel ao texto para os direitos nomeados; falar em “todos os direitos permanecem exatamente iguais” não é.

## Status oficial no corte

O registro do Senado identifica PEC 12/2026 como **em tramitação**, encaminhada à CCJ, em situação **“Aguardando designação do relator”**. A página registra a última atualização legislativa geral em 31/08/2026; o JSON de processo acessado, embora com versão do serviço em 11/10/2026, também traz como atualização geral 31/08/2026 e não lista movimentos posteriores a 01/06/2026. Assim, a formulação prudente no vídeo é: “No registro oficial consultado para o corte, ainda aguardava designação de relator na CCJ; não estava em vigor.” A data de publicação do projeto no Senado é 28/05/2026. Não tratar ausência de novos eventos no registro consultado como prova independente de atos que não constem da base.

## Implicação editorial recomendada

Na parte de folgas, evitar “trabalhar menos dias não significa necessariamente receber pelos dias sem trabalho” sem qualificação, pois pode insinuar perda automática do RSR. Preferir: **“A PEC não especifica como seria calculado o repouso semanal remunerado no regime flexível. A Constituição e a lei atual reconhecem esse direito; o texto não diz que ele acaba, mas a regra de proporcionalidade deixa em aberto como o valor seria calculado.”** Para doença: dizer que proteções atuais seguem aplicáveis enquanto a PEC não vigora e que o projeto não define como calcular remuneração/benefícios em escala variável durante afastamento. Na comparação, descrever férias, 13º e FGTS como expressamente previstos com cálculo proporcional à carga horária, sem afirmar abolição nem preservação de montantes integrais.

## Arquivos preservados nesta pasta

- `PEC-12-2026-proposicao-original.pdf` e `.txt`: proposta original e texto extraído.
- `PEC-12-2026-avulso-inicial-integral.pdf` e `.txt`: avulso inicial integral.
- `registro-oficial-senado-materia-174362.xml`, `textos-oficiais-materia-174362.xml`, `situacao-oficial-materia-174362.xml`, `movimentacoes-oficiais-materia-174362.xml`, `processo-oficial-9055580.json`, `registro-oficial-senado-PEC-12-2026.html`: cópias dos registros oficiais consultados.

**Limite da pesquisa:** os textos da legislação vigente são citados por artigo e link oficial; o domínio Planalto não entregou os arquivos durante esta sessão. O texto da PEC e o status foram verificados diretamente nos documentos/serviços do Senado, sem depender da justificação dos autores como fonte de interpretação legal.
