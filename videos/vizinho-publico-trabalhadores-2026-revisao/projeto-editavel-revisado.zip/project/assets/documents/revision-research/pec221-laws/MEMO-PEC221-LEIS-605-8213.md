# Nota de verificação — PEC 221/2019 e legislação vigente

**Escopo e corte:** situação legislativa em 11/10/2026 e regras brasileiras sobre repouso semanal remunerado, ausência por doença comprovada e benefício por incapacidade. Esta nota separa direito vigente de proposta e não é parecer jurídico individual.

## Andamento da PEC 221/2019

A ficha oficial do Senado registra a matéria **“Em tramitação”**, último local no Plenário em 08/10/2026 e último estado em 09/10/2026: “Incluída em Ordem do Dia”. O histórico registra parecer favorável da CCJ e discussão em primeiro turno. Inclusão em pauta não equivale a aprovação em dois turnos, promulgação ou vigência; portanto, em 11/10/2026 a PEC ainda não alterava a Constituição. Fonte: [ficha oficial do Senado](https://www25.senado.leg.br/web/atividade/materias/-/materia/174386), captura HTML e extrato local nesta pasta.

A Câmara informou que aprovou a PEC em dois turnos em 27/05/2026 e enviou texto ao Senado (1º turno: 472 votos a 22; 2º turno: 461 a 19). É uma etapa concluída na Casa iniciadora, não a conclusão do processo constitucional. Fonte: Agência Câmara, “Plenário aprovou em dois turnos o fim da escala 6x1”, preservada em `assets/documents/research/camara-pec-221-2019-aprovacao.txt`; [ficha/captura institucional](https://www.camara.leg.br/propostas-legislativas/2233358). A PEC original de 2019 não deve ser confundida com o substitutivo aprovado na Câmara.

## Direito vigente: repouso semanal, faltas e doença

A Constituição Federal, art. 7º, XV, assegura repouso semanal remunerado, preferencialmente aos domingos. A Lei 605/1949, art. 6º, condiciona a remuneração do repouso à frequência semanal, ressalvadas faltas justificadas. Seu § 1º, alínea “f”, inclui expressamente “a doença do empregado, devidamente comprovada” entre os motivos justificados; o § 2º trata da comprovação por atestado médico. A lei, assim, já reconhece a doença comprovada para efeitos do repouso semanal remunerado. Isso não significa remuneração ilimitada por todo período de afastamento nem dispensa comprovação.

Fontes primárias arquivadas: texto original da Lei 605/1949 pela Câmara, nesta pasta (`lei605-art6-extract.txt`, além do HTML original); página da Câmara com histórico de alterações; ficha/publicação do Senado. O endereço consolidado do Planalto expirou durante esta coleta. O texto original foi cotejado com a página oficial de histórico; antes de citação literal final, conferir eventual atualização superveniente.

## Ausência por doença e benefício previdenciário

Para o segurado empregado, o art. 60, § 3º, da Lei 8.213/1991 atribui à empresa o salário integral nos primeiros 15 dias consecutivos de afastamento por doença. O benefício previdenciário por incapacidade temporária pode ser devido pelo INSS a partir do 16º dia (art. 60, caput), quando preenchidos os requisitos legais. O art. 59 exige incapacidade para o trabalho ou atividade habitual por mais de 15 dias consecutivos e carência quando aplicável. Atestado é prova médica; não concede automaticamente benefício previdenciário, cuja concessão depende dos requisitos e do procedimento de reconhecimento.

A Lei 8.213/1991 consolidada foi arquivada a partir da Câmara dos Deputados, com os arts. 59 e 60 transcritos em `lei8213-arts59-60-extract.txt`. As exceções de carência, acidentes, períodos longos e procedimentos de revisão não devem ser resumidos como uma regra única. CLT, art. 473, I, também prevê falta por doença devidamente comprovada, conforme os termos legais.

## Proposta e efeitos possíveis

A ementa oficial da PEC propõe reduzir a duração semanal máxima e prever dois dias de repouso semanal remunerado, sem redução salarial. No corte desta verificação, era proposta, não norma vigente. O texto da Câmara é substitutivo e contém transição e regras especiais; para detalhar essas regras deve-se usar a redação efetivamente aprovada e o texto que tramita no Senado.

Não há base para afirmar que a PEC tenha eliminado a justificativa médica prevista na Lei 605/1949, ou que mude automaticamente o direito a atestado ou à cobertura previdenciária. Mais dias de descanso poderiam afetar escalas e distribuição de folgas; esse possível efeito operacional não equivale a alteração automática do tratamento de ausências médicas. Consequências sobre controles, acordos, setores especiais ou benefícios dependem do texto final, regulamentação e interpretação administrativa/judicial.

## Formulação audiovisual segura

> “Hoje, a lei já reconhece doença comprovada como motivo de falta justificada para o repouso semanal. A PEC 221 propõe dois dias de descanso remunerado, mas em 11 de outubro ainda tramitava no Senado. A proposta não deve ser descrita como tendo eliminado o direito ao atestado ou ao benefício por incapacidade.”

Se houver menção ao INSS, esclarecer que o benefício depende de incapacidade, requisitos previdenciários e procedimento de reconhecimento; um atestado isolado não garante concessão.

## Referências primárias

- Senado Federal, ficha PEC 221/2019: https://www25.senado.leg.br/web/atividade/materias/-/materia/174386.
- Câmara dos Deputados, ficha PEC 221/2019: https://www.camara.leg.br/propostas-legislativas/2233358.
- Lei 605/1949, Câmara, texto original: https://www2.camara.leg.br/legin/fed/lei/1940-1949/lei-605-5-janeiro-1949-367115-publicacaooriginal-1-pl.html; página de alterações: https://www2.camara.leg.br/legin/fed/lei/1940-1949/lei-605-5-janeiro-1949-367115-norma-pl.html.
- Lei 8.213/1991, texto consolidado da Câmara: https://www2.camara.leg.br/legin/fed/lei/1991/lei-8213-24-julho-1991-363650-normaatualizada-pl.html; Planalto: https://www.planalto.gov.br/ccivil_03/leis/l8213cons.htm.
- Constituição Federal, art. 7º, XV: https://www.planalto.gov.br/ccivil_03/constituicao/constituicao.htm.
- CLT, art. 473, I: https://www.planalto.gov.br/ccivil_03/decreto-lei/del5452.htm.
