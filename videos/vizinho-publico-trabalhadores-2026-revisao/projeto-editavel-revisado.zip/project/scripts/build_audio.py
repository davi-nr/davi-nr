#!/usr/bin/env python3
"""Validate and assemble the individual Fish takes into delivery tracks/timing."""
from __future__ import annotations

import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[1]
SCENES = ROOT / "assets/audio/scenes"
AUDIO = ROOT / "assets/audio"
GAP = 0.4
TAIL = 3.0
SAMPLE_RATE = 48_000


def run(args: list[str]) -> str:
    return subprocess.check_output(args, text=True).strip()


def duration(path: pathlib.Path) -> float:
    return float(run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)]))


def main() -> None:
    manifest = json.loads((AUDIO / "voice-manifest.json").read_text(encoding="utf-8"))
    if [x["scene"] for x in manifest] != list(range(1, 12)):
        raise SystemExit("Expected a complete ordered manifest for all 11 scenes")

    timings = []
    cursor = 0.0
    durations = []
    for item in manifest:
        path = ROOT / item["path"]
        if not path.is_file() or path.stat().st_size == 0:
            raise SystemExit(f"Missing or empty Fish take: {item['path']}")
        subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-f", "null", "-"], check=True)
        d = duration(path)
        durations.append(d)
        timings.append({
            "scene": item["scene"],
            "voice_start_s": round(cursor, 3),
            "voice_end_s": round(cursor + d, 3),
            "voice_duration_s": round(d, 3),
        })
        cursor += d + (GAP if item["scene"] < 11 else 0)
    total_voice = sum(durations)
    total_duration = total_voice + GAP * 10 + TAIL

    gap_path = AUDIO / "_gap-400ms.wav"
    tail_path = AUDIO / "_tail-3s.wav"
    subprocess.run([
        "ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i",
        f"anullsrc=r={SAMPLE_RATE}:cl=stereo:d={GAP}", "-c:a", "pcm_s24le", str(gap_path)
    ], check=True)
    subprocess.run([
        "ffmpeg", "-y", "-v", "error", "-f", "lavfi", "-i",
        f"anullsrc=r={SAMPLE_RATE}:cl=stereo:d={TAIL}", "-c:a", "pcm_s24le", str(tail_path)
    ], check=True)

    sequence: list[pathlib.Path] = []
    for i, item in enumerate(manifest):
        sequence.append(ROOT / item["path"])
        if i < len(manifest) - 1:
            sequence.append(gap_path)
    sequence.append(tail_path)
    narration = AUDIO / "narration-consolidated.wav"
    inputs = [arg for path in sequence for arg in ("-i", str(path))]
    filters = []
    labels = []
    for i in range(len(sequence)):
        filters.append(f"[{i}:a]aresample={SAMPLE_RATE},aformat=sample_fmts=fltp:channel_layouts=stereo[a{i}]")
        labels.append(f"[a{i}]")
    filters.append(f"{''.join(labels)}concat=n={len(sequence)}:v=0:a=1[out]")
    subprocess.run([
        "ffmpeg", "-y", "-v", "error", *inputs, "-filter_complex", ";".join(filters),
        "-map", "[out]", "-c:a", "pcm_s24le", str(narration)
    ], check=True)
    narration_duration = duration(narration)
    if abs(narration_duration - total_duration) > 0.08:
        raise SystemExit(f"Unexpected assembled voice duration: {narration_duration:.3f} s")

    (AUDIO / "voice-timing.json").write_text(json.dumps({
        "sample_rate_hz": SAMPLE_RATE,
        "inter_scene_silence_s": GAP,
        "ending_hold_s": TAIL,
        "scene_count": len(manifest),
        "spoken_duration_s": round(total_voice, 3),
        "program_duration_s": round(total_duration, 3),
        "scenes": timings,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    (ROOT / "NARRATION-TIMING.md").write_text(
        "# Narração e temporização\n\n"
        f"- Cenas narradas: {len(manifest)}.\n- Duração de fala somada: {total_voice:.3f} s.\n"
        f"- Respiro entre cenas: {GAP:.1f} s.\n- Sustentação final sem fala: {TAIL:.1f} s.\n"
        f"- Duração total prevista: {narration_duration:.3f} s ({narration_duration/60:.2f} min).\n"
        "- Todas as durações foram lidas com ffprobe; o MP3 de cada cena foi decodificado com ffmpeg.\n",
        encoding="utf-8"
    )
    gap_path.unlink(missing_ok=True)
    tail_path.unlink(missing_ok=True)
    print(f"OK scenes=11 speech={total_voice:.3f}s total={narration_duration:.3f}s")


if __name__ == "__main__":
    main()
