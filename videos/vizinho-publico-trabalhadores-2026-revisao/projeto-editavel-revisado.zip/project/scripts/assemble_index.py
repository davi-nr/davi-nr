#!/usr/bin/env python3
"""Assemble HyperFrames root composition from measured voice timing + captions."""
from __future__ import annotations
import html, json, pathlib, re

ROOT = pathlib.Path(__file__).resolve().parents[1]
AUDIO = ROOT / "assets/audio"

def srt_seconds(value: str) -> float:
    h, m, rem = value.split(":")
    sec, millis = rem.split(",")
    return int(h) * 3600 + int(m) * 60 + int(sec) + int(millis) / 1000

def srt_cues(path: pathlib.Path) -> list[dict]:
    cues=[]
    for block in path.read_text(encoding="utf-8").strip().split("\n\n"):
        lines=block.splitlines()
        if len(lines) < 3: continue
        start,end=lines[1].split(" --> ")
        cues.append({"start":srt_seconds(start),"end":srt_seconds(end),"text":"\n".join(lines[2:])})
    return cues

def main() -> None:
    timing=json.loads((AUDIO/"voice-timing.json").read_text(encoding="utf-8"))
    duration=timing["program_duration_s"]
    story=(ROOT/"STORYBOARD.md").read_text(encoding="utf-8")
    blocks=re.findall(r"(?ms)^## Frame (\d+) — (.+?)\n(.*?)(?=^## Frame |\Z)",story)
    if len(blocks)!=11: raise SystemExit(f"Expected 11 storyboard frames, found {len(blocks)}")
    scenes=[]
    for ordinal,(n,title,body) in enumerate(blocks):
        src=re.search(r"(?m)^- src: (.+)$",body).group(1).strip()
        index=int(n)-1
        t=timing["scenes"][index]
        start=t["voice_start_s"]
        end=(timing["scenes"][index+1]["voice_start_s"] if index+1<len(timing["scenes"]) else duration)
        scenes.append((ordinal+1,title.strip(),src,start,end-start))
    cue_markup=[]
    for i,cue in enumerate(srt_cues(AUDIO/"captions.srt"),1):
        start,end,text=cue["start"],cue["end"],html.escape(cue["text"]).replace("\n","<br />")
        cue_markup.append(
            f'<div class="caption clip" id="caption-{i}" data-start="{start:.3f}" '
            f'data-duration="{end-start:.3f}" data-track-index="20">{text}</div>'
        )
    scene_markup=[]; caption_tweens=[]
    for i,title,src,start,span in scenes:
        sid=pathlib.Path(src).stem
        scene_markup.append(
            f'<div id="el-{sid}" class="scene-slot" data-composition-id="{sid}" '
            f'data-composition-src="{html.escape(src)}" data-start="{start:.3f}" '
            f'data-duration="{span:.3f}" data-track-index="1" data-width="1080" data-height="1920"></div>'
        )
    for i,cue in enumerate(srt_cues(AUDIO/"captions.srt"),1):
        st,en=cue["start"],cue["end"]
    markup=f'''<!doctype html>
<html lang="pt-BR" data-resolution="portrait">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=1080,height=1920" />
  <title>Vizinho Público — Trabalhadores 2026</title>
  <script src="assets/vendor/gsap.min.js"></script>
  <style>
    @font-face{{font-family:VPEB;src:url('assets/fonts/EBGaramond-700.woff2') format('woff2');font-weight:700;font-display:block}}
    *{{box-sizing:border-box}} html,body{{margin:0;width:1080px;height:1920px;overflow:hidden;background:#263438}}
    #root{{position:relative;width:1080px;height:1920px;overflow:hidden;background:#F4F1DE;color:#263438}}
    .scene-slot{{position:absolute;inset:0;width:1080px;height:1920px}}
    .caption{{position:absolute;left:92px;right:92px;top:1434px;min-height:78px;padding:12px 22px 14px;border-left:5px solid #D9A441;background:rgba(38,52,56,.94);color:#F4F1DE;font:700 39px/1.04 VPEB,Georgia,serif;letter-spacing:.005em;text-align:center;text-shadow:0 1px 1px rgba(0,0,0,.25);z-index:40;display:flex;justify-content:center;align-items:center;flex-direction:column;white-space:normal;overflow:hidden}}
  </style>
</head>
<body>
  <div id="root" data-composition-id="root" data-width="1080" data-height="1920" data-duration="{duration:.3f}" data-fps="30">
    {''.join(scene_markup)}
    <audio id="el-final-mix" class="clip" src="assets/audio/final-mix-normalized.wav" data-start="0" data-duration="{duration:.3f}" data-track-index="10" data-volume="1"></audio>
    {''.join(cue_markup)}
  </div>
  <script>
    window.__timelines = window.__timelines || {{}};
    const tl=gsap.timeline({{paused:true}});
    {''.join(caption_tweens)}
    window.__timelines["root"]=tl; tl.seek(0);
  </script>
</body>
</html>'''
    (ROOT/"index.html").write_text(markup,encoding="utf-8")
    print(f"root assembled: scenes={len(scenes)} captions={len(cue_markup)} duration={duration:.3f}s")

if __name__ == "__main__": main()
