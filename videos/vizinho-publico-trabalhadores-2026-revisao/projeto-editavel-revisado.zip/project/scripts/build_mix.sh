#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
duration="$(python3 -c 'import json;print(json.load(open("assets/audio/voice-timing.json"))["program_duration_s"])')"
python3 scripts/extend_music.py
ffmpeg -y -hide_banner -loglevel error \
  -i assets/audio/music-extended.wav \
  -i assets/audio/narration-consolidated.wav \
  -filter_complex "[0:a]atrim=0:${duration},asetpts=PTS-STARTPTS,volume=2.0[m];[1:a]atrim=0:${duration},asetpts=PTS-STARTPTS,asplit=2[voice][sc];[m][sc]sidechaincompress=threshold=0.01:ratio=4:attack=100:release=700:makeup=1[duck];[duck][voice]amix=inputs=2:duration=longest:normalize=0,alimiter=limit=0.89:attack=5:release=50[out]" \
  -map '[out]' -t "$duration" -ar 48000 -ac 2 -c:a pcm_s16le assets/audio/final-mix.wav
ffprobe -v error -show_entries format=duration -of json assets/audio/final-mix.wav
python3 scripts/normalize_master.py assets/audio/final-mix.wav assets/audio/final-mix-normalized.wav
