#!/usr/bin/env python3
"""Align approved script captions to Whisper.cpp token timestamps by scene."""
from __future__ import annotations

import difflib
import json
import pathlib
import re
import unicodedata
import textwrap

ROOT = pathlib.Path(__file__).resolve().parents[1]
AUDIO = ROOT / "assets/audio"
TOKEN_RE = re.compile(r"@?[\wÀ-ÿ]+(?:['’][\wÀ-ÿ]+)*(?:[.,!?;:]*)", re.UNICODE)


def fold(s: str) -> str:
    s = unicodedata.normalize("NFKD", s.lower())
    return "".join(ch for ch in s if not unicodedata.combining(ch)).strip(".,!?;:()[]{}\"'“”")


def timestamp(s: str) -> float:
    h, m, rest = s.split(":")
    sec, milli = rest.split(",")
    return int(h) * 3600 + int(m) * 60 + int(sec) + int(milli) / 1000


def parse_asr_words(document: dict) -> list[dict]:
    result = []
    for segment in document["transcription"]:
        current = None
        for token in segment.get("tokens", []):
            raw = token.get("text", "")
            if raw.startswith("[_"):
                continue
            t0 = timestamp(token["timestamps"]["from"])
            t1 = timestamp(token["timestamps"]["to"])
            leading_space = bool(raw[:1].isspace())
            fragment = raw.strip()
            if not fragment:
                continue
            parts = fragment.split()
            if leading_space:
                if current:
                    result.append(current)
                    current = None
            elif current is None:
                pass
            if len(parts) == 1:
                if current is None:
                    current = {"text": parts[0], "start": t0, "end": t1}
                else:
                    current["text"] += parts[0]
                    current["end"] = max(current["end"], t1)
            else:
                if current:
                    result.append(current)
                    current = None
                for part in parts[:-1]:
                    result.append({"text": part, "start": t0, "end": t1})
                current = {"text": parts[-1], "start": t0, "end": t1}
        if current:
            result.append(current)
    return result


def phrase_collapse(words: list[str]) -> list[tuple[str, int, int]]:
    rules = [
        ("sete mil trezentos e cinquenta".split(), "7350"),
        ("duzentos e vinte e um".split(), "221"),
        ("dois mil e vinte e seis".split(), "2026"),
        ("vinte e quatro".split(), "24"),
        ("seis por um".split(), "6x1"),
        ("cinco mil".split(), "5000"),
        ("décimo terceiro".split(), "13"),
    ]
    out: list[tuple[str, int, int]] = []
    i = 0
    while i < len(words):
        match = next(((phrase, replacement) for phrase, replacement in rules if words[i:i + len(phrase)] == phrase), None)
        if match:
            phrase, replacement = match
            out.append((replacement, i, i + len(phrase) - 1))
            i += len(phrase)
            continue
        value = words[i]
        single_numbers = {"quarenta": "40", "cinco": "5", "dois": "2", "três": "3", "tres": "3", "dezoito": "18", "cinquenta": "50", "doze": "12", "onze": "11", "sete": "7", "janeiro": "janeiro"}
        out.append((single_numbers.get(value, value), i, i))
        i += 1
    return out


def normalize_source(word: str, scene: int) -> str:
    value = fold(word)
    if value == "gajos":
        value = "horas"
    if scene == 3 and value == "2022":
        value = "221"
    if scene == 10 and value == "2021":
        value = "221"
    if value in {"visinsum", "visinsum"}:
        value = "221"
    if value == "13a":
        value = "13"
    return value


def align_scene(target_raw: list[str], source_words: list[dict], scene: int) -> list[dict]:
    target_fold = [fold(x) for x in target_raw]
    target_groups = phrase_collapse(target_fold)
    source_groups = [(normalize_source(x["text"], scene), i, i) for i, x in enumerate(source_words)]
    tgt = [x[0] for x in target_groups]
    src = [x[0] for x in source_groups]
    # SequenceMatcher preserves monotonic matching around isolated ASR substitutions.
    matcher = difflib.SequenceMatcher(None, tgt, src, autojunk=False)
    anchors: dict[int, tuple[float, float]] = {}
    for a, b, size in matcher.get_matching_blocks():
        for k in range(size):
            tg = target_groups[a + k]
            sg = source_groups[b + k]
            anchors[tg[1]] = (source_words[sg[1]]["start"], source_words[sg[1]]["end"])
            anchors[tg[2]] = (source_words[sg[1]]["start"], source_words[sg[1]]["end"])
    # Number phrases and a small list of known ASR substitutions are anchored by their nearest words.
    for ti, (norm, first, last) in enumerate(target_groups):
        if first in anchors or last in anchors:
            if first not in anchors and last in anchors:
                anchors[first] = anchors[last]
            if last not in anchors and first in anchors:
                anchors[last] = anchors[first]
    mapped = []
    target_positions = []
    for first, last in ((i, i) for i in range(len(target_raw))):
        if first in anchors:
            mapped.append(anchors[first]); target_positions.append(first)
    if not mapped and source_words:
        mapped = [(source_words[0]["start"], source_words[-1]["end"])]; target_positions = [0]
    for i in range(len(target_raw)):
        if i in anchors:
            continue
        left = max((p for p in target_positions if p < i), default=None)
        right = min((p for p in target_positions if p > i), default=None)
        if left is None and right is None:
            anchors[i] = (source_words[0]["start"], source_words[-1]["end"])
        elif left is None:
            anchors[i] = anchors[right]
        elif right is None:
            anchors[i] = anchors[left]
        else:
            lo, hi = anchors[left], anchors[right]
            ratio = (i - left) / (right - left)
            point = lo[1] + (hi[0] - lo[1]) * ratio
            anchors[i] = (point, max(point + 0.08, point))
    return [{"text": raw, "start": anchors[i][0], "end": anchors[i][1]} for i, raw in enumerate(target_raw)]


def wrap_caption(text: str) -> str:
    lines = textwrap.wrap(text, width=34, break_long_words=False, break_on_hyphens=False)
    return "\n".join(lines[:2])


def srt_time(value: float) -> str:
    ms = max(0, round(value * 1000))
    h, rem = divmod(ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, rem = divmod(rem, 1000)
    return f"{h:02}:{m:02}:{s:02},{rem:03}"


def main() -> None:
    scene_data = json.loads((ROOT / "scene-text.json").read_text(encoding="utf-8"))
    if [item.get("scene") for item in scene_data] != list(range(1, 12)):
        raise SystemExit("scene-text.json must contain scenes 1 through 11 in order")
    scene_texts = [item["narration_text"] for item in scene_data]
    timing = json.loads((AUDIO / "voice-timing.json").read_text(encoding="utf-8"))
    asr = json.loads((AUDIO / "asr-dtw.json").read_text(encoding="utf-8"))
    words = parse_asr_words(asr)
    all_cues = []
    aligned_words = []
    for scene, text in enumerate(scene_texts, 1):
        span = timing["scenes"][scene - 1]
        start, end = span["voice_start_s"], span["voice_end_s"]
        scene_cues = []
        source = [x for x in words if x["start"] >= start - 0.08 and x["end"] <= end + 0.12]
        raw = TOKEN_RE.findall(text)
        aligned = align_scene(raw, source, scene)
        aligned_words += [{**word, "scene": scene, "method": "small-whisper-token-timestamp-sequence-alignment"} for word in aligned]
        # Group up to six words and ~52 characters; respect sentence boundaries.
        groups = []
        current = []
        for word in aligned:
            if current and (len(current) >= 6 or len(" ".join(x["text"] for x in current + [word])) > 52):
                groups.append(current); current = []
            current.append(word)
            if re.search(r"[.!?;:]$", word["text"]):
                groups.append(current); current = []
        if current: groups.append(current)
        for group in groups:
            raw_text = " ".join(x["text"] for x in group)
            cap = wrap_caption(raw_text)
            # Keep the actual captions inside the spoken line's measured interval.
            cue_start = max(start, min(x["start"] for x in group) - 0.03)
            cue_end = min(end, max(x["end"] for x in group) + 0.12)
            if cue_end - cue_start < 0.65:
                cue_end = min(end, cue_start + 0.85)
            scene_cues.append({"start": cue_start, "end": cue_end, "text": cap, "scene": scene})

        all_cues.extend(scene_cues)
    # Add modest gaps between captions without letting them overlap.
    for i, cue in enumerate(all_cues[:-1]):
        nxt = all_cues[i + 1]
        if cue["end"] > nxt["start"]:
            cue["end"] = nxt["start"] - 0.025
        if cue["end"] - cue["start"] < 0.35:
            raise SystemExit(
                f"Caption {i + 1} is too short after overlap correction; fix its alignment instead of overlapping it."
            )
    if all_cues and all_cues[-1]["end"] - all_cues[-1]["start"] < 0.35:
        raise SystemExit("Final caption is too short; fix its alignment.")
    lines = []
    for i, cue in enumerate(all_cues, 1):
        lines += [str(i), f"{srt_time(cue['start'])} --> {srt_time(cue['end'])}", cue["text"], ""]
    (AUDIO / "captions.srt").write_text("\n".join(lines), encoding="utf-8")
    (AUDIO / "transcript.json").write_text(json.dumps(aligned_words, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (ROOT / "CAPTION-ALIGNMENT.md").write_text(
        "# Legendas e alinhamento\n\n"
        f"As legendas reproduzem o texto aprovado em `scene-text.json` e usam {len(asr['transcription'])} segmentos e timestamps de tokens do Whisper.cpp small, em português, sobre a narração consolidada. A saída automática foi comparada ao roteiro; erros lexicais prováveis do ASR (por exemplo, números, siglas e nomes) foram corrigidos no texto exibido, mantendo os timestamps de fala. A sincronização é automática com sequência textual por cena, não uma validação auditiva humana.\n",
        encoding="utf-8"
    )
    print(f"captions={len(all_cues)} words={len(aligned_words)}")


if __name__ == "__main__":
    main()
