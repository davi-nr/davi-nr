#!/usr/bin/env python3
"""Extend the retained original bed with one gently crossfaded interior passage."""
from __future__ import annotations
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[1]
source = ROOT / "assets/audio/music-original.wav"
target = ROOT / "assets/audio/voice-timing.json"
out = ROOT / "assets/audio/music-extended.wav"
duration = float(json.loads(target.read_text())["program_duration_s"])
probe = subprocess.run(
    ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(source)],
    check=True, capture_output=True, text=True,
)
source_duration = float(probe.stdout.strip())
# The supplied track's final seconds already contain its own ending fade. Reuse
# the clean interior 120–162 s passage and blend it into the bed before that fade.
head_end = min(source_duration - 6.6, 170.45)
loop_start, loop_end, crossfade = 120.0, 162.0, 2.5
if head_end <= loop_start or source_duration < loop_end:
    raise SystemExit("Original bed is shorter than the documented interior passage.")
fade_duration = 2.767
fade_start = duration - fade_duration
tail_at = head_end - crossfade
filtergraph = (
    f"[0:a]atrim=start=0:end={head_end:.3f},"
    f"afade=t=out:st={tail_at:.3f}:d={crossfade:.3f}:curve=tri,"
    f"asetpts=PTS-STARTPTS[head];"
    f"[0:a]atrim=start={loop_start:.3f}:end={loop_end:.3f},"
    f"afade=t=in:st=0:d={crossfade:.3f}:curve=tri,"
    f"asetpts=PTS-STARTPTS,adelay={tail_at * 1000:.0f}|{tail_at * 1000:.0f}[tail];"
    f"[head][tail]amix=inputs=2:duration=longest:normalize=0,"
    f"atrim=start=0:end={duration:.3f},"
    f"afade=t=out:st={fade_start:.3f}:d={fade_duration:.3f}:curve=tri[bed]"
)
subprocess.run([
    "ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(source),
    "-filter_complex", filtergraph, "-map", "[bed]", "-ar", "48000", "-ac", "2",
    "-c:a", "pcm_s16le", str(out),
], check=True)
print(f"Wrote {out.relative_to(ROOT)} for {duration:.3f} s (source preserved at {source_duration:.3f} s)")
