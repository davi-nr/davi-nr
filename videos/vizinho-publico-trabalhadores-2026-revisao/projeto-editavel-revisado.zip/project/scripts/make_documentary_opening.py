#!/usr/bin/env python3
"""Create a separate render entry using licensed documentary opening photos."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "index.html").read_text(encoding="utf-8")
old = 'data-composition-id="01-hook" data-composition-src="compositions/frames/01-hook.html"'
new = 'data-composition-id="opening-documentary" data-composition-src="compositions/alternatives/opening-documentary.html"'
if source.count(old) != 1:
    raise SystemExit("Expected exactly one synthetic opening scene in index.html")
(ROOT / "index-documentary.html").write_text(source.replace(old, new), encoding="utf-8")
print("Wrote index-documentary.html; the main index.html and final MP4 were not changed.")
