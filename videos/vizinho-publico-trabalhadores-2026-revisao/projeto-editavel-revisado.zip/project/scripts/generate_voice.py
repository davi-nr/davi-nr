#!/usr/bin/env python3
"""Generate scene narration via the existing configured Fish Audio MCP adapter."""
from __future__ import annotations

import json
import os
import pathlib
import re
import subprocess
import sys
import tomllib

PROJECT = pathlib.Path(__file__).resolve().parents[1]
SCENE_TEXT = PROJECT / "scene-text.json"
OUTPUT = PROJECT / "assets/audio/scenes"
HELPER = PROJECT / "scripts/fish_audio_mcp.mjs"


def lines_from_scene_text() -> list[str]:
    data = json.loads(SCENE_TEXT.read_text(encoding="utf-8"))
    if [item.get("scene") for item in data] != list(range(1, 12)):
        raise RuntimeError("scene-text.json must contain scenes 1 through 11 in order")
    lines = [" ".join(item["narration_text"].split()) for item in data]
    if any(re.search(r"\d|\b(?:PEC|CLT|FGTS|IR|DSR)\b", line) for line in lines):
        raise RuntimeError("Synthesis text must spell out numbers and acronyms; layout text is never sent to Fish")
    return lines


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    lines = lines_from_scene_text()
    if len(lines) != 11:
        raise RuntimeError(f"Expected 11 scene paragraphs; found {len(lines)}")
    cfg_path = pathlib.Path(os.environ["CODEX_HOME"]) / "config.toml"
    cfg = tomllib.loads(cfg_path.read_text(encoding="utf-8"))
    fish = cfg["mcp_servers"]["fish-audio"]["env"]
    manifest_path = PROJECT / "assets/audio/voice-manifest.json"
    existing = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else []
    manifest = {item["scene"]: item for item in existing}
    selected = {int(value) for value in sys.argv[1:]} if len(sys.argv) > 1 else set(range(1, 12))
    if not selected.issubset(set(range(1, 12))):
        raise RuntimeError("Scene selection must be between 1 and 11")
    for index, text in enumerate(lines, 1):
        if index not in selected:
            continue
        target = OUTPUT / f"{index:02d}-scene.mp3"
        args = {
            "text": text,
            "output_path": str(target),
            "format": "mp3",
            "temperature": 0.85,
            "top_p": 0.85,
            "speed": 1.0,
            # This Portuguese project spells out narration numerals; avoid the API's
            # English/Chinese text-normalization default for any regenerated take.
            "normalize": False,
        }
        request = {
            "jsonrpc": "2.0",
            "id": index,
            "method": "tools/call",
            "params": {"name": "fish_audio_tts", "arguments": args},
        }
        env = os.environ.copy()
        env.update(fish)
        env.update({"AUDIO_OUTPUT_DIR": str(OUTPUT), "NODE_USE_ENV_PROXY": "1"})
        result = subprocess.run(
            ["node", str(HELPER)],
            input=json.dumps(request, ensure_ascii=False) + "\n",
            capture_output=True,
            text=True,
            env=env,
            timeout=180,
            check=True,
        )
        response = json.loads(result.stdout.splitlines()[-1])
        body = response.get("result", {})
        if body.get("isError"):
            raise RuntimeError(f"Fish Audio rejected scene {index}")
        detail = json.loads(body["content"][0]["text"])
        if not detail.get("success") or not target.exists() or target.stat().st_size == 0:
            raise RuntimeError(f"Fish Audio returned no usable audio for scene {index}")
        record = {
            "scene": index,
            "path": target.relative_to(PROJECT).as_posix(),
            "bytes": target.stat().st_size,
            "model_header": detail.get("model"),
            "reference_id": detail.get("reference_id"),
            "temperature": detail.get("temperature"),
            "top_p": detail.get("top_p"),
            "speed": detail.get("speed"),
            "normalize": detail.get("normalize"),
        }
        manifest[index] = record
        print(json.dumps(record, ensure_ascii=False), flush=True)
    (PROJECT / "assets/audio/voice-manifest.json").write_text(
        json.dumps([manifest[index] for index in sorted(manifest)], ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    main()
