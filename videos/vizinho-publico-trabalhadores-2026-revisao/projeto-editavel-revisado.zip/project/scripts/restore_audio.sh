#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v ffmpeg >/dev/null
command -v ffprobe >/dev/null
while IFS= read -r -d '' flac_file; do
  wav_file="${flac_file%.flac}"
  raw_bits="$(ffprobe -v error -select_streams a:0 -show_entries stream=bits_per_raw_sample -of default=nw=1:nk=1 "$flac_file")"
  case "$raw_bits" in
    16) pcm_codec=pcm_s16le ;;
    24) pcm_codec=pcm_s24le ;;
    32) pcm_codec=pcm_s32le ;;
    *) echo "Unsupported source bit depth: $raw_bits" >&2; exit 1 ;;
  esac
  ffmpeg -hide_banner -loglevel error -y -i "$flac_file" -c:a "$pcm_codec" "$wav_file"
  echo "Restored without reducing sample depth: $wav_file"
done < <(find assets/audio -type f -name '*.wav.flac' -print0)
