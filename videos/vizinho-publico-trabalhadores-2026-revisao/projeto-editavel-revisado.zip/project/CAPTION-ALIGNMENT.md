# Legendas e alinhamento

As legendas reproduzem o texto aprovado em `scene-text.json` e usam 42 segmentos e timestamps de tokens do Whisper.cpp small, em português, sobre a narração consolidada. A saída automática foi comparada ao roteiro; erros lexicais prováveis do ASR (por exemplo, números, siglas e nomes) foram corrigidos no texto exibido, mantendo os timestamps de fala. A sincronização é automática com sequência textual por cena, não uma validação auditiva humana.
