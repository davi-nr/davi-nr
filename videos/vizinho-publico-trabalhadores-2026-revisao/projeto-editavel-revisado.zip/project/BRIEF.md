---
workflow: general-video
flow: automation
storyboard: no
message: "Compare propostas para a vida de quem trabalha e separe o que está em vigor, em tramitação e ainda depende de decisão."
destination: instagram-reels
aspect: 1080x1920
language: pt-BR
audience: público geral que acompanha o debate sobre trabalho e eleições
length: 2:45–3:15
angle: comparação documental equilibrada
---

## Intent

Documentário editorial animado para o Vizinho Público sobre o que muda para trabalhadores nas propostas associadas a Lula e Flávio Bolsonaro. A narração abre imediatamente com “Lula e Flávio Bolsonaro têm propostas diferentes para quem trabalha.” Compara jornada, salário, direitos, emprego e renda com documentos verificáveis, distinguindo leis vigentes, proposições em tramitação e promessas. Data de corte: 11 de outubro de 2026. A duração pode variar dentro da faixa indicada para preservar a fluidez.

## Assets

- `assets/illustrations/lula-editorial-2d.png` — caricatura editorial 2D reutilizada do episódio anterior; entrada simétrica na abertura, identificada na tela como ilustração gerada por IA.
- `assets/illustrations/flavio-editorial-2d.png` — caricatura editorial 2D reutilizada do episódio anterior; entrada simétrica na abertura, identificada na tela como ilustração gerada por IA.
- `assets/reference/opening_lula.jpg` e `assets/reference/opening_flavio.jpg` — fotografias licenciadas usadas como referência de origem das ilustrações; créditos e links registrados em `ASSET-ATTRIBUTIONS.md`.
- `assets/fonts/` — EB Garamond, Teko e JetBrains Mono, copiadas do projeto Vizinho Público anterior.
- `assets/audio/music-original.wav` — trilha instrumental original procedural, reutilizada do episódio anterior para preservar a identidade sonora.

## Customizations

- Identidade Vizinho Público baseada no `frame.md` do episódio anterior: marfim, grafite esverdeado, terracota, verde e dourado; Teko, EB Garamond e JetBrains Mono.
- Caricaturas 2D com movimento muito sutil, sem sincronia labial, gestos ou falas atribuídas. O aviso visível “ILUSTRAÇÃO GERADA POR IA” acompanha cada arte na abertura.
- Composição de motion design editorial 2D: tipografia cinética, semana/calendário, documentos, barras e diagramas conceituais; sem layout de apresentação.
- Eleven compositions principais, legendas sincronizadas, trilha em ducking e arquivos de narração individuais e consolidados.

## Notes

- Usar o documento integral de entrada em `../USER-BRIEF.md` como contrato editorial. Não alterar o conteúdo factual sem verificação documentada.
- Manter tratamento visual equivalente para os dois candidatos e não indicar recomendação de voto.
- Fonte factual prioritária: texto e andamento da PEC 221/2019, PEC 12/2026 e planos de governo registrados no TSE; a data de corte é 11/10/2026.
- Não representar como lei vigente uma proposta ainda em tramitação. O estado do Senado deve refletir o registro oficial na data de corte.
- Não afirmar que algum direito trabalhista será abolido sem base no texto primário. Distinguir o texto da PEC 12/2026 de declarações de seu primeiro signatário.
- A arte sintética é identificada visivelmente e por texto alternativo. Nenhuma fala, ação ou fato fictício é atribuído a candidatos.
- Preservar integralmente o projeto anterior; esta pasta é uma produção independente.
