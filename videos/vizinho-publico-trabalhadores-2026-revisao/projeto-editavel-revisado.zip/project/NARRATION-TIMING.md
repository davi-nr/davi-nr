# Narração e temporização

- Cenas narradas: 11.
- Duração de fala somada: 202.735 s.
- Respiro entre cenas: 0.4 s.
- Sustentação final sem fala: 3.0 s.
- Duração total prevista: 209.736 s (3.50 min).
- Todas as durações foram lidas com ffprobe; o MP3 de cada cena foi decodificado com ffmpeg.
