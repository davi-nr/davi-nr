# Vizinho Público — sistema visual deste episódio

## Conceito

Dois caminhos documentais entram na mesma semana de trabalho. Calendários, textos legislativos, contracheques esquemáticos e cartões de situação mostram quais mudanças estão propostas, quais já valem e quais ainda dependem de decisão. O vídeo compara documentos, não candidatos como atores; o movimento editorial conecta as páginas sem transformar diferenças em torcida.

## Paleta

- Papel: `#F4F1DE` (marfim quente)
- Tinta: `#263438` (grafite esverdeado)
- Vermelho de ênfase: `#B9483D` (terracota)
- Verde: `#347A70`
- Dourado de marcação: `#D9A441`
- Fundo de documento: `#E8E2D1`

Preserve o fundo em papel e a combinação de tinta, acentos e texturas do episódio anterior. Para comparações, dar o mesmo peso e saturação às duas colunas; cor nunca deve sugerir apoio ou reprovação. Usar os acentos como código de organização, acompanhados por títulos e etiquetas explícitos.

## Tipografia

- Títulos e algarismos: Teko, peso 700, caixa alta e tracking moderado.
- Texto editorial: EB Garamond, pesos 400 e 700, corpo grande e boa entrelinha.
- Datas e códigos de documento: JetBrains Mono, pesos 400 e 700.
- Fontes locais em `assets/fonts/`; não depender de fontes remotas.

## Composição e movimento

Motion design editorial 2D, com márgenes seguros amplas. Usar semana/calendário como eixo visual persistente, avançando para documentos legislativos e comparações paralelas. Uma coluna ou unidade dominante e até dois apoios de leitura por quadro. Máscaras de papel e regras horizontais criam transições; zooms e pans lentos em fotografias reais; reveal por sequência de palavras nos títulos. Evitar aparência de slides, acumulação de cartões sem hierarquia e animações corporais complexas.

## Abertura e assinatura

A fala começa no primeiro quadro. Lula e Flávio aparecem em ilustrações 2D editoriais simétricas, com oscilação lateral e vertical mínima e rotação de até aproximadamente dois graus. Cada imagem recebe a etiqueta legível “ILUSTRAÇÃO GERADA POR IA” e texto alternativo que informa a origem sintética. Não há lip sync, gesto, caminhada ou ação atribuída. A composição passa do retrato à semana 6×1. Encerramento retorna ao calendário e apresenta “JORNADA · SALÁRIO · DIREITOS” e “Siga @vizinhopublico”.

## Limites editoriais

- Distinguir a situação de cada medida: lei em vigor, proposta em tramitação ou compromisso de campanha.
- Não sugerir que PEC 221/2019 já virou lei.
- Não atribuir a Flávio uma cláusula da PEC 12/2026 sem verificar o texto primário; distinguir sua assinatura como coautor das falas do senador Rogério Marinho.
- Não inserir números simulados de salário, jornadas ou efeitos econômicos.
- Nenhuma imagem sem origem, licença ou registro de geração.
- Fotografia documental não deve sugerir encontros ou declarações não ocorridos.
