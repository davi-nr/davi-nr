# VIZINHO PÚBLICO — PRODUÇÃO INTEGRAL

Episódio: O novo pacote para MEIs anunciado por Lula
Projeto: Vizinho Público (@vizinhopublico)
Data de referência: 13 de outubro de 2026
Orquestrador: HyperFrames
Ferramenta de animação: Remotion, subordinado ao HyperFrames
Narração: Fish Audio S2.1 Pro Free
Formato: Reels vertical, 1080 × 1920
Duração desejada: 2min45s a 2min55s
Limite absoluto: 3 minutos

## 1. MISSÃO PRINCIPAL

Produza integralmente um documentário animado em 2D sobre o pacote de medidas para microempreendedores individuais anunciado pelo governo Lula em 13 de outubro de 2026.
O vídeo deve explicar, de maneira natural, envolvente e acessível, como funcionam as medidas anunciadas e quais mudanças elas poderão trazer para os MEIs.
O conteúdo precisa ter qualidade de reportagem audiovisual profissional.
Não quero uma apresentação de slides, um vídeo institucional de governo ou uma narração artificial que interrompe constantemente a própria explicação.
Quero um documentário animado que desenvolva o assunto com clareza, ritmo e identidade editorial.
Conduza o projeto do início ao fim, utilizando efetivamente o subagente HyperFrames.

## 2. ORQUESTRAÇÃO — HYPERFRAMES

Antes de produzir:
1. Localize as instruções reais do HyperFrames.
2. Consulte os arquivos AGENTS.md pertinentes.
3. Leia o README de continuidade do Vizinho Público.
4. Examine os projetos anteriores para preservar a identidade visual e sonora.
5. Identifique o mecanismo disponível para invocar o subagente HyperFrames.
6. Acione efetivamente o subagente e delegue a ele a direção da produção.

Ler o AGENTS.md não equivale a invocar o HyperFrames.
O HyperFrames deverá coordenar pesquisa e verificação factual, desenvolvimento editorial, roteiro, storyboard, direção visual, animação, narração, trilha sonora, renderização e auditoria final.
O Remotion é uma ferramenta de implementação e renderização, não o diretor criativo.
Não substitua o HyperFrames por uma execução genérica de Remotion.
Preserve os projetos e arquivos anteriores.
Não invente ferramentas, capacidades ou requisitos técnicos.

## 3. PESQUISA — PACOTE PARA MEIs

Investigue as medidas anunciadas em 13 de outubro de 2026.
Confirme o nome oficial do pacote, os instrumentos normativos, os valores, as condições e a situação de implementação.
Priorize fontes primárias: Ministério do Empreendedorismo, Ministério da Fazenda, Receita Federal, Procuradoria-Geral da Fazenda Nacional, Presidência da República, Câmara dos Deputados, Senado Federal e Diário Oficial da União.
Utilize reportagens confiáveis como fontes complementares.
Não utilize dados sem verificação.

### A. Auxílio ou incentivo de até R$ 5 mil

O anúncio foi divulgado como uma iniciativa de apoio financeiro a microempreendedores.
Investigue valor previsto, finalidade do recurso, quem poderá receber, critérios de elegibilidade, necessidade de inscrição, condições de utilização, fonte de financiamento e cronograma de implementação.
Verifique a natureza jurídica do benefício: transferência não reembolsável, crédito, subsídio ou outra modalidade.
Não confunda modalidades financeiras diferentes.

### B. Perdão de dívidas tributárias

Investigue a proposta anunciada envolvendo aproximadamente R$ 12,6 bilhões em débitos de cerca de 3,6 milhões de MEIs.
Confirme os números nas fontes oficiais.
Explique quais dívidas poderão ser abrangidas, quais empreendedores poderão ser contemplados, como o mecanismo deverá funcionar e quais condições estão previstas.
Não confunda perdão de dívidas com parcelamento ou renegociação.

### C. Renegociação de dívidas bancárias

Investigue o mecanismo anunciado para renegociar dívidas de microempreendedores junto a instituições financeiras.
Explique como a iniciativa pretende funcionar e quais condições estão previstas.
Diferencie eventuais descontos concedidos na negociação de carteiras bancárias dos descontos efetivamente oferecidos aos devedores.

### D. Aumento do teto de faturamento

Verifique a proposta de ampliação do limite anual de faturamento do MEI.
Valores divulgados para investigação: limite atual de referência R$ 81 mil; proposta para 2027 R$ 110 mil; proposta para 2028 R$ 140 mil.
Confira os valores, a tramitação legislativa e o texto integral da proposta.
Investigue também possíveis mudanças no número permitido de empregados.
Não apresente valores propostos como legislação já vigente.

### E. Simplificação de obrigações

Investigue eventuais mudanças relacionadas a emissão de notas fiscais, obrigações administrativas, regularização e procedimentos de formalização.
Explique apenas medidas que tenham sido efetivamente anunciadas e documentadas.

### Registro factual

Crie ou atualize FACTS.md contendo afirmação utilizada, fonte, URL, data da publicação, data de consulta, situação da medida, observações e limitações.
Separe claramente anúncio, proposta legislativa, norma publicada, regulamentação e execução efetiva.

## 4. REGRA EDITORIAL FUNDAMENTAL — NARRATIVA HUMANA

Esta é uma das orientações mais importantes de toda a produção.
Não quero um roteiro que pareça escrito por uma inteligência artificial excessivamente preocupada em se autocorrigir.
O HyperFrames deve pegar o tema, compreendê-lo e discorrer sobre ele naturalmente.
A narradora deve soar como uma jornalista experiente contando uma história e explicando um acontecimento relevante.

Evitar interrupções artificiais. Não repetir mecanicamente expressões como: “Mas calma…”, “Isso ainda não foi aprovado…”, “É importante destacar que…”, “Vale ressaltar…”, “Vale lembrar que…”, “Isso não significa necessariamente…”, “Porém, precisamos considerar…”, “Mas atenção…”, “Ainda depende de regulamentação…”.
Essas expressões não são individualmente proibidas. O problema é a repetição excessiva e a sensação de que o roteiro está constantemente corrigindo a si mesmo.

Apresente o assunto. Explique a primeira medida. Desenvolva seu funcionamento. Avance naturalmente para a próxima. Mantenha continuidade e interesse.
Não interrompa cada tópico para acrescentar uma advertência burocrática.
Reserve um bloco próximo ao encerramento para explicar o que já está valendo, o que ainda precisa de aprovação e quais detalhes permanecem indefinidos.
Durante o restante do vídeo, utilize construções naturalmente precisas: “O pacote prevê…”, “A proposta estabelece…”, “Segundo o anúncio…”, “O governo apresentou…”.
Essas construções permitem explicar medidas propostas sem tratá-las como regras já em vigor.
Se alguma ressalva for indispensável para evitar uma informação enganosa, integre-a naturalmente à própria frase.
Não omita condições essenciais que mudem o significado de uma medida.
O público deve sentir que está ouvindo uma reportagem bem escrita, e não uma inteligência artificial que faz uma afirmação e imediatamente tenta justificá-la.
Evite frases genéricas, conclusões artificiais e excesso de linguagem institucional.
O roteiro deve ser fluido, jornalístico, acessível e interessante.

## 5. GANCHO E ABERTURA

A abertura precisa prender a atenção desde os primeiros segundos.
Sugestão editorial: “Cinco mil reais para microempreendedores, perdão de dívidas e um novo limite de faturamento. Essas são algumas das medidas anunciadas pelo governo Lula. Mas como tudo isso vai funcionar na prática?”
O HyperFrames pode melhorar essa abertura. Não é obrigatório utilizar exatamente essas palavras.
O gancho precisa despertar curiosidade e apresentar o tema com clareza.
Evite iniciar com uma ressalva jurídica, uma introdução burocrática ou uma longa apresentação institucional.
Não prolongue artificialmente a abertura.

## 6. ESTRUTURA NARRATIVA

O HyperFrames tem liberdade para organizar a progressão do vídeo.
Sugestão: abertura apresenta medidas/pergunta central; desenvolvimento explica apoio financeiro, dívidas tributárias, renegociação bancária e mudanças propostas; contexto prático relaciona medidas à atividade de um microempreendedor com exemplos factualmente adequados; bloco final responde quais estão vigentes, quais dependem de aprovação/regulamentação; encerramento curto, informativo e natural.
Não é necessário dividir o vídeo em capítulos visíveis.
Não criar pausas longas ou vinhetas entre assuntos.
As transições devem ser orgânicas.

## 7. DIREÇÃO VISUAL — DOCUMENTÁRIO ANIMADO 2D

O vídeo inteiro precisa ter animação narrativa.
Não quero uma sequência de slides com imagens estáticas, títulos grandes e zooms lentos.
A animação deve participar da explicação.
Utilize motion design editorial 2D com valores e indicadores financeiros, gráficos, documentos oficiais, notas fiscais, elementos de orçamento, fluxos de recursos, linhas do tempo, fotografias reais, manchetes verificadas, tipografia cinética e elementos gráficos que contribuam para a compreensão.
Esses são recursos possíveis, não uma lista obrigatória de cenas. O HyperFrames tem autonomia para escolher a melhor abordagem.

Problemas anteriores que não podem se repetir: aparência PowerPoint; personagens genéricos dominando composição; ícones isolados sem função narrativa; grandes espaços vazios sem intenção visual; textos estáticos durante vários segundos; animação concentrada apenas na abertura; efeitos decorativos sem contribuição explicativa.
Não tente solucionar esses problemas adicionando movimentos aleatórios.
A prioridade é continuidade visual, clareza e ritmo.

Personagens são opcionais. Caso utilizados, podem permanecer estáticos ou apresentar movimentos sutis: pequenos deslocamentos, escalas e oscilações discretas.
Não exigir lip-sync, caminhadas, corridas, gestos corporais elaborados, manipulação articulada de objetos, movimentos complexos de braços/pernas ou atuação cinematográfica.
Regra de ouro: movimento nos dados e elementos gráficos, não nos personagens.
Não impor transformações complexas entre objetos, movimentos obrigatórios de câmera ou coreografias específicas.

## 8. FOTOGRAFIAS E MANCHETES REAIS

Pesquise fotografias autênticas relacionadas ao anúncio e ao universo dos microempreendedores brasileiros.
Priorize fotografias oficiais do anúncio, registros reais do presidente e representantes do governo, fotografias documentais de pequenos negócios, documentos públicos e manchetes autênticas de veículos jornalísticos.
Utilize somente imagens com direitos de uso compatíveis com a publicação.
Preserve identificação de fonte, veículo, data e contexto quando necessário.
Não invente fotografias, documentos, manchetes ou declarações.
Não apresente imagens sintéticas como registros reais.
Quando não houver autorização de uso, prefira elementos editoriais próprios.

## 9. NARRAÇÃO — FISH AUDIO S2.1 PRO FREE

Serviço Fish Audio; modelo S2.1 Pro Free; voz aprovada Mulher do Criativo top; reference_id ceaf7f569bef42c7bd322d88e3a356b7.
Parâmetros anteriores, sujeitos à compatibilidade API: temperature 0.85; top_p 0.85; speed 1.0.
Não substitua a voz aprovada sem autorização.
Narração feminina, serena, médio-grave, documental e fluida. A narradora deve conversar com o espectador de forma natural.
Não quero pausas exageradas, silêncios artificiais, frases fragmentadas, interpretação teatral, locução excessivamente solene, entonação robótica, perguntas pronunciadas como afirmações ou sensação de leitura palavra por palavra.
Não confundir voz documental com narração lenta. A fala deve ter ritmo/continuidade. Pausas naturais respeitam respiração, pontuação e intenção.

Mantenha narration_text separado de display_text.
Escreva números e siglas por extenso quando necessário para evitar erros de pronúncia.
Evite segmentar excessivamente texto Fish Audio.
Investigue pontuação, parâmetros e silêncios de montagem antes de alterar velocidade.
Não acelere indiscriminadamente a voz para mascarar narração mal construída.
Ouça efetivamente o áudio gerado. Corrija pronúncias, entonações e pausas artificiais.
Sincronize animações à duração real da narração aprovada.

## 10. MÚSICA E EDIÇÃO DE ÁUDIO

Trilha instrumental documental discreta. Preferência piano, texturas leves/percussão sutil quando apropriado.
Música incorporada ao MP4 final desde primeira entrega.
Ducking durante fala; preserve inteligibilidade.
Efeitos sonoros só quando contribuírem para narrativa.
Evite mudanças bruscas de volume, silêncios involuntários e efeitos excessivos.

## 11. IDENTIDADE VIZINHO PÚBLICO

Preserve identidade visual/sonora já estabelecida nos projetos anteriores.
Conteúdo explicativo, acessível, factual, profissional, visualmente envolvente e editorialmente independente.
Não transforme vídeo em propaganda eleitoral ou institucional.
Não acrescente chamadas promocionais sobre inteligência artificial, ressalvadas obrigações legais e das plataformas.
Não invente novo quadro, vinheta ou identidade sem necessidade.

## 12. DURAÇÃO E EXPORTAÇÃO

1080 × 1920, vertical 9:16. Máximo absoluto 180 segundos; meta 165–175 segundos.
Duração inclui abertura, desenvolvimento, conclusão, assinatura e créditos.
Não corte encerramento para caber. Não imponha 60 FPS genericamente.
Escolha exportação adequada e verifique fluidez real.

## 13. ENTREGÁVEIS

MP4 final com narração e música; projeto editável; roteiro integral; storyboard; FACTS.md verificado; créditos/licenças mídia; capa Instagram; legenda pronta Instagram com no máximo cinco hashtags; relatório auditoria audiovisual.
Preserve materiais anteriores.

## 14. AUDITORIA FINAL

Verifique efetivamente: HyperFrames acionado; duração ≤3min; roteiro natural sem autocorreções/ressalvas redundantes; propostas/vigência distintas; bloco final situaçãoimplementação; narração fluida sem pausas artificiais; perguntas entonação convincente; animação explicativa duração inteira; aparência semslides; personagens respeitam limites; fotos/manchetesautênticas; dadoscontextualizados/verificados; música incorporada; sincronia comáudioreal; encerramentocompleto.
Não declare verificações que não tenham sido realizadas.
Não apresente vídeo aprovado automaticamente.

## 15. INSTRUÇÃO FINAL

HyperFrames, assuma direção criativa/editorial. Pesquise/compreenda medidas e desenvolva reportagem audiovisual natural, envolvente/factual.
Não transforme instruções em lista mecânica de efeitos. Não crie narração cheia de ressalvas, autocorreções/interrupções burocráticas.
Não confunda precisão factual com justificar cada frase. Explique assunto naturalmente, desenvolva ideias, deixe espectador acompanhar história.
Concentre informações de aprovação/regulamentação/implementação em bloco final sem omitir qualificações indispensáveis durante explicação.
Não exija movimentos complexos de personagens para dinamismo.
Animação editorial verdadeira com liberdadecriativa e identidade Vizinho Público.
Conduza produção completa sem interromper desnecessariamente fluxo para aprovação de cada etapa.
Objetivo final: documentário animado atétrêsminutos, profissional, narraçãohumana/fluida, pesquisarigorosa, linguagem envolvente.
