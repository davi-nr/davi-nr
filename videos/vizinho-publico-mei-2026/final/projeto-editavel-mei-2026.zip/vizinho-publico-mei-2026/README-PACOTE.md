# Projeto editável — pacote anunciado para MEIs

O projeto de composição ativo usa Remotion 4.0.535 em `remotion-app/`. A abertura e as cenas, títulos, gráficos e legendas são editáveis em React/CSS; os takes e os dados-fonte usados estão incluídos. O MP4 final e a capa são entregues separadamente.

## Restaurar áudio e renderizar

Requisitos: Python 3, FFmpeg com suporte a FLAC e Node.js/npm.

Na raiz deste pacote:

```bash
python3 scripts/restore_package_audio.py
```

O script restaura os três WAVs PCM16 para `assets/audio/` e `remotion-app/public/audio/`, confere taxa, canais, número de amostras e SHA-256 do PCM antes de copiar. Os FLACs estão em `audio-package/` para reduzir o tamanho do ZIP sem perda de amostras.

Depois:

```bash
cd remotion-app
npm ci
npm run render
npm run render-cover
```

`npm run render` cria `../deliverables/vizinho-publico-mei-2026-final-transition-fixed.mp4` a 1080×1920/30 fps, H.264, AAC-LC estéreo, usando Chromium em `/usr/bin/chromium`. Se o executável do Chromium estiver em outro caminho, ajuste `--browser-executable` em `package.json`.

O render do filme existente usa os áudios empacotados e não exige conta nem credencial Fish. Para sintetizar novas falas, edite `assets/audio/scene-text.json` e use `python3 scripts/generate_voice.py [números-das-cenas]`. O gerador usa `normalize:false`, alias/modelo e referência documentados em `assets/audio/voice-manifest.json`; forneça `FISH_API_KEY` pelo ambiente (ou `FISH_CONFIG_TOML` apontando para uma configuração MCP local). Nenhum segredo está incluído. Após novos takes, rode `python3 scripts/build_mix.py` e restaure/sincronize os novos masters PCM para o áudio público antes de renderizar.

## Fontes e limites

Consulte `FACTS.md` para os fatos, o recorte temporal, as modalidades anunciadas e as propostas legislativas; `SCRIPT.md` e `STORYBOARD.md` acompanham a narração e a ordem visual. `ASSET-ATTRIBUTIONS.md` registra a foto contextual CC0, a música original procedural, fontes e licenças. O áudio e as legendas têm verificações automáticas documentadas; elas não equivalem a escuta humana.
