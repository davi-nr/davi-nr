# Auditoria da revisão de transições

Esta revisão mantém intacto `deliverables/vizinho-publico-mei-2026-final.mp4` e gera a candidata `deliverables/vizinho-publico-mei-2026-final-transition-fixed.mp4` a partir do projeto Remotion.

## Alteração

As sequências agora cobrem sem intervalo o tempo até o início da cena seguinte. O título e o identificador de cada cena ficam visíveis no primeiro quadro local; a nota secundária continua entrando depois. Isso elimina o quadro creme sem conteúdo que aparecia entre as cinco cenas.

## Verificações do MP4 novo

- H.264 High, nível 4.0, 1080×1920, 30 fps, 4.987 quadros, 166,251 s; AAC-LC, 48 kHz, estéreo.
- Arquivo: 9.484.938 bytes; SHA-256: `66d42edc90d81a330aa70fd4537b7764951fd4fbfe640fe06bc178847492b7b5`.
- Decodificação integral com FFmpeg concluída sem erros. A caixa `moov` precede `mdat` (fast start).
- Áudio integrado: −16,0 LUFS, LRA 2,0 LU, true peak −1,5 dBFS. A extração AAC é byte a byte idêntica à candidata anterior, SHA-256 `5ff353394bb9bd3fa54e3877b1d48cfe1d856924a47ac7a421c99949c35b27d3`.
- Foram extraídos e inspecionados quadros do MP4 nos cinco cortes (antes e depois) e nos pontos corrigidos das cenas 3, 4, 5 e CTA. Contato: `deliverables/mp4-audit-frames/` e `/tmp/mei-final-mp4-contact.jpg`.
- Testes de stills anteriores à exportação confirmaram título no primeiro quadro das cenas 2–6: `deliverables/transition-fixed-*.png`.

Os arquivos de áudio não foram alterados; portanto, as transcrições automáticas existentes continuam correspondentes. Não houve avaliação de escuta humana nem execução de um gate automático de movimento; as verificações acima cobrem metadados, decodificação, loudness, identidade da trilha AAC e inspeção visual dos quadros selecionados.
