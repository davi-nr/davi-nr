#!/usr/bin/env python3
"""Restore the exact PCM sample streams from the packaged FLAC files."""
from __future__ import annotations
import hashlib
import json
import pathlib
import shutil
import subprocess
import tempfile
import wave

ROOT = pathlib.Path(__file__).resolve().parents[1]
PACK = ROOT / "audio-package"

def pcm_sha(path: pathlib.Path) -> str:
    with wave.open(str(path), "rb") as wf:
        return hashlib.sha256(wf.readframes(wf.getnframes())).hexdigest()

def main() -> None:
    rows = json.loads((PACK / "manifest.json").read_text(encoding="utf-8"))
    with tempfile.TemporaryDirectory(prefix="mei-audio-restore-") as tmp:
        tmp = pathlib.Path(tmp)
        for row in rows:
            flac = ROOT / row["flac"]
            restored = tmp / f"{row['stem']}.wav"
            subprocess.run([
                "ffmpeg", "-y", "-v", "error", "-i", str(flac),
                "-ar", str(row["sample_rate"]), "-ac", str(row["channels"]),
                "-c:a", "pcm_s16le", str(restored)
            ], check=True)
            with wave.open(str(restored), "rb") as wf:
                params = wf.getparams()
            if params.nframes != row["frames"] or params.sampwidth != row["sample_width_bytes"]:
                raise SystemExit(f"PCM format mismatch: {row['stem']}")
            actual = pcm_sha(restored)
            if actual != row["pcm_sha256"]:
                raise SystemExit(f"PCM checksum mismatch: {row['stem']}")
            for rel in row["targets"]:
                target = ROOT / rel
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(restored, target)
            print(f"restored {row['stem']}: PCM SHA-256 {actual}")

if __name__ == "__main__":
    main()
