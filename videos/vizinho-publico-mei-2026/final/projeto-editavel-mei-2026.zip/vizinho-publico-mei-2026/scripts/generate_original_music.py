#!/usr/bin/env python3
"""Deterministic, original low-profile documentary music bed (no external samples)."""
import argparse
from pathlib import Path

import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io.wavfile import write

SR = 44100


def make_track(seconds: float) -> np.ndarray:
    n = int(SR * seconds)
    t = np.arange(n, dtype=np.float64) / SR
    out = np.zeros(n, dtype=np.float64)

    # D minor → B-flat → F → C: a distinct, restrained investigative palette.
    chords = [
        [36.708, 73.416, 110.000, 146.832],
        [58.270, 116.540, 174.614, 233.082],
        [43.654, 87.307, 130.813, 174.614],
        [32.703, 65.406, 98.000, 130.813],
    ]
    chord_len = 8 * 60 / 78
    fade = 1.25
    pad = np.zeros(n, dtype=np.float64)

    # Cycle repeats with smooth chord-to-chord crossfades; detuned pairs create warmth.
    loop_len = chord_len * len(chords)
    loop_t = np.mod(t, loop_len)
    segment = np.floor(loop_t / chord_len).astype(np.int8)
    local_t = loop_t - segment * chord_len
    for i, chord in enumerate(chords):
        mask = segment == i
        next_chord = chords[(i + 1) % len(chords)]
        local = local_t[mask]
        fade_start = chord_len - fade
        phase_blend = np.clip((local - fade_start) / fade, 0, 1)
        blend = 0.5 - 0.5 * np.cos(np.pi * phase_blend)
        current = np.zeros(mask.sum(), dtype=np.float64)
        following = np.zeros(mask.sum(), dtype=np.float64)
        for j, hz in enumerate(chord):
            phase = 0.31 * j + i * 0.17
            current += (
                np.sin(2 * np.pi * hz * t[mask] + phase)
                + 0.42 * np.sin(2 * np.pi * hz * 2.004 * t[mask] + phase * 0.7)
                + 0.16 * np.sin(2 * np.pi * hz * 0.501 * t[mask] + phase * 1.3)
            ) / 7.0
        for j, hz in enumerate(next_chord):
            phase = 0.31 * j + (i + 1) * 0.17
            following += (
                np.sin(2 * np.pi * hz * t[mask] + phase)
                + 0.42 * np.sin(2 * np.pi * hz * 2.004 * t[mask] + phase * 0.7)
                + 0.16 * np.sin(2 * np.pi * hz * 0.501 * t[mask] + phase * 1.3)
            ) / 7.0
        pad[mask] = current * (1 - blend) + following * blend
    lfo = 0.86 + 0.12 * np.sin(2 * np.pi * loop_t / loop_len - 0.7)
    pad *= lfo

    # A muted, rounded felt-like pulse on each beat, with a light alternating arp.
    beat = 60 / 78
    beat_count = int(np.ceil(seconds / beat))
    pulse = np.zeros(n, dtype=np.float64)
    for b in range(beat_count):
        start = int(b * beat * SR)
        if start >= n:
            break
        end = min(n, start + int(0.24 * SR))
        x = np.arange(end - start, dtype=np.float64) / SR
        bar_index = int((b * beat) / chord_len) % 4
        note = chords[bar_index][(b // 2) % 4]
        attack = np.minimum(1.0, x / 0.018)
        env = attack * np.exp(-x / (0.14 if b % 4 else 0.2))
        fundamental = np.sin(2 * np.pi * note * x)
        overtone = 0.22 * np.sin(2 * np.pi * note * 2.76 * x)
        pulse[start:end] += (fundamental + overtone) * env * (0.34 if b % 4 else 0.48)

    # Soft low-frequency throb every two beats; no hard drum transient.
    kick = np.zeros(n, dtype=np.float64)
    for b in range(0, beat_count, 2):
        start = int(b * beat * SR)
        if start >= n:
            break
        end = min(n, start + int(0.38 * SR))
        x = np.arange(end - start, dtype=np.float64) / SR
        freq = 62 - 18 * np.minimum(x / 0.18, 1.0)
        phase = 2 * np.pi * np.cumsum(freq) / SR
        kick[start:end] += np.sin(phase) * np.exp(-x / 0.15) * 0.17

    # Sparse, soft paper/wood ticks on alternate bars.
    tick = np.zeros(n, dtype=np.float64)
    for b in range(0, beat_count, 4):
        start = int((b + 2) * beat * SR)
        if start >= n:
            break
        end = min(n, start + int(0.08 * SR))
        x = np.arange(end - start, dtype=np.float64) / SR
        click = np.sin(2 * np.pi * 1650 * x) + 0.32 * np.sin(2 * np.pi * 2470 * x)
        tick[start:end] += click * np.exp(-x / 0.022) * 0.05

    # Add occasional glassy but low-contrast notes at phrase turns.
    bells = np.zeros(n, dtype=np.float64)
    for bar in range(int(seconds / (4 * beat)) + 1):
        start_s = bar * 4 * beat + 1.5 * beat
        start = int(start_s * SR)
        if start >= n:
            break
        end = min(n, start + int(1.5 * SR))
        x = np.arange(end - start, dtype=np.float64) / SR
        chord = chords[bar % 4]
        note = chord[(bar + 1) % len(chord)] * 2
        bell = np.sin(2 * np.pi * note * x) + 0.22 * np.sin(2 * np.pi * note * 2.01 * x)
        bell *= (1 - np.exp(-x / 0.018)) * np.exp(-x / 0.65)
        bells[start:end] += bell * 0.08

    out = 0.68 * pad + pulse + kick + tick + bells
    # Soft low-pass keeps the music under clear dialogue.
    sos = butter(3, 5400, btype="lowpass", fs=SR, output="sos")
    out = sosfilt(sos, out)

    # Opening tension, steady middle, restrained lift for the numbers, natural close.
    dynamics = np.ones(n, dtype=np.float64)
    dynamics *= 0.74 + 0.11 * np.minimum(t / 14, 1.0)
    lift = np.clip((t - seconds * 0.70) / max(1.0, seconds * 0.16), 0, 1)
    dynamics *= 1 + 0.12 * lift
    fade_out = np.clip((seconds - t) / 5.0, 0, 1)
    dynamics *= fade_out
    out *= dynamics

    # Reverb-like early reflections are deterministic and quiet.
    for delay_s, gain in [(0.13, 0.14), (0.23, 0.085), (0.37, 0.045)]:
        d = int(delay_s * SR)
        out[d:] += out[:-d] * gain

    peak = np.max(np.abs(out)) or 1.0
    # Conservative peak target leaves headroom for the voice/music mix.
    out = out / peak * 0.16
    stereo = np.column_stack((out, np.roll(out, int(0.007 * SR)) * 0.985))
    stereo[: int(0.007 * SR), 1] = stereo[: int(0.007 * SR), 0]
    return np.clip(stereo, -1, 1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("seconds", type=float)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    write(args.output, SR, (make_track(args.seconds) * 32767).astype(np.int16))
    print(f"Wrote original procedural documentary bed: {args.output} ({args.seconds:.2f}s, {SR} Hz stereo)")
