#!/usr/bin/env python3
"""Build the scene-aligned narration and a continuous, ducked music master."""
from __future__ import annotations
import json, pathlib, subprocess, tempfile, wave

ROOT = pathlib.Path(__file__).resolve().parents[1]
VOICE_DIR = ROOT / "assets/audio/scenes"
OUT_DIR = ROOT / "assets/audio"
MANIFEST = OUT_DIR / "voice-manifest.json"
RATE = 48_000
CHANNELS = 2
SAMPLE_WIDTH = 2
GAP_SECONDS = 0.28
TAIL_SECONDS = 1.8

def run(args: list[str], **kwargs):
    return subprocess.run(args, check=True, **kwargs)

def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    manifest = sorted(manifest, key=lambda x: x["scene"])
    if [x["scene"] for x in manifest] != list(range(1, 7)):
        raise SystemExit("Expected six current voice takes in voice-manifest.json")

    with tempfile.TemporaryDirectory(prefix="mei-mix-") as tmp:
        tmp = pathlib.Path(tmp)
        pcm_paths: list[pathlib.Path] = []
        durations: list[float] = []
        for row in manifest:
            source = ROOT / row["path"]
            target = tmp / f"scene-{row['scene']:02d}.wav"
            run(["ffmpeg", "-y", "-v", "error", "-i", str(source), "-ar", str(RATE), "-ac", str(CHANNELS), "-c:a", "pcm_s16le", str(target)])
            with wave.open(str(target), "rb") as wf:
                durations.append(wf.getnframes() / wf.getframerate())
            pcm_paths.append(target)

        narration_path = OUT_DIR / "narration-full.wav"
        with wave.open(str(pcm_paths[0]), "rb") as first:
            params = first.getparams()
        with wave.open(str(narration_path), "wb") as output:
            output.setnchannels(CHANNELS)
            output.setsampwidth(SAMPLE_WIDTH)
            output.setframerate(RATE)
            for idx, path in enumerate(pcm_paths):
                with wave.open(str(path), "rb") as wf:
                    output.writeframes(wf.readframes(wf.getnframes()))
                if idx < len(pcm_paths) - 1:
                    output.writeframes(b"\0" * round(GAP_SECONDS * RATE) * CHANNELS * SAMPLE_WIDTH)

        speech_len = sum(durations) + GAP_SECONDS * (len(durations) - 1)
        program_len = speech_len + TAIL_SECONDS
        music = OUT_DIR / "music-original.wav"
        full = OUT_DIR / "full-mix.wav"
        pre = tmp / "premix.wav"
        # Raise the quiet original bed, duck it against the narration, and fade only at the film ending.
        filter_complex = (
            f"[0:a]apad=pad_dur={TAIL_SECONDS:.6f}[voice];"
            f"[1:a]atrim=0:{program_len:.6f},asetpts=PTS-STARTPTS,volume=9dB,"
            f"afade=t=out:st={program_len-1.3:.6f}:d=1.3[music];"
            f"[music][voice]sidechaincompress=threshold=0.018:ratio=7:attack=18:release=280:makeup=1[bed];"
            f"[voice][bed]amix=inputs=2:duration=longest:dropout_transition=0[out]"
        )
        run([
            "ffmpeg", "-y", "-v", "warning", "-i", str(narration_path), "-i", str(music),
            "-filter_complex", filter_complex, "-map", "[out]", "-t", f"{program_len:.6f}",
            "-ar", str(RATE), "-ac", str(CHANNELS), "-c:a", "pcm_s16le", str(pre)
        ], stdout=subprocess.DEVNULL)
        first = run([
            "ffmpeg", "-hide_banner", "-i", str(pre), "-af", "loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json",
            "-f", "null", "-"
        ], capture_output=True, text=True)
        import re
        blocks = re.findall(r"\{[^{}]*\}", first.stderr, flags=re.S)
        stats = json.loads(blocks[-1])
        ln = (
            "loudnorm=I=-16:TP=-1.5:LRA=7:"
            f"measured_I={stats['input_i']}:measured_TP={stats['input_tp']}:"
            f"measured_LRA={stats['input_lra']}:measured_thresh={stats['input_thresh']}:"
            f"offset={stats['target_offset']}:linear=true:print_format=summary"
        )
        run([
            "ffmpeg", "-y", "-v", "warning", "-i", str(pre), "-af", ln,
            "-ar", str(RATE), "-ac", str(CHANNELS), "-c:a", "pcm_s16le", str(full)
        ], stdout=subprocess.DEVNULL)
        report = {
            "scene_durations_seconds": [round(x, 3) for x in durations],
            "gaps_seconds": GAP_SECONDS,
            "speech_duration_seconds": round(speech_len, 3),
            "program_duration_seconds": round(program_len, 3),
            "tail_seconds": TAIL_SECONDS,
            "music": "continuous original procedural instrumental, +9dB then sidechain-compressed under narration, 1.3s final fade",
            "mix": "48 kHz stereo PCM16; two-pass loudnorm target I=-16 LUFS, TP=-1.5 dBTP, LRA=7; verify actual result after mux",
            "loudnorm_pass1": stats,
        }
        (OUT_DIR / "mix-report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(report, ensure_ascii=False))

if __name__ == "__main__":
    main()
