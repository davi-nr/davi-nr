#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, pathlib, re, subprocess, sys, tomllib
P=pathlib.Path(__file__).resolve().parents[1]
TEXT=P/'assets/audio/scene-text.json'; OUT=P/'assets/audio/scenes'; HELPER=P/'assets/vendor/fish_audio_tts.mjs'
VOICE='ceaf7f569bef42c7bd322d88e3a356b7'
def call(text: str, path: pathlib.Path, request_id: int):
 # Portable and secret-safe: use injected environment values first. In a
 # Codex environment, FISH_CONFIG_TOML may point to its existing MCP config.
 fish={}
 if not os.environ.get('FISH_API_KEY'):
  config_path=os.environ.get('FISH_CONFIG_TOML')
  if not config_path:
   raise RuntimeError('Set FISH_API_KEY or FISH_CONFIG_TOML in the runtime environment; never store the key in this project.')
  config=tomllib.loads(pathlib.Path(config_path).read_text(encoding='utf8'))
  fish=config['mcp_servers']['fish-audio']['env']
 env=os.environ.copy(); env.update(fish); env.update(AUDIO_OUTPUT_DIR=str(path.parent),NODE_USE_ENV_PROXY='1')
 args={'text':text,'output_path':str(path),'format':'mp3','temperature':.85,'top_p':.85,'speed':1.0,'normalize':False}
 req={'jsonrpc':'2.0','id':request_id,'method':'tools/call','params':{'name':'fish_audio_tts','arguments':args}}
 r=subprocess.run(['node',str(HELPER)],input=json.dumps(req,ensure_ascii=False)+'\n',capture_output=True,text=True,env=env,timeout=240,check=True)
 response=json.loads(r.stdout.splitlines()[-1]); body=response.get('result',{})
 if body.get('isError'): raise RuntimeError('Fish Audio rejected request '+str(request_id))
 d=json.loads(body['content'][0]['text'])
 if not d.get('success') or not path.exists() or path.stat().st_size==0: raise RuntimeError('No audio returned')
 return d

def main():
 data=json.loads(TEXT.read_text(encoding='utf-8'))
 if not data or len({x['scene'] for x in data}) != len(data): raise SystemExit('Expected a non-empty list with unique scene ids')
 if any(re.search(r'\d',x['narration_text']) for x in data): raise SystemExit('Narration must spell out all numbers')
 OUT.mkdir(parents=True,exist_ok=True)
 manifest_path=P/'assets/audio/voice-manifest.json'; records={}
 selected={int(x) for x in sys.argv[1:]} if len(sys.argv)>1 else {int(x['scene']) for x in data}
 for item in data:
  i=item['scene']
  if i not in selected: continue
  path=OUT/f'{i:02d}-scene.mp3'; d=call(item['narration_text'],path,i)
  records[i]={'scene':i,'path':path.relative_to(P).as_posix(),'bytes':path.stat().st_size,'model_requested_accepted_alias':d.get('model'),'model_backend_attestation':'not independently provided','reference_id':d.get('reference_id'),'temperature':d.get('temperature'),'top_p':d.get('top_p'),'speed':d.get('speed'),'normalize':False,'input_sha256':hashlib.sha256(item['narration_text'].encode()).hexdigest()}
  print(json.dumps({'scene':i,'bytes':path.stat().st_size,'model':d.get('model'),'normalize':False,'input_sha256':records[i]['input_sha256']}),flush=True)
  old=json.loads(manifest_path.read_text()) if manifest_path.exists() else []
  current={x['scene']:hashlib.sha256(x['narration_text'].encode()).hexdigest() for x in data}
  keep={r['scene']:r for r in old if r['scene'] not in selected and r.get('input_sha256')==current.get(r['scene']) and (P/r.get('path','')).is_file()}
  keep.update(records)
  manifest_path.write_text(json.dumps([keep[i] for i in sorted(keep)],ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__': main()
