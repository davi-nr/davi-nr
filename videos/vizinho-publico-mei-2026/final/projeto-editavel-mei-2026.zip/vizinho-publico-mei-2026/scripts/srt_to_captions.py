#!/usr/bin/env python3
"""Convert Whisper SRT cues to the Remotion caption array."""
import re
import sys
from pathlib import Path


def seconds(value: str) -> float:
    h, m, rest = value.split(":")
    s, ms = rest.split(",")
    return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000


def split_caption(text: str, limit: int = 54) -> list[str]:
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) <= limit:
        return [text]
    # Prefer a sentence boundary when both lines remain comfortably readable.
    for marker in (". ", "? ", "; "):
        at = text.find(marker)
        if at > 0 and at + len(marker) < len(text):
            first = text[:at + 1].strip()
            second = text[at + len(marker):].strip()
            if len(first) <= limit and len(second) <= int(limit * 1.25):
                return [first + "\n" + second]
    words = text.split()
    lines, current = [], ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if len(candidate) > limit and current:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    if len(lines) <= 2:
        return ["\n".join(lines)]
    # Keep captions at two lines. Split long ASR intervals evenly by words;
    # downstream captions retain the original interval's timing.
    chunks = []
    while words:
        chunk, n = [], 0
        while words and (n + len(words[0]) + bool(chunk) <= limit * 2):
            w = words.pop(0)
            chunk.append(w)
            n += len(w) + bool(chunk)
        chunks.append(" ".join(chunk))
    return chunks


def correct_asr_orthography(text: str) -> str:
    """Apply known contextual homophone fixes, then preserve script wording."""
    fixes = {
        "O governo Lula anunciou um pacote para mês, o que muda de verdade para quem trabalha por":
            "O governo Lula anunciou um pacote para MEIs. O que muda de verdade para quem trabalha por",
        "para débitos de mês inscritos na": "para débitos de MEIs inscritos na",
        "carteiras de débitos de mês, com": "carteiras de débitos de MEIs, com",
        "Hoje, o limite anual do mês é": "Hoje, o limite anual do MEI é",
        "exige a missão": "exige emissão",
        "Siga, rouba, vizinho público.": "Siga @vizinhopublico.",
        "a documento fiscal": "documento fiscal",
        "reais apresentado como não reembolsável": "reais, apresentado como não reembolsável",
        "procuradoria geral da Fazenda Nacional": "Procuradoria-Geral da Fazenda Nacional",
        "A modalidade do desenrola anunciada": "A modalidade do Desenrola anunciada",
        "No desenrola,": "No Desenrola,",
        "Em Leilão,": "Em leilão,",
        "O teto também prevê até dois empregados": "Ele também prevê até dois empregados",
        "que resolve uma necessidade": "que resolva uma necessidade",
        "capital semente": "capital-semente",
        "antes de contar com o benefício": "antes de contar com um benefício",
        "aguardava despacho na Câmara, perdão tributário": "aguardava despacho na Câmara. Perdão tributário",
    }
    for old, new in fixes.items():
        text = text.replace(old, new)
    return text


def parse_srt(path: Path):
    raw = path.read_text(encoding="utf-8-sig")
    cues = []
    for block in re.split(r"\n\s*\n", raw.strip()):
        lines = block.splitlines()
        timing = next((x for x in lines if "-->" in x), None)
        if not timing:
            continue
        a, b = [x.strip() for x in timing.split("-->")]
        text = " ".join(x.strip() for x in lines[lines.index(timing) + 1:] if x.strip())
        cues.append((seconds(a), seconds(b), correct_asr_orthography(text)))
    return cues


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: srt_to_captions.py INPUT.srt OUTPUT.js")
    source, target = Path(sys.argv[1]), Path(sys.argv[2])
    result = []
    for start, end, text in parse_srt(source):
        chunks = split_caption(text)
        if len(chunks) == 1:
            result.append({"start": round(start, 3), "end": round(end, 3), "text": chunks[0]})
        else:
            weights = [max(1, len(c.replace("\n", " "))) for c in chunks]
            total = sum(weights)
            cursor = start
            for i, (chunk, weight) in enumerate(zip(chunks, weights)):
                next_cursor = end if i == len(chunks) - 1 else cursor + (end - start) * weight / total
                result.append({"start": round(cursor, 3), "end": round(next_cursor, 3), "text": chunk})
                cursor = next_cursor
    for i, cue in enumerate(result):
        if cue["end"] <= cue["start"]:
            raise SystemExit(f"invalid cue: {cue}")
        if i and result[i - 1]["end"] > cue["start"] + 0.002:
            raise SystemExit(f"overlapping captions: {result[i-1]} / {cue}")
    lines = ["// Generated from the final Whisper SRT; text was checked against SCRIPT.md.", "export const captions = ["]
    for cue in result:
        text = cue["text"].replace("\\", "\\\\").replace("`", "\\`").replace("${", "\\${")
        lines.append(f'  {{start:{cue["start"]}, end:{cue["end"]}, text:`{text}`}},')
    lines.append("];")
    target.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"{len(result)} captions -> {target}")
    print(f"last caption ends at {result[-1]['end']:.3f}s" if result else "no captions")


if __name__ == "__main__":
    main()
