import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {captions} from './captions.js';

export const FilmFrames = 4987;
const fps = 30;
const C = {petrol:'#263438', cream:'#F4F1DE', ochre:'#D9A441', brick:'#B9483D', green:'#347A70', paper:'#FFFEF7', gray:'#687574'};
const clamp = {extrapolateLeft:'clamp', extrapolateRight:'clamp'};
const v = (fr, a, b, x, y) => interpolate(fr, [a*fps, b*fps], [x,y], clamp);
const reveal = (fr, at, dur=.55) => ({opacity:v(fr,at,at+dur,0,1), translate:`0 ${v(fr,at,at+dur,24,0)}px`});

const Header = ({n, eyebrow, title, note, fr, dark=false}) => <>
  <div className={`brandline ${dark?'brandline-dark':''}`}><b>VIZINHO PÚBLICO</b><span>{String(n).padStart(2,'0')} / 06&nbsp;&nbsp; · &nbsp;&nbsp;MEI</span></div>
  {/* The scene title is already present at the exact cut frame; delayed details
      can still build after it. This prevents a blank/only-caption transition. */}
  <div className="eyebrow" style={reveal(fr,-.15,.15)}>{eyebrow}</div>
  <h1 className="scene-title" style={reveal(fr,-.15,.15)}>{title}</h1>
  {note&&<div className="scene-note" style={reveal(fr,.55,.38)}>{note}</div>}
</>;

const Stamp = ({children, style={}})=><span className="stamp" style={style}>{children}</span>;
const Arrow = ({color=C.ochre, width=150})=><svg width={width} height="26" viewBox={`0 0 ${width} 26`} aria-hidden="true"><path d={`M2 13 H${width-13} M${width-24} 3 L${width-13} 13 L${width-24} 23`} fill="none" stroke={color} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/></svg>;

function Scene1(){
 const fr=useCurrentFrame();
 const scale=v(fr,0,9.2,1.02,1.12);
 return <AbsoluteFill className="scene scene-hook">
  <Img src={staticFile('images/vendor-rio-context.jpg')} className="hook-photo" style={{scale}}/>
  <div className="hook-shade"/>
  <Header n={1} eyebrow="Pacote anunciado · 13 de outubro" title={<>MEI: três frentes<br/>em discussão</>} note="Apoio · dívidas · faturamento" fr={fr} dark/>
  <div className="hook-ledger" style={reveal(fr,.65,.42)}>
    <div className="hook-entry"><span className="hook-number">R$ 5 MIL</span><span>apoio anunciado</span><i style={{transform:`scaleX(${v(fr,.7,2.7,0,1)})`}}/></div>
    <div className="hook-entry"><span className="hook-number">R$ 12,6 BI</span><span>débitos citados</span><i style={{transform:`scaleX(${v(fr,2.2,4.8,0,1)})`}}/></div>
    <div className="hook-entry"><span className="hook-number">R$ 81 MIL</span><span>teto atual</span><i style={{transform:`scaleX(${v(fr,4.3,7.1,0,1)})`}}/></div>
  </div>
  <Stamp style={{position:'absolute',right:78,bottom:265,background:C.cream,color:C.petrol}}>PACOTE ANUNCIADO · 13/10</Stamp>
  <div className="hook-thread" style={{width:`${v(fr,1.0,8.7,0,470)}px`}}/>
 </AbsoluteFill>;
}

function Scene2(){
 const fr=useCurrentFrame();
 const flow=v(fr,4.5,16.5,0,1);
 const year=v(fr,18,21.5,2027,2030);
 return <AbsoluteFill className="scene">
  <Header n={2} eyebrow="Apoio produtivo" title={<>Um recurso para<br/>estruturar o negócio</>} note="Capital-semente anunciado · não reembolsável" fr={fr}/>
  <div className="seed-amount" style={reveal(fr,.7,.5)}><small>POR PROJETO</small><strong>ATÉ <em>R$ 5 MIL</em></strong><span>não é empréstimo bancário</span></div>
  <div className="seed-path">
   <div className="seed-node seed-cash" style={reveal(fr,2.8,.5)}><b>RECURSO</b><span>apoio financeiro</span><div className="coin-row"><i/><i/><i/><i/></div></div>
   <div className="seed-connector"><i style={{transform:`scaleX(${flow})`}}/></div>
   <div className="seed-node seed-choice" style={reveal(fr,7.5,.55)}><b>BEM OU SERVIÇO</b><span>uma necessidade concreta</span><div className="mini-equipment"><div/><i/><i/></div></div>
   <div className="seed-connector seed-connector-low"><i style={{transform:`scaleX(${v(fr,14,18,0,1)})`}}/></div>
   <div className="seed-node seed-support" style={reveal(fr,14.5,.55)}><b>ACOMPANHAMENTO</b><span>plano de uso produtivo</span><div className="support-check">✓</div></div>
  </div>
  <div className="seed-scale" style={reveal(fr,18.5,.4)}><div><small>PREVISÃO TOTAL</small><b>R$ 5 BILHÕES</b></div><div className="seed-years"><span>2027</span><i/><b>{Math.round(year)}</b></div><small>prioridade anunciada: mulheres com menor faturamento</small></div>
 </AbsoluteFill>;
}

function Scene3(){
 const fr=useCurrentFrame();
 const count=v(fr,11.5,15,0,3.6);
 const debt=v(fr,16,18.3,0,12.6);
 const cursor=v(fr,6,14,0,1);
 return <AbsoluteFill className="scene scene-paper">
  <Header n={3} eyebrow="Dívida ativa da União" title={<>Uma proposta de<br/>remissão tributária</>} note="Débitos classificados como irrecuperáveis pela PGFN" fr={fr}/>
  <div className="debt-file" style={reveal(fr,.5,.5)}>
   <div className="file-spine"><span>PROCESSO · MEI</span><i style={{height:`${v(fr,.8,10,0,310)}px`}}/></div>
   <div className="file-body">
    <div className="file-top"><span>DIAGRAMA EDITORIAL · ILUSTRATIVO</span><Stamp>PROPOSTA</Stamp></div>
    <div className="file-row" style={reveal(fr,2.5,.4)}><b>01</b><span>Inscrição em dívida ativa</span><i/></div>
    <div className="file-row" style={reveal(fr,7,.4)}><b>02</b><span>PGFN · classificação de irrecuperável</span><i style={{width:`${v(fr,7.2,13,0,290)}px`}}/></div>
    <div className="pgfn-seal" style={{opacity:v(fr,11,12,.0,1),rotate:`${v(fr,11,12,-9,0)}deg`}}>2027 · PREVISTO</div>
   </div>
  </div>
  <div className="debt-numbers">
   <div style={reveal(fr,11.5,.3)}><small>ESTIMATIVA DIVULGADA</small><strong>{count.toFixed(1).replace('.',',')} MI</strong><span>empreendedores</span></div>
   <div className="debt-divider"/>
   <div style={reveal(fr,15.9,.3)}><small>VALOR AGREGADO</small><strong>R$ {debt.toFixed(1).replace('.',',')} BI</strong><span>débitos citados no anúncio</span></div>
  </div>
  <div className="debt-compare" style={reveal(fr,23,.4)}><div><b>REMISSÃO</b><span>extingue a dívida abrangida</span></div><strong className="not-equal">≠</strong><div><b>PARCELAMENTO</b><span>divide o pagamento</span></div></div>
  <div className="debt-year" style={reveal(fr,27,.3)}><span>PREVISÃO DO ANÚNCIO</span><b>2027</b></div>
 </AbsoluteFill>;
}

function Scene4(){
 const fr=useCurrentFrame();
 const sale=v(fr,9.5,17,0,1);
 return <AbsoluteFill className="scene">
  <Header n={4} eyebrow="Desenrola MEI · bancos" title={<>Uma carteira pode<br/>ser vendida em leilão</>} note="Valor nominal estimado: R$ 6 bilhões" fr={fr}/>
  <div className="portfolio-sheet" style={reveal(fr,.6,.45)}>
   <div className="portfolio-head"><span>CARTEIRA DE DÉBITOS</span><b>VALOR NOMINAL</b></div>
   <div className="portfolio-grid">{Array.from({length:12},(_,i)=><i key={i} style={{opacity:v(fr,1.5+i*.11,2+i*.11,.18,.9),transform:`translateY(${v(fr,1.5+i*.11,2+i*.11,12,0)}px)`}}/>)}</div>
   <div className="portfolio-total">R$ 6 BI</div>
  </div>
  <div className="auction-route" style={reveal(fr,5,.45)}><div className="bank-pill">BANCO</div><Arrow width={330}/><div className="auction-box"><b>LEILÃO</b><span>carteira</span></div><Arrow width={220}/><div className="gov-pill">GOVERNO</div></div>
  <div className="auction-discount" style={reveal(fr,10,.35)}><div className="discount-mark">90%</div><div className="discount-copy"><b>DESCONTO MÍNIMO NO LANCE</b><span>sobre o valor da carteira vendida ao governo</span></div><div className="auction-bar"><i style={{transform:`scaleX(${sale})`}}/></div></div>
  <div className="individual-note" style={reveal(fr,18,.4)}><span>NEGOCIAÇÃO DO MEI</span><b>tem condições próprias</b><small>o percentual do leilão não vira abatimento automático da dívida individual</small></div>
 </AbsoluteFill>;
}

function Scene5(){
 const fr=useCurrentFrame();
 const line=v(fr,8,12,0,1);
 const grossIn=reveal(fr,5,.4);
 const grossOpacity=Math.min(1,grossIn.opacity*(1-v(fr,20,20.5,0,1))+v(fr,31.5,31.9,0,1));
 return <AbsoluteFill className="scene scene-ceiling">
  <Header n={5} eyebrow="Enquadramento e nota fiscal" title={<>O teto sobe no projeto;<br/>a regra ainda é a atual</>} note="Receita bruta não é lucro" fr={fr}/>
  <div className="ceiling-rail" style={reveal(fr,.6,.45)}>
   <div className="rail-line"><i style={{transform:`scaleX(${line})`}}/></div>
   <div className="ceiling-stop current" style={reveal(fr,1,.35)}><small>HOJE</small><b>R$ 81 MIL</b><span>limite anual vigente</span></div>
   <div className="ceiling-stop proposed one" style={reveal(fr,8.05,.35)}><small>PROPOSTA · 2027</small><b>R$ 110 MIL</b><span>PLP na Câmara</span></div>
   <div className="ceiling-stop proposed two" style={reveal(fr,11.3,.35)}><small>PROPOSTA · 2028</small><b>R$ 140 MIL</b><span>se o projeto avançar</span></div>
  </div>
  <div className="gross-profit" style={{...grossIn,opacity:grossOpacity}}>
   <div className="cash-in"><small>VENDA NO ANO</small><b>RECEITA BRUTA</b><span>entra antes dos custos</span><i style={{width:`${v(fr,6,10,20,390)}px`}}/></div>
   <div className="cash-costs"><span>compras</span><span>aluguel</span><span>outros custos</span><Arrow color={C.brick} width={78}/></div>
   <div className="profit-remain" style={{opacity:v(fr,10,12,0,1)}}><small>O QUE SOBRA</small><b>LUCRO</b></div>
  </div>
  <div className="employee-note" style={reveal(fr,15.6,.35)}>O projeto prevê até dois empregados em atividades rurais específicas descritas no texto.</div>
  <div className="invoice-flow" style={reveal(fr,20.5,.45)}>
   <div className="invoice-heading"><b>NOTA FISCAL</b><span>VENDA E DESTINATÁRIO</span></div>
   <div className="invoice-path"><div className="invoice-box buyer">PESSOA FÍSICA<span>CONSUMIDOR FINAL</span></div><Arrow width={130}/><div className="invoice-current">REGRA ATUAL<br/><b>DISPENSA JÁ PREVISTA</b></div></div>
   <div className="invoice-path second"><div className="invoice-box buyer">DESTINO COM CNPJ<span>EMPRESA</span></div><Arrow color={C.green} width={130}/><div className="invoice-current cnpj">EMISSÃO<br/><b>DOCUMENTO FISCAL</b></div></div>
   <div className="invoice-announcement" style={{opacity:v(fr,22,22.3,0,1)}}>ANÚNCIO SOBRE DISPENSA</div>
  </div>
 </AbsoluteFill>;
}

function Scene6(){
 const fr=useCurrentFrame();
 const progress=v(fr,.6,20,0,1);
 const cta=v(fr,22.2,23.4,0,1);
 return <AbsoluteFill className="scene scene-close">
  <Header n={6} eyebrow="O que está valendo?" title={<>Anúncio não é<br/>regra em vigor</>} note="Situação em 13 de outubro de 2026" fr={fr}/>
  <div className="status-river" style={reveal(fr,1,.4)}>
   <div className="status-lane current-lane"><small>VIGENTE</small><b>R$ 81 MIL</b><span>teto anual do MEI</span><i style={{width:`${v(fr,1,5,0,300)}px`}}/></div>
   <div className="status-lane bill-lane" style={reveal(fr,5,.4)}><small>PROJETO NA CÂMARA</small><b>R$ 110 MIL → R$ 140 MIL</b><span>aguarda despacho</span><i style={{width:`${v(fr,5,10,0,360)}px`}}/></div>
   <div className="status-lane announced-lane" style={reveal(fr,10,.4)}><small>MEDIDAS ANUNCIADAS</small><b>APOIO · REMISSÃO · DESENROLA</b><span>regras de execução precisam ser consultadas</span><i style={{width:`${v(fr,10,16,0,360)}px`}}/></div>
  </div>
  <div className="status-footer" style={reveal(fr,17,.4)}><span>A dispensa ao consumidor final já integra a regra atual.</span><b>Acompanhe canais oficiais antes de mudar o planejamento.</b></div>
  <div className="endline" style={{opacity:cta,translate:`0 ${v(fr,22.2,23.4,24,0)}px`}}><div className="end-logo">VIZINHO<br/>PÚBLICO</div><span>Siga @vizinhopublico</span><i/></div>
  <div className="end-thread" style={{width:`${v(fr,19,23,80,800)}px`}}/>
 </AbsoluteFill>;
}

const SceneComponents=[Scene1,Scene2,Scene3,Scene4,Scene5,Scene6];
const timeline=[0,9.684,39.456125,70.273188,95.264938,135.407688];
const timelineFrames=timeline.map((t)=>Math.round(t*fps));
const sceneFrameLengths=timelineFrames.map((start,i)=>i<timelineFrames.length-1?timelineFrames[i+1]-start:FilmFrames-start);

export const MeiFilm=()=>{
 const {fps:compFps}=useVideoConfig();
 return <AbsoluteFill style={{backgroundColor:C.cream}}>
  {SceneComponents.map((Scene,i)=><Sequence key={i} from={timelineFrames[i]} durationInFrames={sceneFrameLengths[i]}><Scene/></Sequence>)}
  <Audio src={staticFile('audio/full-mix.wav')} />
  <CaptionRail/>
 </AbsoluteFill>;
};

function CaptionRail(){
 const fr=useCurrentFrame();
 const sec=fr/fps;
 const cue=captions.find(x=>sec>=x.start && sec<x.end);
 if(!cue) return null;
 const opacity=interpolate(sec,[cue.start,cue.start+.09,cue.end-.09,cue.end],[0,1,1,0],clamp);
 return <div className="caption-rail" style={{opacity}}>{cue.text}</div>;
}
