import React from 'react';
import {Composition} from 'remotion';
import {MeiFilm, FilmFrames} from './Video';
import {MeiCover} from './Cover';

export const RemotionRoot = () => <>
  <Composition id="MeiFilm" component={MeiFilm} durationInFrames={FilmFrames} fps={30} width={1080} height={1920}/>
  <Composition id="MeiCover" component={MeiCover} durationInFrames={1} fps={30} width={1080} height={1920}/>
</>;
