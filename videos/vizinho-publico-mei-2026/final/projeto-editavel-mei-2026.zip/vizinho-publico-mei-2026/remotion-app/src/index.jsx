import React from 'react';
import {registerRoot} from 'remotion';
import {RemotionRoot} from './Root';
import './styles.css';

registerRoot(RemotionRoot);
