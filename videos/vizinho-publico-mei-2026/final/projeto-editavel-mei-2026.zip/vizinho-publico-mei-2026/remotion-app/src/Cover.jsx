import React from 'react';
import {AbsoluteFill, Img, staticFile} from 'remotion';

export const MeiCover=()=> <AbsoluteFill className="cover-frame">
 <Img src={staticFile('images/vendor-rio-context.jpg')} className="cover-photo"/>
 <div className="cover-shade"/>
 <div className="cover-brand">VIZINHO PÚBLICO <span>· REPORTAGEM</span></div>
 <div className="cover-date">O QUE FOI ANUNCIADO · OUTUBRO DE 2026</div>
 <div className="cover-title"><small>MEI</small><strong>O PACOTE<br/>EM DETALHES</strong></div>
 <div className="cover-amount">R$ 5 MIL · DÍVIDAS · NOVO TETO</div>
 <div className="cover-stamp">ANÚNCIO<br/>EM ANÁLISE</div>
 <div className="cover-handle">@VIZINHOPUBLICO</div>
</AbsoluteFill>;
