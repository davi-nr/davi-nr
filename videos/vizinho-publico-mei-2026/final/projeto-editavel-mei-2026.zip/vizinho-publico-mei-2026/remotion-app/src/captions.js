// Generated from the final Whisper SRT; text was checked against SCRIPT.md.
export const captions = [
  {start:0.0, end:4.6, text:`Até 5 mil reais para investir, perdão de dívidas, e um
limite maior de faturamento.`},
  {start:4.6, end:8.52, text:`O governo Lula anunciou um pacote para MEIs.
O que muda de verdade para quem trabalha por`},
  {start:8.52, end:9.52, text:`conta própria.`},
  {start:9.52, end:15.08, text:`A primeira frente é um capital-semente de até 5 mil
reais, apresentado como não reembolsável.`},
  {start:15.08, end:19.32, text:`O recurso serviria para comprar um bem ou contratar um
serviço que ajude a estruturar`},
  {start:19.32, end:21.46, text:`o negócio, com acompanhamento.`},
  {start:21.46, end:27.96, text:`A previsão é distribuir 5 bilhões entre 2027 e 2030,
priorizando mulheres com menor`},
  {start:27.96, end:28.96, text:`faturamento.`},
  {start:28.96, end:32.16, text:`Não é crédito, é apoio produtivo por projeto.`},
  {start:32.16, end:36.2, text:`Imagine uma máquina que economize tempo ou um serviço
que resolva uma necessidade da`},
  {start:36.2, end:37.2, text:`operação.`},
  {start:37.2, end:39.44, text:`Esse é o tipo de investimento descrito.`},
  {start:39.44, end:41.64, text:`A segunda frente é a dívida com a União.`},
  {start:41.64, end:45.76, text:`O governo anunciou uma proposta de remissão integral
para débitos de MEIs inscritos na`},
  {start:45.76, end:51.08, text:`dívida ativa e classificados como irrecuperáveis pela
Procuradoria-Geral da Fazenda Nacional.`},
  {start:51.08, end:56.64, text:`A estimativa divulgada é de 3 milhões e 600 mil
empreendedores, com 12 bilhões e 600`},
  {start:56.64, end:58.36, text:`milhões de reais em débitos.`},
  {start:58.36, end:61.96, text:`A remissão está prevista para começar em 2027.`},
  {start:61.96, end:67.08, text:`Remissão significa extinguir a dívida abrangida,
parcelamento apenas divide o pagamento.`},
  {start:67.08, end:70.4, text:`Aqui o anúncio fala em remissão, não em parcelamento.`},
  {start:70.4, end:72.36, text:`Dívida bancária é outra frente.`},
  {start:72.36, end:76.94, text:`A modalidade do Desenrola anunciada prevê comprar
carteiras de débitos de MEIs, com`},
  {start:76.94, end:80.04, text:`valor nominal estimado em 6 bilhões de reais.`},
  {start:80.04, end:85.08, text:`Em leilão, os bancos ofereceriam pelo menos 90% de
desconto sobre o valor da carteira ao`},
  {start:85.08, end:88.76, text:`governo e as ofertas com maior desconto teriam
prioridade.`},
  {start:88.76, end:93.0, text:`Esse percentual incide na venda entre banco e governo,
não é um abatimento automático`},
  {start:93.0, end:95.32, text:`de 90% para cada empreendedor.`},
  {start:95.32, end:97.64, text:`O teto de faturamento também está na pauta.`},
  {start:97.64, end:101.32, text:`Hoje, o limite anual do MEI é 81 mil reais.`},
  {start:101.32, end:103.28, text:`Faturamento é receita bruta, não lucro.`},
  {start:103.28, end:110.84, text:`O projeto enviado à Câmara em junho propõe 110 mil em
2027 e 140 mil em 2028.`},
  {start:110.84, end:114.72, text:`Ele também prevê até dois empregados para as
atividades rurais específicas descritas`},
  {start:114.72, end:115.72, text:`no texto.`},
  {start:115.72, end:120.0, text:`Sobre a nota fiscal, o anúncio mencionou dispensa para
vendas a pessoas físicas.`},
  {start:120.0, end:124.4, text:`A regra atual já dispensa documento fiscal para o
consumidor final e exige emissão`},
  {start:124.4, end:127.04, text:`quando o destinatário tem CNPJ.`},
  {start:127.04, end:132.12, text:`O teto conta o que entra em vendas no ano antes de
descontar compras, aluguel ou outros`},
  {start:132.12, end:133.12, text:`custos.`},
  {start:133.12, end:135.52, text:`Por isso, o faturamento não é o lucro que sobra.`},
  {start:135.52, end:140.12, text:`No corte de 13 de outubro, o teto de 81 mil reais
seguia em vigor e o projeto de aumento`},
  {start:140.12, end:144.68, text:`aguardava despacho na Câmara. Perdão tributário e
capital-semente foram anunciados para tramitar`},
  {start:144.68, end:146.2, text:`em projeto de lei.`},
  {start:146.2, end:150.16, text:`No Desenrola, as condições da negociação individual
ainda precisam ser definidas.`},
  {start:150.16, end:154.4, text:`Para saber o alcance do decreto sobre notas, é preciso
consultar o texto oficial.`},
  {start:154.4, end:158.12, text:`A dispensa para o consumidor final já integra a regra
atual.`},
  {start:158.12, end:162.56, text:`Acompanhe os canais oficiais antes de contar com o
benefício ou mudar o planejamento.`},
  {start:162.56, end:164.18, text:`Siga @vizinhopublico.`},
];
