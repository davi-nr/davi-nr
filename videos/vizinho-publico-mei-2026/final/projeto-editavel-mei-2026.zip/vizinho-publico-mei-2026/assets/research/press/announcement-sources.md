# Fontes secundárias do anúncio de 13/10/2026

Consulta registrada em 13/10/2026. As matérias são cobertura do anúncio e das falas de autoridades; não substituem o projeto de lei, edital, decreto ou ato do DOU.

- CNN Brasil, “De perdão de dívidas a Pix de R$ 5 mil: entenda o pacote de Lula para MEI”, 13/10/2026: https://www.cnnbrasil.com.br/economia/money/macroeconomia/de-perdao-de-dividas-a-pix-de-r-5-mil-entenda-o-pacote-de-lula-para-mei/
- CNN Brasil, “Pix MEI: Governo propõe distribuir R$ 5 bi para empreendedores”, 13/10/2026: https://www.cnnbrasil.com.br/economia/money/macroeconomia/pix-mei-governo-propoe-distribuir-r-5-bi-para-empreendedores/
- Poder360, “Saiba as medidas anunciadas pelo governo para microempreendedores”, 13/10/2026, 12h37: https://www.poder360.com.br/poder-economia/saiba-as-medidas-anunciadas-pelo-governo-para-microempreendedores/
- Poder360, “Na reta final do 2º turno, governo lançará ‘Pix MEI’ de até R$ 5.000”, matéria anterior ao anúncio: https://www.poder360.com.br/poder-economia/na-reta-final-do-2o-turno-governo-lancara-pix-mei-de-ate-r-5-000/

Notas factuais, os números e os limites do uso das fontes estão em `FACTS.md`.
