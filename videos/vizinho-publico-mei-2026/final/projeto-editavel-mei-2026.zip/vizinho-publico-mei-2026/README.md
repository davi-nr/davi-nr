# Vizinho Público — pacote anunciado para MEIs

Projeto audiovisual em 1080×1920, criado sob direção do fluxo HyperFrames e implementado/renderizado em Remotion 4.0.535. Os documentos separam anúncio jornalístico, regras atuais e propostas legislativas; consulte `FACTS.md` antes de reutilizar trechos fora do vídeo.

## Fontes do projeto

- `SCENE-DATA.json` mantém, por cena, texto falado e texto de tela separados.
- `SCRIPT.md` é a versão falada correspondente aos seis takes atuais.
- `STORYBOARD.md` registra a progressão visual e os tempos calculados a partir dos takes efetivamente usados.
- `assets/audio/voice-manifest.json` liga cada MP3 ao hash do texto enviado e aos parâmetros Fish usados. A API aceitou o alias solicitado `s2.1-pro-free`; não forneceu atestação independente do backend.
- `assets/audio/transcript-full.srt` e `.json` guardam a transcrição automática bruta; `assets/audio/captions-final.srt` e `remotion-app/src/captions.js` contêm as legendas revistas contra o roteiro. O ASR serviu como triagem textual, não como prova de audição humana.
- `remotion-app/src/Video.jsx` contém as seis cenas animadas, o áudio e as legendas.

## Reprodução

Requisitos: Python 3.11+, FFmpeg, Node.js/npm e Chromium. Na raiz extraída, restaure primeiro os áudios lossless; o script verifica os hashes PCM e copia o mix ao caminho público usado na composição:

```bash
python3 scripts/restore_package_audio.py
cd remotion-app
```

No diretório `remotion-app`:

```bash
npm ci
npm run studio
npm run render
npm run render-cover
```

O comando de render gera `deliverables/vizinho-publico-mei-2026-final-transition-fixed.mp4` usando Chromium local em `/usr/bin/chromium`, 1080×1920, 30 fps, H.264, AAC estéreo e preset `fast`. Ajuste `--browser-executable` no script se Chromium estiver em outro caminho. A composição usa apenas arquivos locais em `public/`.

O mix reproduzível é criado a partir dos MP3 em `assets/audio/scenes/` e da trilha original `assets/audio/music-original.wav`:

```bash
python3 scripts/build_mix.py
```

O script decodifica os takes para PCM estéreo a 48 kHz, intercala pausas curtas entre blocos, aplica ducking na música, faz normalização de dois passos e registra as durações e medições preliminares em `assets/audio/mix-report.json`. A trilha e a narração também permanecem separadas em `assets/audio/music-original.wav` e `assets/audio/narration-full.wav`.

Legendas podem ser reconstruídas do SRT automático com `python3 scripts/srt_to_captions.py assets/audio/transcript-full.srt remotion-app/src/captions.js`. Depois, confira o texto com `SCRIPT.md`: reconhecimento automático pode errar nomes, siglas ou fronteiras de palavras.

## Voz e fontes

A síntese usa Fish Audio, alias de modelo solicitado `s2.1-pro-free`, voz de referência `ceaf7f569bef42c7bd322d88e3a356b7`, temperature/top-p 0,85, speed 1,0 e `normalize:false`. Renderizar com os áudios incluídos não requer credenciais nem chamadas de síntese. Para gerar novas vozes, o script lê `FISH_API_KEY` do ambiente (ou `FISH_CONFIG_TOML` opcional). Nunca grave chaves no projeto.

Fontes e licenças estão em `assets/fonts/`. Créditos de imagem e trilha estão em `ASSET-ATTRIBUTIONS.md`. Verificações de texto automatizadas por ASR são triagem, não avaliação humana de dicção ou entonação.
