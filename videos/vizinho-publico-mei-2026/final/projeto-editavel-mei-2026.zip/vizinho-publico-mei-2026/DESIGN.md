# Direção visual — pacote anunciado para MEIs

**Conceito:** acompanhar uma pequena operação comercial através de seus registros: entrada e aplicação de capital, dívida tributária, carteira bancária e limite de faturamento. Os números do anúncio surgem como documentos em movimento e encontram seu status legislativo no fechamento.

**Identidade Vizinho Público:** petróleo `#263438`, creme `#F4F1DE`, ocre `#D9A441`, tijolo `#B9483D` e verde `#347A70`; Teko para manchetes e números, EB Garamond para narração em tela e JetBrains Mono para datas, referências e status. Fontes locais licenciadas em `assets/fonts/`.

**Composição:** 1080 × 1920, editorial documental. Uma fotografia CC0 de comércio de rua funciona como contexto, não como identificação de uma empresa ou pessoa beneficiada pelo programa. Os demais diagramas são gráficos editoriais, não documentos oficiais. Valores agregados sempre acompanham seu escopo.

**Movimento:** folhas de caixa, linhas de dívida e limite anual atravessam o quadro em continuidade; os dados se reagrupam conforme a narração muda de medida. Evitar seis cartões isolados, manter leitura móvel e reservar faixa inferior às legendas.

**Som:** voz Fish em ritmo documental, música instrumental original procedural discreta e ducking contínuo. Não usar trilha como pausa artificial entre assuntos.
